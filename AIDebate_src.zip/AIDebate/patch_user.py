#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 新增「用户狼人杀」模式：用户扮演一名玩家，轮到他时暂停等输入/选择。
#  · 新标签 tab-userww + 新视图 view-userww（身份卡 / 身份分配面板 / 发言记录 / 私有信息 / 选择框 / 输入框）
#  · 不显示头像、不显示职业（chips 只显示号码+存活），思考默认不可见
#  · 无上帝视角：好人看不到狼人投票/预言家/女巫操作
#  · 随机分配号码，发言顺序按号码；结束后在本局真相标出「谁扮演几号」
import io

PATH = 'assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, tag):
    global src, n
    if old not in src:
        print('WARN 未命中: ' + tag)
        return
    src = src.replace(old, new, 1)
    n += 1
    print('OK   ' + tag)

# ================= A. CSS =================
rep(
""".bar-actions .chk.inline input{width:15px;height:15px;margin:0}
</style>""",
""".bar-actions .chk.inline input{width:15px;height:15px;margin:0}

/* ---------- 用户狼人杀 ---------- */
#view-userww.active{display:flex;flex-direction:column;padding:0}
.uwwtop{padding:8px 10px 0}
.uwwid{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:9px 12px;font-size:13px;line-height:1.7}
.uwwid b{color:var(--accent)}
.uwwid .role{font-weight:800;color:var(--txt)}
.uwwroles{margin-top:8px;background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:8px 12px;font-size:12px;color:var(--dim);line-height:1.7}
.uwwbottom{flex:0 0 auto;border-top:1px solid var(--line);background:var(--panel);padding:8px 10px}
.uwwpriv{font-size:12px;color:#9fb0c9;margin-bottom:6px;white-space:pre-wrap;line-height:1.6}
.uwwchoices{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px}
.uwwchoices .btn{font-size:13px;padding:7px 12px}
.uww-hint{flex:1 0 100%;font-size:12.5px;color:var(--accent);margin-bottom:2px}
.uwwinput{display:flex;gap:6px;align-items:flex-end}
.uwwinput textarea{flex:1;min-height:42px;max-height:120px;resize:none;background:var(--panel2);
  border:1px solid var(--line);color:var(--txt);border-radius:10px;padding:9px 11px;font-size:14px;font-family:inherit}
.uwwinput .btn{flex:0 0 auto;height:42px}
#view-userww .transcript{flex:1;min-height:0}
</style>""",
    'css userww')

# ================= B. 标签 + 视图 =================
rep(
"""      <button id="tab-werewolf" class="active">狼人杀</button>
      <button id="tab-config">设置</button>""",
"""      <button id="tab-werewolf" class="active">狼人杀</button>
      <button id="tab-userww">用户狼人杀</button>
      <button id="tab-config">设置</button>""",
    'tab userww')

rep(
"""      <div class="transcript" id="wwTranscript">
        <p class="empty">还没有开局。<br>在「设置」里配好至少 5 位 AI 选手，<br>然后回来点「开始新一局」。</p>
      </div>
    </section>

    <!-- ================= 设置 ================= -->""",
"""      <div class="transcript" id="wwTranscript">
        <p class="empty">还没有开局。<br>在「设置」里配好至少 5 位 AI 选手，<br>然后回来点「开始新一局」。</p>
      </div>
    </section>

    <!-- ================= 用户狼人杀 ================= -->
    <section id="view-userww" class="pane">
      <div class="bar">
        <div class="status" id="uwwStatus"></div>
        <div class="bar-actions">
          <button class="btn primary" id="btnUwwStart">开始新一局</button>
          <button class="btn danger" id="btnUwwStop" disabled>停止</button>
          <button class="btn ghost" id="btnUwwClear">清空</button>
        </div>
      </div>
      <div class="uwwtop">
        <div class="uwwid" id="uwwIdentity">你还没有参战。点「开始新一局」，随机分配号码后你会扮演其中一名玩家。</div>
        <div class="uwwroles" id="uwwRoles" hidden></div>
      </div>
      <div class="wwchips" id="uwwChips"></div>
      <div class="transcript" id="uwwTranscript">
        <p class="empty">点「开始新一局」参战。<br>至少需要 4 位已配置的 AI 选手（你 + AI 共 5 人起）。<br>轮到你发言 / 行动时，下方会出现输入框或选择框。</p>
      </div>
      <div class="uwwbottom">
        <div class="uwwpriv" id="uwwPriv"></div>
        <div class="uwwchoices" id="uwwChoices" hidden></div>
        <div class="uwwinput" id="uwwInputWrap" hidden>
          <textarea id="uwwInput" placeholder="轮到你发言了，说点什么…"></textarea>
          <button class="btn primary" id="uwwSend">发送</button>
        </div>
      </div>
    </section>

    <!-- ================= 设置 ================= -->""",
    'view userww')

# ================= C. 模式化 UI 辅助 =================
rep(
"""let ww = null;
let wwStick = true;""",
"""let ww = null;
let wwStick = true;

/* ---------- 用户狼人杀：模式化 UI +输入网关 ---------- */
let uwwWaitResolve = null;
function wwIsUser() { return !!(ww && ww.userMode); }
function wwTrans() { return document.getElementById(wwIsUser() ? 'uwwTranscript' : 'wwTranscript'); }
function wwChipsEl() { return document.getElementById(wwIsUser() ? 'uwwChips' : 'wwChips'); }
function wwStatusEl() { return document.getElementById(wwIsUser() ? 'uwwStatus' : 'wwStatus'); }
function wwGateEl() { return document.getElementById(wwIsUser() ? 'uwwGateBtn' : 'wwGateBtn'); }
function wwBtn(name) { return document.getElementById((wwIsUser() ? 'btnUww' : 'btnWw') + name); }

/* 轮到你发言：弹出输入框，等用户发送 */
function uwwAskInput(ph) {
  return new Promise(function (resolve) {
    const wrap = document.getElementById('uwwInputWrap');
    const ta = document.getElementById('uwwInput');
    if (!wrap || !ta) { resolve({ type: 'abort' }); return; }
    if (ta && ph) ta.placeholder = ph;
    if (ta) ta.value = '';
    wrap.hidden = false;
    uwwWaitResolve = resolve;
    try { ta.focus(); } catch (e) {}
  });
}
function uwwSendNow() {
  const ta = document.getElementById('uwwInput');
  const wrap = document.getElementById('uwwInputWrap');
  if (!uwwWaitResolve) return;
  const v = String((ta && ta.value) || '').trim();
  if (!v) { toast('说点什么再发送'); return; }
  if (ta) ta.value = '';
  if (wrap) wrap.hidden = true;
  const r = uwwWaitResolve; uwwWaitResolve = null;
  r({ type: 'text', value: v });
}
/* 需要做选择时弹出的选择框 */
function uwwChoose(title, options) {
  return new Promise(function (resolve) {
    const box = document.getElementById('uwwChoices');
    if (!box) { resolve({ type: 'abort' }); return; }
    box.hidden = false;
    box.innerHTML = '';
    if (title) {
      const tip = document.createElement('div');
      tip.className = 'uww-hint';
      tip.textContent = title;
      box.appendChild(tip);
    }
    options.forEach(function (op) {
      const b = document.createElement('button');
      b.className = 'btn ' + (op.primary ? 'primary' : 'ghost');
      b.textContent = op.label;
      b.addEventListener('click', function () {
        box.hidden = true; box.innerHTML = '';
        const r = uwwWaitResolve; uwwWaitResolve = null;
        if (r) r({ type: 'choice', value: op.value });
      });
      box.appendChild(b);
    });
    uwwWaitResolve = resolve;
  });
}
/* 从一组玩家里选一个，返回名字 */
async function uwwPick(title, pool) {
  const r = await uwwChoose(title, pool.map(function (p) { return { label: p.name, value: p.name }; }));
  return (r && r.type === 'choice') ? r.value : null;
}
/* 中止等待（停止 / 新局时调用），解开挂起的 Promise */
function uwwAbort() {
  const wrap = document.getElementById('uwwInputWrap');
  const box = document.getElementById('uwwChoices');
  if (wrap) wrap.hidden = true;
  if (box) { box.hidden = true; box.innerHTML = ''; }
  const r = uwwWaitResolve; uwwWaitResolve = null;
  if (r) r({ type: 'abort' });
}
function uwwResetUI() {
  const t = document.getElementById('uwwTranscript');
  if (t) t.innerHTML = '';
  const priv = document.getElementById('uwwPriv');
  if (priv) priv.textContent = '';
  const box = document.getElementById('uwwChoices');
  if (box) { box.hidden = true; box.innerHTML = ''; }
  const wrap = document.getElementById('uwwInputWrap');
  if (wrap) wrap.hidden = true;
}
/* 身份卡：始终显示「你是几号 / 你的身份」 */
function uwwRenderIdentity() {
  const el = document.getElementById('uwwIdentity');
  if (!el) return;
  if (!ww || !ww.userMode || !ww.userPlayer) { el.textContent = '你还没有参战。点「开始新一局」，随机分配号码后你会扮演其中一名玩家。'; return; }
  const u = ww.userPlayer;
  let s = '你是 <b>' + esc(u.name) + '</b> · 你的身份：<span class="role">' + (WW_ROLE_EMOJI[u.role] || '') + u.role + '</span>';
  if (u.role === '狼人') {
    const mates = ww.players.filter(function (x) { return x.role === '狼人' && x.id !== u.id; }).map(function (x) { return x.name; });
    s += '<br>你的狼队友：' + (mates.length ? mates.join('、') : '（只有你一个狼人）');
  }
  if (!u.alive) s += '<br>（你已出局，可以继续围观）';
  el.innerHTML = s;
}
/* 你的私有信息（只有你能看到的事实） */
function uwwPriv() {
  const el = document.getElementById('uwwPriv');
  if (!el) return;
  if (!ww || !ww.userMode || !ww.userPlayer) { el.textContent = ''; return; }
  const u = ww.userPlayer;
  const lines = (u.notes || []).slice(-8);
  el.textContent = lines.join('\n');
}
/* 对局结束后揭晓身份分配（谁扮演几号） */
function uwwRevealRoles() {
  const el = document.getElementById('uwwRoles');
  if (!el || !ww) return;
  el.hidden = false;
  el.innerHTML = '🔓 身份分配（本局已结束，供核对）：<br>' + ww.players.map(function (p) {
    const st = p.alive ? '（存活）' : ('（' + (p.deathReason || '出局') + (p.deathDay ? ('·第' + p.deathDay + '天') : '') + '）');
    return p.name + '：' + (WW_ROLE_EMOJI[p.role] || '') + p.role + st + (p.isUser ? ' ← 你' : '');
  }).join('<br>');
}""",
    'uww helpers')

# ================= D. 让现有渲染走模式化元素 =================
rep("""function wwScroll(force) {
  const t = $("#wwTranscript");""",
"""function wwScroll(force) {
  const t = wwTrans();""",
    'wwScroll ref')

rep("""function wwBindScroll() {
  const t = $("#wwTranscript");
  if (!t || t.__sb) return;
  t.__sb = true;
  t.addEventListener("touchstart", function () { wwStick = false; }, { passive: true });
  t.addEventListener("mousedown", function () { wwStick = false; }, { passive: true });
  t.addEventListener("wheel", function () { wwStick = false; }, { passive: true });
  t.addEventListener("scroll", function () {
    if (t.scrollHeight - t.scrollTop - t.clientHeight < 24) wwStick = true;
  }, { passive: true });
}""",
"""function wwBindScroll() {
  ['wwTranscript', 'uwwTranscript'].forEach(function (id) {
    const t = document.getElementById(id);
    if (!t || t.__sb) return;
    t.__sb = true;
    t.addEventListener("touchstart", function () { wwStick = false; }, { passive: true });
    t.addEventListener("mousedown", function () { wwStick = false; }, { passive: true });
    t.addEventListener("wheel", function () { wwStick = false; }, { passive: true });
    t.addEventListener("scroll", function () {
      if (t.scrollHeight - t.scrollTop - t.clientHeight < 24) wwStick = true;
    }, { passive: true });
  });
}""",
    'wwBindScroll ref')

rep("""function wwClear() {
  const t = $("#wwTranscript");
  if (t) t.innerHTML = '<p class="empty">还没有开局。<br>在「设置」里配好至少 5 位 AI 选手，<br>然后回来点「开始新一局」。</p>';
  const c = $("#wwChips");
  if (c) c.innerHTML = '';
}""",
"""function wwClear() {
  const t = wwTrans();
  if (t) t.innerHTML = '<p class="empty">还没有开局。<br>在「设置」里配好至少 5 位 AI 选手，<br>然后回来点「开始新一局」。</p>';
  const c = wwChipsEl();
  if (c) c.innerHTML = '';
}""",
    'wwClear ref')

rep("""function wwAdd(kind, title, text) {
  const t = $("#wwTranscript");""",
"""function wwAdd(kind, title, text) {
  const t = wwTrans();""",
    'wwAdd ref')

rep("""function wwSpeakBubble(pl, label) {
  const t = $("#wwTranscript");
  if (!t) return null;
  const empty = t.querySelector(".empty");
  if (empty) empty.remove();
  const el = document.createElement("div");
  el.className = "msg";
  el.innerHTML =
    '<div class="avatar">' + esc(pl.emoji || '🤖') + '</div>' +
    '<div class="body">' +""",
"""function wwSpeakBubble(pl, label) {
  const t = wwTrans();
  if (!t) return null;
  const empty = t.querySelector(".empty");
  if (empty) empty.remove();
  const el = document.createElement("div");
  el.className = "msg";
  const av = wwIsUser() ? '' : ('<div class="avatar">' + esc(pl.emoji || '🤖') + '</div>');
  el.innerHTML =
    av +
    '<div class="body">' +""",
    'wwSpeakBubble ref+avatar')

rep("""function wwStatus(s) { const e = $("#wwStatus"); if (e) e.textContent = s || ""; }""",
"""function wwStatus(s) { const e = wwStatusEl(); if (e) e.textContent = s || ""; }""",
    'wwStatus ref')

rep("""function wwGod(title, text) { if (state.wwGodView !== false) wwAdd('night', title, text); }""",
"""function wwGod(title, text) { if (wwIsUser()) return; if (state.wwGodView !== false) wwAdd('night', title, text); }""",
    'wwGod suppress(usermode)')

# ================= E. chips 渲染（用户模式不显示职业/头像） =================
rep("""  // 开局中：上帝视角，一开局就贴上身份标签
  ww.players.forEach(function (p, i) {
    let cls = p.alive ? '' : 'dead';
    if (p.role === '狼人') cls += ' wolf';
    else if (p.role !== '村民') cls += ' spec';
    const tag = (WW_ROLE_EMOJI[p.role] || '') + p.role + (p.alive ? '' : ' ☠');
    box.appendChild(mkTile(i + 1, p.name, tag, cls, true));
  });""",
"""  // 用户模式：只显示号码 + 存活状态，不显示头像 / 职业
  if (wwIsUser()) {
    ww.players.forEach(function (p) {
      const cls = p.alive ? '' : 'dead';
      const tag = p.alive ? '' : '☠';
      const t = mkTile(p.num, p.isUser ? '你' : '', tag, cls, true);
      if (p.isUser) t.classList.add('ready');
      box.appendChild(t);
    });
    uwwRenderIdentity();
    uwwPriv();
    return;
  }

  // 开局中：上帝视角，一开局就贴上身份标签
  ww.players.forEach(function (p, i) {
    let cls = p.alive ? '' : 'dead';
    if (p.role === '狼人') cls += ' wolf';
    else if (p.role !== '村民') cls += ' spec';
    const tag = (WW_ROLE_EMOJI[p.role] || '') + p.role + (p.alive ? '' : ' ☠');
    box.appendChild(mkTile(i + 1, p.name, tag, cls, true));
  });""",
    'chips user mode')

# ================= F. 真相行标注「你」 =================
rep("""function wwTruthLine(p) {
  const head = p.name + '：' + (WW_ROLE_EMOJI[p.role] || '') + p.role;
  if (p.alive) return head + '（存活到最后）';
  const why = p.deathReason || '出局';
  const d = p.deathDay ? ('第' + p.deathDay + '天 ' + why) : why;
  return head + '（' + d + '）';
}""",
"""function wwTruthLine(p) {
  const head = p.name + '：' + (WW_ROLE_EMOJI[p.role] || '') + p.role;
  const me = p.isUser ? '（你）' : '';
  if (p.alive) return head + '（存活到最后）' + me;
  const why = p.deathReason || '出局';
  const d = p.deathDay ? ('第' + p.deathDay + '天 ' + why) : why;
  return head + '（' + d + '）' + me;
}""",
    'truth line me')

# ================= G. 夜晚：狼人挂钩 =================
rep("""      if (!pool.length) break;
      let think = '';
      let pick = null;
      const roundTxt = (ww.day <= 1)""",
"""      if (!pool.length) break;
      let think = '';
      let pick = null;
      if (w.isUser) {
        const un = await uwwPick('🌙 你是狼人，今晚要刀谁？（队友会一起决定）', pool);
        if (!ww.running) return null;
        if (!un) continue;
        pick = wwByName(un);
        if (pick) {
          proposals.push(w.name + ' 想杀 ' + pick.name);
          tally[pick.name] = (tally[pick.name] || 0) + 1;
          wwNote(w, '第' + ww.day + '夜，我提议杀 ' + pick.name + '。');
        }
        uwwPriv();
        continue;
      }
      const roundTxt = (ww.day <= 1)""",
    'night wolf user')

# ================= H. 夜晚：预言家挂钩 =================
rep("""    const pool = wwAlive().filter(function (p) { return p.name !== s.name; });
    if (!pool.length) continue;
    let think = '';
    let tgt = null;
    try {""",
"""    const pool = wwAlive().filter(function (p) { return p.name !== s.name; });
    if (!pool.length) continue;
    if (s.isUser) {
      const un = await uwwPick('🔮 你是预言家，今晚查验谁？', pool);
      if (!ww.running) return null;
      const ut = un ? wwByName(un) : null;
      if (ut) {
        const isWolf = ut.role === '狼人';
        wwNote(s, '第' + ww.day + '夜，我查验了 ' + ut.name + '，结果是【' + (isWolf ? '狼人' : '好人') + '】。');
        uwwPriv();
      }
      continue;
    }
    let think = '';
    let tgt = null;
    try {""",
    'night seer user')

# ================= I. 夜晚：女巫挂钩 =================
rep("""    if (ww.healUsed && ww.poisonUsed) {
      wwNote(wi, '第' + ww.day + '夜，我的两瓶药都用完了。');
      continue;
    }
    const info = nightKill ? ('今晚被狼人袭击的是：' + nightKill.name) : '今晚无人被狼人袭击';""",
"""    if (ww.healUsed && ww.poisonUsed) {
      wwNote(wi, '第' + ww.day + '夜，我的两瓶药都用完了。');
      continue;
    }
    if (wi.isUser) {
      const opts = [];
      if (!ww.healUsed && nightKill) opts.push({ label: '🧪 用解药救 ' + nightKill.name, value: 'heal', primary: true });
      if (!ww.poisonUsed) opts.push({ label: '☠ 用毒药', value: 'poison' });
      opts.push({ label: '不用', value: 'none' });
      const c = await uwwChoose('🧪 你是女巫 · ' + (nightKill ? ('今晚 ' + nightKill.name + ' 被袭') : '今晚平安') + ' · 解药' + (ww.healUsed ? '已用完' : '有') + ' · 毒药' + (ww.poisonUsed ? '已用完' : '有'), opts);
      if (!ww.running) return null;
      if (c && c.type === 'choice' && c.value === 'heal') {
        ww.healUsed = true; healed = true;
        wwNote(wi, '第' + ww.day + '夜，我用解药救了 ' + nightKill.name + '。');
      } else if (c && c.type === 'choice' && c.value === 'poison') {
        const pt = wwAlive().filter(function (p) { return p.name !== wi.name; });
        const pn = await uwwPick('☠ 毒谁？', pt);
        if (!ww.running) return null;
        const ut = pn ? wwByName(pn) : null;
        if (ut) { ww.poisonUsed = true; poisoned = ut; wwNote(wi, '第' + ww.day + '夜，我用毒药毒了 ' + ut.name + '。'); }
      } else if (!ww.running) {
        return null;
      } else {
        wwNote(wi, '第' + ww.day + '夜，我没有用药。');
      }
      uwwPriv();
      continue;
    }
    const info = nightKill ? ('今晚被狼人袭击的是：' + nightKill.name) : '今晚无人被狼人袭击';""",
    'night witch user')

# ================= J. 白天发言挂钩 =================
rep("""      const label = '第' + ww.day + '天' + (rounds > 1 ? (' 第' + r + ' 轮') : '') + ' 发言';
      wwStatus('☀️ 第 ' + ww.day + ' 天 · ' + sp.name + ' 发言中');
      const node = wwSpeakBubble(sp, label);""",
"""      const label = '第' + ww.day + '天' + (rounds > 1 ? (' 第' + r + ' 轮') : '') + ' 发言';
      if (sp.isUser) {
        wwStatus('☀️ 第 ' + ww.day + ' 天 · 轮到你发言');
        const unode = wwSpeakBubble(sp, label);
        const res = await uwwAskInput('轮到你发言（' + label + '）：说点什么…');
        if (!ww.running || !res || res.type !== 'text') return;
        const utxt = String(res.value || '').trim();
        if (unode && unode.content) unode.content.textContent = utxt;
        wwPub(sp.name + '（' + label + '）：' + utxt);
        continue;
      }
      wwStatus('☀️ 第 ' + ww.day + ' 天 · ' + sp.name + ' 发言中');
      const node = wwSpeakBubble(sp, label);""",
    'day speech user')

# ================= K. 投票挂钩 + 隐藏他人逐条投票 =================
rep("""    const v = voters[i];
    const pool = wwAlive().filter(function (p) { return p.name !== v.name; });
    if (!pool.length) break;""",
"""    const v = voters[i];
    const pool = wwAlive().filter(function (p) { return p.name !== v.name; });
    if (!pool.length) break;
    if (v.isUser) {
      const un = await uwwPick('🗳 轮到你投票（第 ' + ww.day + ' 天）：投谁出局？', pool);
      if (!ww.running) return;
      const up = un ? wwByName(un) : null;
      if (up) {
        tally[up.name] = (tally[up.name] || 0) + 1;
        detail.push(v.name + ' → ' + up.name);
        wwAdd('vote', '🗳 你投给', up.name);
      }
      continue;
    }""",
    'vote user')

rep("""    wwAdd('vote', '🗳 ' + v.name + ' 投给', pick.name + thinkLine(think));""",
"""    if (!wwIsUser()) wwAdd('vote', '🗳 ' + v.name + ' 投给', pick.name + thinkLine(think));""",
    'vote hide AI detail in usermode')

# ================= L. 猎人开枪挂钩 =================
rep("""  const pool = wwAlive();
  if (!pool.length) return;
  let ans = '';""",
"""  const pool = wwAlive();
  if (!pool.length) return;
  if (out.isUser) {
    const un = await uwwPick('🔫 你是猎人，开枪带走谁？', pool);
    if (!ww.running) return;
    const shot = un ? wwByName(un) : null;
    if (shot) {
      wwSys('🔫 猎人开枪', out.name + ' 亮出猎人身份，开枪带走了 ' + shot.name);
      wwPub(out.name + ' 是猎人，开枪带走了 ' + shot.name + '。');
      await wwKill(shot, '猎人开枪');
    }
    return;
  }
  let ans = '';""",
    'hunter user')

# ================= M. 闸门（用户模式无需手动闸门） =================
rep("""function wwHideGate() {
  const btn = $("#wwGateBtn");""",
"""function wwHideGate() {
  const btn = wwGateEl();""",
    'hideGate ref')

rep("""function wwGateNext(label) {
  if (!ww || !ww.running) { wwHideGate(); return Promise.resolve(); }
  if (state.wwAuto === true) { wwHideGate(); return Promise.resolve(); }
  const btn = $("#wwGateBtn");""",
"""function wwGateNext(label) {
  if (!ww || !ww.running) { wwHideGate(); return Promise.resolve(); }
  if (wwIsUser()) { wwHideGate(); return Promise.resolve(); }
  if (state.wwAuto === true) { wwHideGate(); return Promise.resolve(); }
  const btn = wwGateEl();""",
    'gateNext user bypass')

# ================= N. wwStart / wwStop 按钮模式化 =================
rep("""  $("#btnWwStart").disabled = true;
  $("#btnWwStop").disabled = false;""",
"""  wwBtn('Start').disabled = true;
  wwBtn('Stop').disabled = false;""",
    'wwStart buttons')

rep("""  ww.running = false;
  wwGateResolve = null;
  wwHideGate();
  $("#btnWwStart").disabled = false;
  $("#btnWwStop").disabled = true;
  wwStatus(ww.winner ? ('🏆 ' + ww.winner) : '已停止');
}""",
"""  ww.running = false;
  wwGateResolve = null;
  wwHideGate();
  wwBtn('Start').disabled = false;
  wwBtn('Stop').disabled = true;
  if (wwIsUser()) uwwRevealRoles();
  wwStatus(ww.winner ? ('🏆 ' + ww.winner) : '已停止');
}""",
    'wwStart tail')

rep("""function wwStop() {
  if (!ww || !ww.running) return;
  ww.running = false;
  wwReleaseGate();
  try { if (ww.abort) ww.abort.abort(); } catch (e) {}
  $("#btnWwStart").disabled = false;
  $("#btnWwStop").disabled = true;
  wwStatus('⏹ 已停止');
  wwSys('已停止', '本局中断');
}""",
"""function wwStop() {
  if (!ww || !ww.running) return;
  ww.running = false;
  wwReleaseGate();
  uwwAbort();
  try { if (ww.abort) ww.abort.abort(); } catch (e) {}
  wwBtn('Start').disabled = false;
  wwBtn('Stop').disabled = true;
  if (wwIsUser()) uwwRevealRoles();
  wwStatus('⏹ 已停止');
  wwSys('已停止', '本局中断');
}""",
    'wwStop ref')

# ================= O. 盘后总结跳过用户 =================
rep("""    const p = ww.players[i];
    const recap = ww.pub.slice(-30).join('\\n');""",
"""    const p = ww.players[i];
    if (p.isUser) continue;
    const recap = ww.pub.slice(-30).join('\\n');""",
    'postgame skip user A')

rep("""    const p = ww.players[i];
    const seen = postLog.join('\\n');""",
"""    const p = ww.players[i];
    if (p.isUser) continue;
    const seen = postLog.join('\\n');""",
    'postgame skip user B')

# ================= P. switchView 增加 userww =================
rep("""  ["werewolf", "config"].forEach(function (n) {""",
"""  ["werewolf", "userww", "config"].forEach(function (n) {""",
    'switchView array')

# ================= Q. uwwStart 引擎 =================
rep("""/* ---------- 绑定 ---------- */
function initWerewolf() {""",
"""/* ---------- 用户狼人杀：开局 ---------- */
async function uwwStart() {
  if (ww && ww.running) { toast('本局还在进行中，先停止或打完'); return; }
  const ps = state.participants.filter(function (p) { return p.enabled; });
  if (ps.length < 4) { toast('用户狼人杀至少需要 4 位已启用的 AI 选手（你 + AI 共 5 人起），当前 ' + ps.length + ' 位'); switchView('config'); return; }
  let bad = null;
  for (let i = 0; i < ps.length; i++) {
    if (!String(ps[i].endpoint || '').trim() || !String(ps[i].model || '').trim()) { bad = ps[i]; break; }
  }
  if (bad) { toast('AI 选手「' + bad.name + '」还没填接口地址或模型名'); switchView('config'); return; }

  const total = ps.length + 1;
  const nums = [];
  for (let i = 1; i <= total; i++) nums.push(i);
  wwShuffle(nums);
  const plan = wwRolePlan(total);
  const roles = [];
  plan.forEach(function (pair) { for (let k = 0; k < pair[1]; k++) roles.push(pair[0]); });
  wwShuffle(roles);

  const userPlayer = { id: 'USER', num: nums[0], name: nums[0] + '号', emoji: '', role: roles[0], alive: true, notes: [], cfg: null, isUser: true };
  const players = [userPlayer];
  for (let i = 0; i < ps.length; i++) {
    players.push({ id: ps[i].id, num: nums[i + 1], name: nums[i + 1] + '号', emoji: '', role: roles[i + 1], alive: true, notes: [], cfg: ps[i], isUser: false });
  }
  players.sort(function (a, b) { return a.num - b.num; });

  ww = {
    players: players, pub: [], day: 0, running: true, winner: null,
    healUsed: false, poisonUsed: false, abort: new AbortController(),
    userMode: true, userPlayer: userPlayer
  };

  switchView('userww');
  uwwResetUI();
  const rEl = document.getElementById('uwwRoles');
  if (rEl) { rEl.hidden = false; rEl.innerHTML = '🔒 身份分配将在本局结束后揭晓（用于对局后核对身份）。'; }
  wwRenderChips();
  wwAdd('sys', '🆕 新一局开始', '共 ' + total + ' 人 · 最多 ' + (Number(state.wwMaxDays) || 10) + ' 天。你扮演 ' + userPlayer.name + '。天黑请闭眼…');
  wwBtn('Start').disabled = true;
  wwBtn('Stop').disabled = false;

  await wwRun();

  if (ww.running && state.wwPostSummary !== false) { await wwPostGame(); }

  ww.running = false;
  uwwAbort();
  uwwRevealRoles();
  wwBtn('Start').disabled = false;
  wwBtn('Stop').disabled = true;
  wwStatus(ww.winner ? ('🏆 ' + ww.winner) : '已停止');
}

/* ---------- 绑定 ---------- */
function initWerewolf() {""",
    'uwwStart')

# ================= R. 绑定用户狼人杀控件 =================
rep("""  b = $("#tab-werewolf");
  if (b) b.addEventListener("click", function () { switchView('werewolf'); wwRenderPreview(); });""",
"""  b = $("#tab-werewolf");
  if (b) b.addEventListener("click", function () { switchView('werewolf'); wwRenderPreview(); });
  b = $("#tab-userww");
  if (b) b.addEventListener("click", function () { switchView('userww'); });
  b = $("#btnUwwStart");
  if (b) b.addEventListener("click", uwwStart);
  b = $("#btnUwwStop");
  if (b) b.addEventListener("click", wwStop);
  b = $("#btnUwwClear");
  if (b) b.addEventListener("click", function () {
    if (ww && ww.running) { toast('先停止再清空'); return; }
    ww = null;
    const t = document.getElementById('uwwTranscript');
    if (t) t.innerHTML = '<p class="empty">点「开始新一局」参战。</p>';
    const c = document.getElementById('uwwChips');
    if (c) c.innerHTML = '';
    const id = document.getElementById('uwwIdentity');
    if (id) id.textContent = '你还没有参战。点「开始新一局」，随机分配号码后你会扮演其中一名玩家。';
    const rl = document.getElementById('uwwRoles');
    if (rl) { rl.hidden = true; rl.innerHTML = ''; }
    uwwResetUI();
  });
  b = document.getElementById("uwwSend");
  if (b) b.addEventListener("click", uwwSendNow);
  b = document.getElementById("uwwInput");
  if (b) b.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); uwwSendNow(); }
  });""",
    'bind userww')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处修改，文件 %d 字符' % (n, len(src)))