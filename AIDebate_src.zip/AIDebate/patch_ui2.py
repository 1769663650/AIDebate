#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 1. 上帝视角：一开局就给每个方格贴上身份标签（不再等死了才显示）
# 2. 方格缩小、狼人杀信息区高度压缩，少挡屏
# 3. 顶栏 / 工具栏 / 按钮整体收紧
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)
n = 0
def rep(old, new, tag):
    global src, n
    if old in src:
        src = src.replace(old, new, 1); n += 1
    else:
        print('   !! 未命中：' + tag)

# ---- 1. 开局即显示身份 ----
rep(
"""  // 开局中：显示存活状态与身份
  ww.players.forEach(function (p, i) {
    const reveal = !p.alive || !!ww.winner;
    let cls = p.alive ? '' : 'dead';
    if (reveal && p.role === '狼人') cls += ' wolf';
    else if (reveal && p.role !== '村民') cls += ' spec';
    let tag;
    if (reveal) tag = (WW_ROLE_EMOJI[p.role] || '') + p.role;
    else tag = '存活';
    box.appendChild(mkTile(i + 1, p.name, tag, cls, true));
  });""",
"""  // 开局中：上帝视角，一开局就贴上身份标签
  ww.players.forEach(function (p, i) {
    let cls = p.alive ? '' : 'dead';
    if (p.role === '狼人') cls += ' wolf';
    else if (p.role !== '村民') cls += ' spec';
    const tag = (WW_ROLE_EMOJI[p.role] || '') + p.role + (p.alive ? '' : ' ☠');
    box.appendChild(mkTile(i + 1, p.name, tag, cls, true));
  });""",
"开局即显示身份")

# ---- 2. 顶栏收紧 ----
rep(
"  padding:calc(12px + env(safe-area-inset-top)) 12px 12px;",
"  padding:calc(6px + env(safe-area-inset-top)) 10px 6px;",
"顶栏内边距")

# ---- 3. 工具栏（狼人杀顶部那块）收紧 ----
rep(
""".bar{
  flex:0 0 auto;display:flex;flex-direction:column;gap:8px;
  padding:10px 12px;background:var(--panel);border-bottom:1px solid var(--line);
}""",
""".bar{
  flex:0 0 auto;display:flex;flex-direction:column;gap:6px;
  padding:6px 10px;background:var(--panel);border-bottom:1px solid var(--line);
}""",
"工具栏内边距")

# ---- 4. 按钮整体缩小一点 ----
rep(
"  border-radius:10px;padding:9px 14px;font-size:14px;font-weight:600;font-family:inherit;",
"  border-radius:9px;padding:6px 11px;font-size:13px;font-weight:600;font-family:inherit;",
"按钮尺寸")

# ---- 5. 狼人杀信息区（chips）压缩 ----
rep(
""".wwchips{display:grid;grid-template-columns:repeat(auto-fill,minmax(64px,1fr));gap:8px;
  padding:10px 12px;background:var(--panel);border-bottom:1px solid var(--line);
  flex:0 0 auto;max-height:36vh;overflow-y:auto}""",
""".wwchips{display:grid;grid-template-columns:repeat(auto-fill,minmax(46px,1fr));gap:6px;
  padding:6px 8px;background:var(--panel);border-bottom:1px solid var(--line);
  flex:0 0 auto;max-height:20vh;overflow-y:auto}""",
"chips 压缩")

# ---- 6. 方格缩小 ----
rep(
".pgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(64px,1fr));gap:8px}",
".pgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(52px,1fr));gap:6px}",
"pgrid 缩小")

rep(
""".ptile{position:relative;min-height:64px;border-radius:14px;background:var(--panel2);
  border:2px solid var(--line);display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:1px;padding:6px 4px;overflow:hidden}""",
""".ptile{position:relative;min-height:44px;border-radius:10px;background:var(--panel2);
  border:2px solid var(--line);display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:0;padding:3px 3px;overflow:hidden}""",
"ptile 缩小")

rep(
".ptile .num{font-size:24px;font-weight:800;line-height:1.05;color:var(--dim)}",
".ptile .num{font-size:16px;font-weight:800;line-height:1.05;color:var(--dim)}",
"编号字号")

rep(
""".ptile .nm{width:100%;text-align:center;font-size:10.5px;color:var(--dim);
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}""",
""".ptile .nm{width:100%;text-align:center;font-size:9px;line-height:1.15;color:var(--dim);
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}""",
"名字字号")

rep(
".ptile .st{font-size:10px;color:var(--dim);white-space:nowrap}",
".ptile .st{font-size:9px;line-height:1.15;color:var(--dim);white-space:nowrap}",
"标签字号")

rep(
""".ptile .dot{position:absolute;top:5px;right:5px;width:7px;height:7px;border-radius:50%;background:#6b2b38}""",
""".ptile .dot{position:absolute;top:3px;right:3px;width:6px;height:6px;border-radius:50%;background:#6b2b38}""",
"状态点")

io.open(P, 'w', encoding='utf-8').write(src)
print('命中 %d/10 段，文件大小 %d -> %d' % (n, before, len(src)))
if n < 10:
    sys.exit(1)