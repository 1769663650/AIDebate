#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 白天发言改成「【思考】/【发言】」两段：
#   ·【思考】只灰字显示给你看，绝不进公共信息
#   ·【发言】才是公开内容
#   · 模型没按格式写时，整段当发言兜底
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)
n = 0
def rep(old, new, tag):
    global src, n
    if old in src:
        src = src.replace(old, new, 1); n += 1
    else:
        print('   !! 未命中：' + tag)

# ---- 1. 发言提示词：两段格式 ----
rep(
"  return '【白天讨论】\\n现在是第 ' + ww.day + ' 天。\\n请发表你的发言：陈述身份、指认你认为的狼人、反驳别人、拉票都可以。\\n控制在 200 字以内。只输出你要说的话本身，不要加名字前缀，不要写括号动作。';",
"""  return '【白天讨论】\\n现在是第 ' + ww.day + ' 天。\\n请严格按下面两段格式输出，不要有多余内容：\\n【思考】这里写你真实的内心想法——只有你自己能看到，不会被公开。\\n【发言】这里写你当众对大家说的话：陈述身份、指认狼人、反驳别人、拉票都可以，控制在 200 字以内，不要加名字前缀，不要写括号动作。\\n记住：其他玩家只能看到【发言】那一段。';""",
"发言两段格式")

# ---- 2. 新增分段解析 + 发言执行 ----
rep(
"async function wwDaySpeeches() {",
"""function wwSplitSpeech(raw) {
  const t = String(raw || '');
  let think = '', text = t.trim();
  const mi = t.indexOf('【发言】');
  if (mi >= 0) {
    text = t.slice(mi + 4).trim();
    const th = t.slice(0, mi);
    const ti = th.indexOf('【思考】');
    think = (ti >= 0 ? th.slice(ti + 4) : th).trim();
  } else {
    const mi2 = t.indexOf('发言：');
    if (mi2 >= 0) {
      text = t.slice(mi2 + 3).trim();
      const th = t.slice(0, mi2);
      const ti2 = th.indexOf('思考：');
      think = (ti2 >= 0 ? th.slice(ti2 + 3) : th).trim();
    }
  }
  return { think: think, text: text };
}

async function wwSpeechRun(pl, node) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: 0 });
  let raw = '';
  await callModel(cfg, wwContext(pl, wwSpeechPrompt(pl)), function (d) {
    if (d.think) raw += d.think;
    if (d.text) raw += d.text;
    const s = wwSplitSpeech(raw);
    if (node) {
      if (node.think && state.wwShowThink && s.think) { node.think.hidden = false; node.think.textContent = s.think; }
      if (node.content) node.content.textContent = s.text;
    }
    wwScroll();
  }, ww.abort ? ww.abort.signal : null);
  return wwSplitSpeech(raw);
}

async function wwDaySpeeches() {""",
"分段解析函数")

# ---- 3. 白天发言：用两段解析 ----
rep(
"""      const node = wwSpeakBubble(sp, label);
      let txt = '';
      try {
        txt = await wwAskStream(sp, wwSpeechPrompt(sp), node, 0);
        if (!txt) {
          wwStatus('☀️ 第 ' + ww.day + ' 天 · ' + sp.name + ' 重新组织发言…');
          txt = await wwSpeechRetry(sp, 0);
        }
      } catch (e) {
        if (e && e.name === 'AbortError') return;
        node.el.classList.add('err');
        node.content.textContent = '⚠️ ' + (e && e.message ? e.message : e);
        continue;
      }
      if (txt) {
        if (node && node.content) node.content.textContent = txt;
        wwPub(sp.name + '（' + label + '）：' + txt);
      } else {
        node.el.classList.add('err');
        node.content.textContent = '（模型始终只给思考、没给正式发言。请把该选手的「最大输出」调大，或把模型名换成非推理模型再试。）';
      }""",
"""      const node = wwSpeakBubble(sp, label);
      let txt = '';
      try {
        const r = await wwSpeechRun(sp, node);
        txt = r.text;
        if (!txt) {
          wwStatus('☀️ 第 ' + ww.day + ' 天 · ' + sp.name + ' 重新组织发言…');
          txt = wwSplitSpeech(await wwSpeechRetry(sp, 0)).text;
        }
      } catch (e) {
        if (e && e.name === 'AbortError') return;
        node.el.classList.add('err');
        node.content.textContent = '⚠️ ' + (e && e.message ? e.message : e);
        continue;
      }
      if (txt) {
        if (node && node.content) node.content.textContent = txt;
        wwPub(sp.name + '（' + label + '）：' + txt);
      } else {
        node.el.classList.add('err');
        node.content.textContent = '（模型没给出发言内容。请检查该选手的接口/模型名是否可用。）';
      }""",
"白天发言用两段")

io.open(P, 'w', encoding='utf-8').write(src)
print('命中 %d/3 段，文件大小 %d -> %d' % (n, before, len(src)))
if n < 3:
    sys.exit(1)