#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 修复「发言有标题没正文」：
#   1. 兼容「忽略 stream 参数、直接返回整段 JSON」的接口
#   2. 推理模型：content 为空时回落到 reasoning_content
#   3. 白天发言若确实拿到空内容，显示可见提示（不再静默空白）
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)

OLD = '''  const reader = res.body.getReader();
  const dec = new TextDecoder("utf-8");
  let buf = "", full = "";

  while (true) {
    const r = await reader.read();
    if (r.done) break;
    buf += dec.decode(r.value, { stream: true });

    let i;
    while ((i = buf.indexOf("\\n")) >= 0) {
      const line = buf.slice(0, i).replace(/\\r$/, "");
      buf = buf.slice(i + 1);
      if (line.slice(0, 5) !== "data:") continue;
      const d = line.slice(5).trim();
      if (!d || d === "[DONE]") continue;

      let j; try { j = JSON.parse(d); } catch (e) { continue; }
      const ch = j.choices && j.choices[0];
      if (!ch) continue;
      const dl = ch.delta || ch.message || {};
      if (dl.reasoning_content) onDelta({ think: dl.reasoning_content });
      if (typeof dl.content === "string" && dl.content) {
        full += dl.content;
        onDelta({ text: dl.content });
      }
    }
  }
  return full;
}'''

NEW = '''  const reader = res.body.getReader();
  const dec = new TextDecoder("utf-8");
  let buf = "", full = "", raw = "", thinkAll = "";

  while (true) {
    const r = await reader.read();
    if (r.done) break;
    const chunk = dec.decode(r.value, { stream: true });
    raw += chunk;
    buf += chunk;

    let i;
    while ((i = buf.indexOf("\\n")) >= 0) {
      const line = buf.slice(0, i).replace(/\\r$/, "");
      buf = buf.slice(i + 1);
      const s = line.trim();
      if (!s) continue;

      let payload = null;
      if (s.slice(0, 5) === "data:") {
        const d = s.slice(5).trim();
        if (!d || d === "[DONE]") continue;
        payload = d;
      } else if (s.charAt(0) === "{") {
        payload = s;
      } else {
        continue;
      }

      let j; try { j = JSON.parse(payload); } catch (e) { continue; }
      if (j.error) throw new Error("接口返回错误：" + JSON.stringify(j.error).slice(0, 200));
      const ch = j.choices && j.choices[0];
      if (!ch) continue;
      const dl = ch.delta || ch.message || {};
      if (dl.reasoning_content) { thinkAll += dl.reasoning_content; onDelta({ think: dl.reasoning_content }); }
      if (typeof dl.content === "string" && dl.content) {
        full += dl.content;
        onDelta({ text: dl.content });
      }
    }
  }

  // 兜底一：整段不是 SSE，或一行都没解析出正文 —— 按普通 JSON 再解析一次
  if (!full) {
    const trimmed = raw.trim().replace(/^data:\\s*/, "");
    let j = null;
    try { j = JSON.parse(trimmed); } catch (e) {}
    if (j) {
      if (j.error) throw new Error("接口返回错误：" + JSON.stringify(j.error).slice(0, 200));
      const m = j.choices && j.choices[0] && (j.choices[0].message || j.choices[0].delta);
      const c = m && (m.content || m.reasoning_content);
      if (c) { full = c; onDelta({ text: c }); }
    }
  }

  // 兜底二：正文为空但有思考过程 —— 把思考过程当作正文展示，避免空白
  if (!full && thinkAll) { full = thinkAll; onDelta({ text: thinkAll }); }

  return full;
}'''

if OLD not in src:
    print('!! 未找到目标代码块，未修改')
    sys.exit(1)
src = src.replace(OLD, NEW, 1)

# 非流式兜底里也补上 reasoning_content
OLD2 = '''    const c = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || "";'''
NEW2 = '''    const _m = j.choices && j.choices[0] && j.choices[0].message;
    const c = (_m && (_m.content || _m.reasoning_content)) || "";'''
if OLD2 in src:
    src = src.replace(OLD2, NEW2, 1)
else:
    print('   (提示) 未找到非流式兜底行，跳过')

# 白天发言：空内容给出可见提示
OLD3 = '''      if (txt) wwPub(sp.name + '（' + label + '）：' + txt);'''
NEW3 = '''      if (txt) {
        wwPub(sp.name + '（' + label + '）：' + txt);
      } else {
        node.el.classList.add('err');
        node.content.textContent = '（模型返回了空内容。请检查：接口地址是否到 /v1 为止、模型名是否正确、Key 是否有额度）';
      }'''
if OLD3 in src:
    src = src.replace(OLD3, NEW3, 1)
else:
    print('   (提示) 未找到发言写入行，跳过')

io.open(P, 'w', encoding='utf-8').write(src)
print('文件大小 %d -> %d' % (before, len(src)))
