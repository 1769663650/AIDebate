#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 让 AI 会玩一点：
#   1. 狼人：加夜晚策略（首夜随机；之后优先刀跳预言家/带队的人）
#   2. 狼人：夜里后发言的狼能看到队友提议，便于跟票统一意见
#   3. 狼人：白天投票候选排除狼人（不再投同伙）
#   4. 预言家：改成谨慎跳身份
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)
n = 0
def rep(old, new, tag):
    global src, n
    if old in src:
        src = src.replace(old, new, 1); n += 1
    else:
        print('   !! 未命中：' + tag)

# ---- 1. 狼人 brief 加夜晚策略 ----
rep(
"    '\\n【铁律】你和狼队友是一伙的。任何情况下都不得选择击杀或投票淘汰狼队友，必须保护他们。';",
"    '\\n【铁律】你和狼队友是一伙的。任何情况下都不得选择击杀或投票淘汰狼队友，必须保护他们。' +\n"
"    '\\n【夜晚策略】第 1 晚没有任何信息，随便杀一个好人即可。从第 2 晚起，务必回顾公共信息：谁自称预言家、谁在带队指认，就优先刀掉威胁最大的那个——不要总挑沉默的平民。';",
"狼人策略")

# ---- 2. 预言家 brief 改成谨慎 ----
rep(
"    return '【你的身份：预言家】\\n每晚可以查验一名玩家的真实身份（狼人 / 好人）。\\n白天要让好人相信你，同时提防狼人反咬你是假预言家。';",
"    return '【你的身份：预言家】\\n每晚可以查验一名玩家的真实身份（狼人 / 好人）。\\n【策略】不要第一晚就急着跳身份——太早暴露，当晚就会被狼刀死。\\n正确做法：先用查验结果观察和带节奏；等到你握有【查杀】，或者场上已经有人跳预言家、需要你对跳时，再亮身份并把查验结果报出来。';",
"预言家谨慎")

# ---- 3. 狼人夜晚：队友提议可参考 + 首夜/后续策略 ----
rep(
"""      let pool = wwAlive().filter(function (p) { return p.role !== '狼人'; });
      if (!pool.length) pool = wwAlive().filter(function (p) { return p.name !== w.name; });
      if (!pool.length) break;
      let ans = '';
      try {
        ans = await wwAsk(w, '【夜晚 · 狼人行动】\\n现在是第 ' + ww.day + ' 个夜晚。\\n请选择今晚要击杀的玩家。\\n只回复一个玩家名字，不要任何解释。\\n可选：' + wwNames(pool), 30);
      } catch (e) {
        if (e && e.name === 'AbortError') return null;
        wwNote(w, '第' + ww.day + '夜：我提议杀谁时出错了。');
      }
      const pick = wwPick(ans, pool) || wwRand(pool);
      tally[pick.name] = (tally[pick.name] || 0) + 1;
      wwGod('🐺 ' + w.name + ' 提议击杀', pick.name);""",
"""      let pool = wwAlive().filter(function (p) { return p.role !== '狼人'; });
      if (!pool.length) pool = wwAlive().filter(function (p) { return p.name !== w.name; });
      if (!pool.length) break;
      let ans = '';
      const roundTxt = (ww.day <= 1)
        ? '这是第 1 晚，还没有任何信息，随便杀一个好人即可（不要杀狼队友）。'
        : '请先回顾上面的【公共信息】：有没有人自称预言家、有没有人拿到查验结果在带队？优先杀掉对你威胁最大的那个（尤其是跳预言家的），不要只挑沉默的平民。';
      const propTxt = proposals.length
        ? ('\\n你的狼队友今晚已经提议杀：' + proposals.join('、') + '。你可以跟票，也可以另选目标。')
        : '';
      try {
        ans = await wwAsk(w, '【夜晚 · 狼人行动】\\n现在是第 ' + ww.day + ' 个夜晚。\\n' + roundTxt + propTxt + '\\n请选择今晚要击杀的玩家，只回复一个玩家名字，不要任何解释。\\n可选：' + wwNames(pool), 60);
      } catch (e) {
        if (e && e.name === 'AbortError') return null;
        wwNote(w, '第' + ww.day + '夜：我提议杀谁时出错了。');
      }
      const pick = wwPick(ans, pool) || wwRand(pool);
      proposals.push(pick.name);
      tally[pick.name] = (tally[pick.name] || 0) + 1;
      wwGod('🐺 ' + w.name + ' 提议击杀', pick.name);""",
"狼人夜晚策略")

# ---- 4. 狼人夜晚：声明 proposals 数组 ----
rep(
"    const tally = {};\n    for (let i = 0; i < wolves.length; i++) {",
"    const tally = {};\n    const proposals = [];\n    for (let i = 0; i < wolves.length; i++) {",
"proposals 数组")

# ---- 5. 白天投票：狼人的候选排除狼人 ----
rep(
"""    const pool = wwAlive().filter(function (p) { return p.name !== v.name; });
    if (!pool.length) break;""",
"""    let pool = wwAlive().filter(function (p) { return p.name !== v.name; });
    if (v.role === '狼人') pool = pool.filter(function (p) { return p.role !== '狼人'; });
    if (!pool.length) pool = wwAlive().filter(function (p) { return p.name !== v.name; });
    if (!pool.length) break;""",
"狼人投票排除同类")

io.open(P, 'w', encoding='utf-8').write(src)
print('命中 %d/5 段，文件大小 %d -> %d' % (n, before, len(src)))
if n < 5:
    sys.exit(1)