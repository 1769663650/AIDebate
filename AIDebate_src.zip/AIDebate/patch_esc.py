#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 index.html 里被写坏的 esc() 替换成一个不依赖 HTML 实体的实现。
原实现里的 """ 在写入时被解码成了裸双引号，导致整段 <script> 语法错误。
新实现用 String.fromCharCode 拼出实体，源码里不出现任何 & 开头的实体字面量。
"""
import sys

PATH = '/sdcard/Download/AIDebate/assets/index.html'

NEW = (
    "function esc(s) {\n"
    "  var A = String.fromCharCode(38);\n"
    "  var Q = String.fromCharCode(34);\n"
    "  if (s == null || s === undefined) return '';\n"
    "  return String(s).replace(/[&<>\"']/g, function (c) {\n"
    "    if (c === '&') return A + 'amp;';\n"
    "    if (c === '<') return A + 'lt;';\n"
    "    if (c === '>') return A + 'gt;';\n"
    "    if (c === Q) return A + 'quot;';\n"
    "    return A + '#39;';\n"
    "  });\n"
    "}\n"
)

src = open(PATH, encoding='utf-8').read()

i = src.find('const esc')
j = src.find('const uid')
if i < 0 or j < 0 or j < i:
    print('定位失败: i=%d j=%d' % (i, j))
    sys.exit(1)

out = src[:i] + NEW + src[j:]
open(PATH, 'w', encoding='utf-8').write(out)
print('已修补，文件大小 %d -> %d' % (len(src), len(out)))
