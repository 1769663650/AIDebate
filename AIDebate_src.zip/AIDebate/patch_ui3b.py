#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 1) 「开始投票」按钮不再备注天数；点完直接进入下一天（删掉「进入第 N 天」二次闸门）。
# 2) 压缩上半部分：header / .bar / .wwchips / .pgrid / .ptile。
# 3) 玩家框编号缩小并挪到右上角；状态小圆点挪到左上角避免重叠。

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, cnt=1):
    global src, n
    c = src.count(old)
    if c != cnt:
        print('[WARN] 命中 %d 次（期望 %d）：%r' % (c, cnt, old[:60]))
    src = src.replace(old, new)
    n += c

# ---- 1) 主循环：去掉二次闸门，简化按钮标签 ----
rep("    await wwGateNext('\u25b6 \u5f00\u59cb\u6295\u7968\uff08\u7b2c ' + ww.day + ' \u5929\uff09');",
    "    await wwGateNext('\u25b6 \u5f00\u59cb\u6295\u7968');")

rep("""    if (ww.day < maxDays) {
      await wwGateNext('\u25b6 \u8fdb\u5165\u7b2c ' + (ww.day + 1) + ' \u5929');
      if (!ww.running) break;
    }
""", "")

# ---- 2) 压缩 header ----
rep("padding:calc(6px + env(safe-area-inset-top)) 10px 6px;",
    "padding:calc(3px + env(safe-area-inset-top)) 8px 3px;")
rep("flex:0 0 auto;display:flex;align-items:center;gap:10px;",
    "flex:0 0 auto;display:flex;align-items:center;gap:8px;")
rep(".brand{flex:1;font-weight:700;font-size:16px;letter-spacing:.3px}",
    ".brand{flex:1;font-weight:700;font-size:15px;letter-spacing:.3px}")
rep("padding:6px 14px;border-radius:8px;font-size:14px;font-weight:600;font-family:inherit;",
    "padding:5px 12px;border-radius:8px;font-size:13px;font-weight:600;font-family:inherit;")

# ---- 3) 压缩 .bar ----
rep("""  flex:0 0 auto;display:flex;flex-direction:column;gap:6px;
  padding:6px 10px;background:var(--panel);border-bottom:1px solid var(--line);""",
    """  flex:0 0 auto;display:flex;flex-direction:column;gap:4px;
  padding:4px 8px;background:var(--panel);border-bottom:1px solid var(--line);""")
rep(".topicline{font-size:13px;color:var(--dim);word-break:break-word;line-height:1.45}",
    ".topicline{font-size:12px;color:var(--dim);word-break:break-word;line-height:1.4}")
rep(".bar-actions{display:flex;gap:8px;flex-wrap:wrap}",
    ".bar-actions{display:flex;gap:6px;flex-wrap:wrap}")

# ---- 4) 压缩 .wwchips ----
rep(""".wwchips{display:grid;grid-template-columns:repeat(auto-fill,minmax(46px,1fr));gap:6px;
  padding:6px 8px;background:var(--panel);border-bottom:1px solid var(--line);
  flex:0 0 auto;max-height:20vh;overflow-y:auto}""",
    """.wwchips{display:grid;grid-template-columns:repeat(auto-fill,minmax(40px,1fr));gap:4px;
  padding:4px 6px;background:var(--panel);border-bottom:1px solid var(--line);
  flex:0 0 auto;max-height:16vh;overflow-y:auto}""")
rep(".chip{font-size:12px;padding:3px 9px;border-radius:20px;background:var(--panel2);",
    ".chip{font-size:11px;padding:2px 8px;border-radius:20px;background:var(--panel2);")

# ---- 5) 压缩编号方格 ----
rep(".pgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(52px,1fr));gap:6px}",
    ".pgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(46px,1fr));gap:5px}")
rep(""".ptile{position:relative;min-height:44px;border-radius:10px;background:var(--panel2);
  border:2px solid var(--line);display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:0;padding:3px 3px;overflow:hidden}""",
    """.ptile{position:relative;min-height:38px;border-radius:9px;background:var(--panel2);
  border:2px solid var(--line);display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:0;padding:2px 3px;overflow:hidden}""")

# ---- 6) 编号挪到右上角并缩小 ----
rep(".ptile .num{font-size:16px;font-weight:800;line-height:1.05;color:var(--dim)}",
    ".ptile .num{position:absolute;top:1px;right:5px;font-size:10.5px;font-weight:800;line-height:1;color:var(--dim)}")

# ---- 7) 状态圆点挪到左上角 ----
rep(".ptile .dot{position:absolute;top:3px;right:3px;width:6px;height:6px;border-radius:50%;background:#6b2b38}",
    ".ptile .dot{position:absolute;top:3px;left:4px;width:6px;height:6px;border-radius:50%;background:#6b2b38}")

open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处替换，文件大小 %d -> %d' % (n, len(src) - len(src), len(src)))
