#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 本版三件事：
#  1. 修复「投票想法与行动不一致」：wwPick 做中文/阿拉伯数字归一化，
#     并优先匹配「投票：/决定：/查验：」等决策关键字之后出现的名字。
#  2. 新增「投票 / 下一天」暂停闸门：默认手动，点按钮才继续；
#     可在闸门里勾选「自动」切换为连续自动运行。
#  3. （提示词文档另由文档文件给出，不在本脚本内）
import io, sys

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
before = len(src)
n = 0

# ---------- 1) 替换 wwPick ----------
old_pick = """function wwPick(text, cands) {
  const t = String(text || '');
  let best = null, bi = -1;
  for (let i = 0; i < cands.length; i++) {
    const idx = t.lastIndexOf(cands[i].name);
    if (idx >= 0 && idx > bi) { bi = idx; best = cands[i]; }
  }
  return best;
}"""

new_pick = """/* 数字归一化：把中文数字转成阿拉伯数字（一~九十九），
   解决模型写「十二号」而选手名叫「12号」导致匹配失败的问题。 */
function wwCnNum(str) {
  const s = String(str == null ? '' : str);
  const d = { '零': 0, '一': 1, '二': 2, '两': 2, '三': 3, '四': 4,
              '五': 5, '六': 6, '七': 7, '八': 8, '九': 9 };
  return s.replace(/[零一二两三四五六七八九十]+/g, function (m) {
    if (m.indexOf('十') >= 0) {
      const i = m.indexOf('十');
      const head = m.slice(0, i), tail = m.slice(i + 1);
      const tens = head === '' ? 1 : (d[head] !== undefined ? d[head] : Number(head));
      const ones = tail === '' ? 0 : (d[tail] !== undefined ? d[tail] : Number(tail));
      if (isNaN(tens) || isNaN(ones)) return m;
      return String(tens * 10 + ones);
    }
    let out = '';
    for (let k = 0; k < m.length; k++) {
      const ch = m.charAt(k);
      out += (d[ch] !== undefined ? String(d[ch]) : ch);
    }
    return out;
  });
}
/* 在文本里找名字（取最后出现的位置），并避免「1号」误命中「11号」里面。 */
function wwFindIdx(t, name) {
  if (!name) return -1;
  let pos = t.length;
  for (let guard = 0; guard < 500; guard++) {
    const idx = t.lastIndexOf(name, pos - 1);
    if (idx < 0) return -1;
    const pre = idx > 0 ? t.charAt(idx - 1) : '';
    if (!(pre >= '0' && pre <= '9')) return idx;
    pos = idx;
    if (pos <= 0) return -1;
  }
  return -1;
}
/* 从回答里解析出目标玩家：
   ① 先看「投票：/决定：/查验：…」这类决策关键字之后出现的名字（最后提到的那个）；
   ② 都没有，就取全文最后被提到的名字。 */
function wwPick(text, cands) {
  const t = wwCnNum(text);
  const kws = ['投票：', '投票:', '决定：', '决定:', '查验：', '查验:',
               '击杀：', '击杀:', '选择：', '选择:', '带走：', '带：', '毒：', '毒:'];
  let decPos = -1;
  for (let k = 0; k < kws.length; k++) {
    const p = t.lastIndexOf(kws[k]);
    if (p > decPos) decPos = p;
  }
  const norm = cands.map(function (c) { return wwCnNum(c.name); });
  let best = null, bi = -1;
  if (decPos >= 0) {
    for (let i = 0; i < cands.length; i++) {
      const idx = wwFindIdx(t, norm[i]);
      if (idx > decPos && idx > bi) { bi = idx; best = cands[i]; }
    }
    if (best) return best;
  }
  for (let i = 0; i < cands.length; i++) {
    const idx = wwFindIdx(t, norm[i]);
    if (idx > bi) { bi = idx; best = cands[i]; }
  }
  return best;
}"""

if old_pick in src:
    src = src.replace(old_pick, new_pick, 1); n += 1
else:
    print('!! 未找到 wwPick 原函数'); sys.exit(2)

# ---------- 2) CSS ----------
old_css = "\n</style>"
new_css = """
.wwgate{display:flex;align-items:center;gap:10px;padding:8px 10px;margin:6px 0;
  background:#1e2a3a;border:1px solid #33507f;border-radius:10px}
.wwgate[hidden]{display:none}
.wwgate .btn{flex:0 0 auto}
.wwgate .chk{margin:0;font-size:12px;color:var(--dim)}
</style>"""
if old_css in src:
    src = src.replace(old_css, new_css, 1); n += 1
else:
    print('!! 未找到 </style>'); sys.exit(2)

# ---------- 3) HTML 闸门 ----------
old_html = """      <div class="wwchips" id="wwChips"></div>
      <div class="transcript" id="wwTranscript">"""
new_html = """      <div class="wwchips" id="wwChips"></div>
      <div class="wwgate" id="wwGate" hidden>
        <button class="btn primary" id="wwGateBtn">▶ 继续</button>
        <label class="chk"><input type="checkbox" id="wwAuto">自动（不暂停）</label>
      </div>
      <div class="transcript" id="wwTranscript">"""
if old_html in src:
    src = src.replace(old_html, new_html, 1); n += 1
else:
    print('!! 未找到 wwchips 区块'); sys.exit(2)

# ---------- 4) 闸门 JS ----------
old_marker = "/* ---------- 主循环 ---------- */"
new_gate_js = """/* ---------- 手动 / 自动 暂停闸门 ---------- */
let wwGateResolve = null;

function wwHideGate() { const g = $("#wwGate"); if (g) g.hidden = true; }
function wwReleaseGate() {
  if (wwGateResolve) { const r = wwGateResolve; wwGateResolve = null; wwHideGate(); r(); }
}
/* 自动模式直接放行；手动模式显示按钮并等待点击 */
function wwGateNext(label) {
  if (!ww || !ww.running) return Promise.resolve();
  if (state.wwAuto === true) return Promise.resolve();
  const g = $("#wwGate");
  const btn = $("#wwGateBtn");
  if (!g || !btn) return Promise.resolve();
  btn.textContent = label || '▶ 继续';
  g.hidden = false;
  wwStatus('⏸ 已暂停 · 点「' + (label || '继续') + '」继续（勾选「自动」可取消暂停）');
  return new Promise(function (res) { wwGateResolve = res; });
}

/* ---------- 主循环 ---------- */"""
if old_marker in src:
    src = src.replace(old_marker, new_gate_js, 1); n += 1
else:
    print('!! 未找到 主循环 标记'); sys.exit(2)

# ---------- 5) wwRun：插入闸门 ----------
old_run = """    await wwDaySpeeches();
    if (!ww.running) break;

    await wwVote();
    if (!ww.running) break;

    win = wwCheckWin();
    if (win) { ww.winner = win; break; }
  }"""
new_run = """    await wwDaySpeeches();
    if (!ww.running) break;

    await wwGateNext('▶ 开始投票（第 ' + ww.day + ' 天）');
    if (!ww.running) break;

    await wwVote();
    if (!ww.running) break;

    win = wwCheckWin();
    if (win) { ww.winner = win; break; }

    if (ww.day < maxDays) {
      await wwGateNext('▶ 进入第 ' + (ww.day + 1) + ' 天');
      if (!ww.running) break;
    }
  }"""
if old_run in src:
    src = src.replace(old_run, new_run, 1); n += 1
else:
    print('!! 未找到 wwRun 段落'); sys.exit(2)

# ---------- 6) wwStart 开局清闸门 ----------
old_st = """  switchView('werewolf');
  $("#btnWwStart").disabled = true;
  $("#btnWwStop").disabled = false;"""
new_st = """  switchView('werewolf');
  wwGateResolve = null;
  wwHideGate();
  $("#btnWwStart").disabled = true;
  $("#btnWwStop").disabled = false;"""
if old_st in src:
    src = src.replace(old_st, new_st, 1); n += 1
else:
    print('!! 未找到 wwStart 开局段'); sys.exit(2)

# ---------- 7) wwStart 结束清闸门 ----------
old_en = """  ww.running = false;
  $("#btnWwStart").disabled = false;
  $("#btnWwStop").disabled = true;
  wwStatus(ww.winner ? ('🏆 ' + ww.winner) : '已停止');
}"""
new_en = """  ww.running = false;
  wwGateResolve = null;
  wwHideGate();
  $("#btnWwStart").disabled = false;
  $("#btnWwStop").disabled = true;
  wwStatus(ww.winner ? ('🏆 ' + ww.winner) : '已停止');
}"""
if old_en in src:
    src = src.replace(old_en, new_en, 1); n += 1
else:
    print('!! 未找到 wwStart 结束段'); sys.exit(2)

# ---------- 8) wwStop 释放闸门 ----------
old_stop = """function wwStop() {
  if (!ww || !ww.running) return;
  ww.running = false;
  try { if (ww.abort) ww.abort.abort(); } catch (e) {}"""
new_stop = """function wwStop() {
  if (!ww || !ww.running) return;
  ww.running = false;
  wwReleaseGate();
  try { if (ww.abort) ww.abort.abort(); } catch (e) {}"""
if old_stop in src:
    src = src.replace(old_stop, new_stop, 1); n += 1
else:
    print('!! 未找到 wwStop'); sys.exit(2)

# ---------- 9) 绑定闸门控件 ----------
old_bind = """  b = $("#btnWwClear");
  if (b) b.addEventListener("click", function () {
    if (ww && ww.running) { toast('先停止再清空'); return; }
    ww = null; wwClear(); wwStatus('');
  });"""
new_bind = """  b = $("#btnWwClear");
  if (b) b.addEventListener("click", function () {
    if (ww && ww.running) { toast('先停止再清空'); return; }
    ww = null; wwClear(); wwStatus('');
  });
  b = $("#wwGateBtn");
  if (b) b.addEventListener("click", wwReleaseGate);
  b = $("#wwAuto");
  if (b) {
    b.checked = state.wwAuto === true;
    b.addEventListener("change", function (e) {
      state.wwAuto = e.target.checked; save();
      if (state.wwAuto) wwReleaseGate();
    });
  }"""
if old_bind in src:
    src = src.replace(old_bind, new_bind, 1); n += 1
else:
    print('!! 未找到 wwClear 绑定'); sys.exit(2)

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，已应用 %d 处修改，文件大小 %d -> %d' % (n, before, len(src)))
