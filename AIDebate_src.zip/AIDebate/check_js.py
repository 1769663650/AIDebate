#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 对 index.html 里每一段 script 做真正的语法解析检查。
# 需要 esprima（纯 Python 实现的 JS 解析器，离线可用）。
#
import re
import sys

PATH = '/sdcard/Download/AIDebate/assets/index.html'

src = open(PATH, encoding='utf-8').read()
blocks = re.findall(r'<script>(.*?)</script>', src, re.S)
print('找到 script 段数: %d' % len(blocks))

try:
    import esprima
except ImportError:
    print('esprima 未安装，无法检查')
    sys.exit(2)

bad = 0
for n, code in enumerate(blocks, 1):
    try:
        esprima.parseScript(code)
        print('  #%d 语法 OK  (%d 字符)' % (n, len(code)))
    except Exception as e:
        bad += 1
        print('  #%d 语法错误: %s' % (n, e))

if bad == 0:
    print('==> 全部通过')
    sys.exit(0)
print('==> %d 段有错误' % bad)
sys.exit(1)