#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 修复「女巫/狼人/预言家 决策解析」误判：
# 旧逻辑把整段推理里的字词（"毒""救"）当成决定，导致「说10号是好人却毒了10号」。
# 新逻辑：要求模型把最终决定单独放在「决定：」一行，解析时只截取该行（顺带兼容「查验：/结论：」）。
# 1) 新增 wwDecisionSeg(s) 辅助函数。
# 2) 狼人击杀 / 预言家查验 / 女巫用药 三处解析改用 wwDecisionSeg。
# 3) 女巫提示词改成「先理由、后决定」并明确三选一格式。

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, cnt=1):
    global src, n
    c = src.count(old)
    if c != cnt:
        print('[WARN] \u547d\u4e2d %d \u6b21\uff08\u671f\u671b %d\uff09\uff1a%r' % (c, cnt, old[:70]))
    src = src.replace(old, new)
    n += c

# ---- 1) 新增 wwDecisionSeg：只截取「最终决定」那一段 ----
rep(
"function wwNames(pool) { return pool.map(function (p) { return p.name; }).join('\u3001'); }",
"""function wwNames(pool) { return pool.map(function (p) { return p.name; }).join('\u3001'); }

/* \u53ea\u622a\u53d6\u300c\u6700\u7ec8\u51b3\u5b9a\u300d\u90a3\u4e00\u6bb5\uff1a\u4f18\u5148\u53d6\u6700\u540e\u4e00\u4e2a\u300c\u51b3\u5b9a\uff1a/\u67e5\u9a8c\uff1a/\u7ed3\u8bba\uff1a\u300d\u5230\u7ed3\u5c3e\u3002
   \u6ca1\u6709\u8fd9\u4e9b\u6807\u8bb0\u65f6\uff0c\u9000\u5316\u4e3a\u53d6\u6700\u540e 2 \u884c\u975e\u7a7a\u6587\u672c\u2014\u2014\u907f\u514d\u628a\u6574\u6bb5\u63a8\u7406\u91cc\u7684\u5b57\u8bcd\u5f53\u6210\u51b3\u5b9a\u3002 */
function wwDecisionSeg(s) {
  const t = wwCnNum(String(s == null ? '' : s));
  let idx = -1;
  const marks = ['\u51b3\u5b9a\uff1a', '\u51b3\u5b9a:', '\u67e5\u9a8c\uff1a', '\u67e5\u9a8c:', '\u7ed3\u8bba\uff1a', '\u7ed3\u8bba:'];
  for (let i = 0; i < marks.length; i++) {
    const p = t.lastIndexOf(marks[i]);
    if (p > idx) idx = p;
  }
  if (idx >= 0) return t.slice(idx);
  const lines = t.split('\\n').map(function (x) { return x.trim(); }).filter(function (x) { return x; });
  return lines.slice(-2).join('\\n');
}"""
)

# ---- 2) 狼人击杀解析 ----
rep(
"      const pick = wwPick(ans, pool) || wwRand(pool);",
"      const pick = wwPick(wwDecisionSeg(ans), pool) || wwPick(ans, pool) || wwRand(pool);"
)

# ---- 3) 预言家查验解析 ----
rep(
"    const tgt = wwPick(ans, pool) || wwRand(pool);",
"    const tgt = wwPick(wwDecisionSeg(ans), pool) || wwPick(ans, pool) || wwRand(pool);"
)

# ---- 4) 女巫提示词：先理由、后决定，三选一 ----
rep(
"      '\\n注意：同一晚最多只能使用一瓶药。\\n请回复你的决定：\\n\u00b7 想救被袭击的人，回复：救\\n\u00b7 想毒死某人，回复：毒 玩家名\\n\u00b7 什么都不做，回复：不用';",
"      '\\n注意：同一晚最多只能使用一瓶药。\\n请先简要说明你的判断（只有你自己能看到），然后【另起一行】给出最终决定，必须三选一：\\n决定：救\\n决定：毒 <玩家名>\\n决定：不用\\n只有「决定：」这一行才算数；前面写理由时提到任何人的名字都不影响决定，请务必想清楚再下结论。';"
)

# ---- 5) 女巫决策解析：只认「决定：」行，正确处理否定 ----
rep(
"""    const t = String(ans || '');
    const wantHeal = !ww.healUsed && nightKill && t.indexOf('\u6551') >= 0 && t.indexOf('\u4e0d\u6551') < 0;
    let poisonTgt = null;
    if (!wantHeal && !ww.poisonUsed && t.indexOf('\u6bd2') >= 0) {
      const pool = wwAlive().filter(function (p) { return p.name !== wi.name; });
      poisonTgt = wwPick(t.slice(t.indexOf('\u6bd2')), pool);
    }""",
"""    const seg = wwDecisionSeg(ans);
    const sayNo = /\u4e0d\u7528|\u4e0d\u6bd2|\u522b\u6bd2|\u65e0\u9700|\u653e\u5f03|\u4e0d\u6253\u7b97|\u5148\u4e0d/.test(seg);
    const wantHeal = !ww.healUsed && !!nightKill &&
      seg.indexOf('\u6551') >= 0 && seg.indexOf('\u4e0d\u6551') < 0 && seg.indexOf('\u6bd2') < 0 && !sayNo;
    let poisonTgt = null;
    if (!wantHeal && !ww.poisonUsed && seg.indexOf('\u6bd2') >= 0 && !sayNo) {
      const pool = wwAlive().filter(function (p) { return p.name !== wi.name; });
      poisonTgt = wwPick(seg, pool) || wwPick(ans, pool);
    }"""
)

open(PATH, 'w', encoding='utf-8').write(src)
print('OK\uff0c\u5171 %d \u5904\u4fee\u6539\uff0c\u6587\u4ef6\u5927\u5c0f %d \u5b57\u7b26' % (n, len(src)))