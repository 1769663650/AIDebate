#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 删除「辩论」功能：视图、标签、表单、提示词构造、辩论引擎、记录导出
# 保留：选手配置（狼人杀复用）、callModel、testConn、导入导出、toast
import io

PATH = 'assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
n = 0

def cut(start, end, tag):
    global src, n
    i = src.find(start)
    j = src.find(end)
    if i < 0 or j < 0 or j <= i:
        print('WARN cut 未命中: ' + tag + ' (i=%d j=%d)' % (i, j))
        return
    src = src[:i] + src[j:]
    n += 1
    print('OK   cut ' + tag)

def rep(old, new, tag):
    global src, n
    if old not in src:
        print('WARN 未命中: ' + tag)
        return
    src = src.replace(old, new, 1)
    n += 1
    print('OK   ' + tag)

# ============ A. HTML：删辩论视图 + 本场设置卡片 ============
cut("    <!-- ================= 辩论 ================= -->",
    "    <!-- ================= 狼人杀 ================= -->",
    'html debate view')
rep('<section id="view-werewolf" class="pane">',
    '<section id="view-werewolf" class="pane active">',
    'werewolf pane active')
rep('      <button id="tab-debate" class="active">辩论</button>\n      <button id="tab-werewolf">狼人杀</button>',
    '      <button id="tab-werewolf" class="active">狼人杀</button>',
    'tab debate removed')
cut('      <div class="card">\n        <h3>本场设置</h3>',
    '      <div class="card">\n        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">',
    'config debate card')

# ============ B. JS：删辩论 UI / 提示词 / 引擎 ============
cut("/* =========================================================\n   发言记录 UI",
    "let toastTimer = null;",
    'speech UI block')
cut("/* =========================================================\n   提示词构造",
    "/* =========================================================\n   连接测试",
    'debate prompts+engine')
cut("function applyStateToForm() {",
    "/* ---------- 选手卡片 ---------- */",
    'applyStateToForm/renderTopicLine/refreshJudge')
cut("function showMarkdown() {",
    "/* =========================================================\n   初始化",
    'showMarkdown')

# ============ C. 小改：选手模型 ============
rep('  const names = ["正方一号", "反方一号", "正方二号", "反方二号", "中立观察员", "场外嘉宾"];',
    '  const names = ["1号", "2号", "3号", "4号", "5号", "6号", "7号", "8号", "9号", "10号", "11号", "12号"];',
    'mkPart names')
rep("""    name: names[i % names.length],
    emoji: FACES[i % FACES.length],
    stance: (i % 2 === 0) ? "正方" : "反方",
    enabled: true,""",
    """    name: names[i % names.length],
    emoji: FACES[i % FACES.length],
    enabled: true,""",
    'mkPart stance removed')

rep("""    topic: "",
    rounds: 3,
    rotate: true,
    judgeOn: false,
    judgeId: "",
    compactLimit: 0,
    participants: [mkPart(0), mkPart(1)]""",
    """    participants: [mkPart(0), mkPart(1), mkPart(2), mkPart(3), mkPart(4)]""",
    'defaultState slim')

# participantCard：删立场下拉、改文案、删赋值
rep("""      '<select class="in stance" data-field="stance">' +
        '<option value="正方">正方</option><option value="反方">反方</option><option value="中立">中立</option>' +
      "</select>" +
""", "", 'card stance select')
rep('> 参与本场辩论</label>', '> 参与本局</label>', 'card label')
rep("""  el.querySelector('[data-field="stance"]').value = p.stance;

""", "", 'card stance assign')

# onPartChange / onPartClick
rep('  if (f === "name" || f === "enabled") refreshJudgeOptions();\n', '', 'onPartChange judge hook')
rep('    if (state.judgeId === p.id) state.judgeId = "";\n', '', 'onPartClick judgeId')

# renderParticipants / wwRenderChips 的立场显示
rep("""      const tag = p.enabled ? p.stance : '未启用';
      const cls = p.enabled ? (p.stance === '正方' ? 'pro' : (p.stance === '反方' ? 'con' : 'neu')) : 'off';
      const t = mkTile(i + 1, p.name, tag, cls, isConfigured(p));
      t.addEventListener('click', function () { openPartEditor(p.id); });
      grid.appendChild(t);""",
    """      const tag = p.enabled ? (p.model || '') : '未启用';
      const cls = p.enabled ? '' : 'off';
      const t = mkTile(i + 1, p.name, tag, cls, isConfigured(p));
      t.addEventListener('click', function () { openPartEditor(p.id); });
      grid.appendChild(t);""",
    'renderParticipants stance')

rep("""      const tag = p.enabled ? p.stance : '未启用';
      const cls = p.enabled ? (p.stance === '正方' ? 'pro' : (p.stance === '反方' ? 'con' : 'neu')) : 'off';
      const t = mkTile(i + 1, p.name, tag, cls, isConfigured(p));""",
    """      const tag = p.enabled ? (p.model || '') : '未启用';
      const cls = p.enabled ? '' : 'off';
      const t = mkTile(i + 1, p.name, tag, cls, isConfigured(p));""",
    'wwRenderChips stance')

rep('  refreshJudgeOptions();\n  if (typeof wwRenderPreview === "function") wwRenderPreview();',
    '  if (typeof wwRenderPreview === "function") wwRenderPreview();',
    'renderParticipants judge refresh')

# applyImport
rep('    applyStateToForm();\n    renderParticipants();', '    renderParticipants();', 'applyImport form')

# ============ D. init 重写片段 ============
rep("""  applyStateToForm();
  renderParticipants();

  // 设置页表单
  $("#topic").addEventListener("input", e => { state.topic = e.target.value; save(); renderTopicLine(); });
  $("#rounds").addEventListener("input", e => {
    state.rounds = Math.max(1, Math.min(10, Number(e.target.value) || 3)); save();
  });
  $("#compactLimit").addEventListener("input", e => {
    state.compactLimit = Math.max(0, Math.min(99, Number(e.target.value) || 0)); save();
  });
  $("#rotateSel").addEventListener("change", e => { state.rotate = e.target.value === "1"; save(); });
  $("#judgeOn").addEventListener("change", e => {
    state.judgeOn = e.target.checked;
    $("#judgeWrap").style.display = state.judgeOn ? "block" : "none";
    save();
  });
  $("#judgePick").addEventListener("change", e => { state.judgeId = e.target.value; save(); });

  $("#btnAdd").addEventListener("click", function () { addParticipant(true); });""",
    """  renderParticipants();

  $("#btnAdd").addEventListener("click", function () { addParticipant(true); });""",
    'init form block')

rep("""  // 顶部标签
  $("#tab-debate").addEventListener("click", () => switchView("debate"));
  $("#tab-config").addEventListener("click", () => switchView("config"));

  // 辩论按钮
  $("#btnStart").addEventListener("click", runDebate);
  $("#btnStop").addEventListener("click", stopDebate);
  $("#btnClear").addEventListener("click", () => {
    if (running) { toast("先停止再清空"); return; }
    transcript = []; memory = "";
    clearTranscript(); setStatus("");
  });
  $("#btnExportMd").addEventListener("click", showMarkdown);

  // 配置导入导出""",
    """  // 顶部标签
  $("#tab-config").addEventListener("click", () => switchView("config"));

  // 配置导入导出""",
    'init tabs+debate buttons')

rep("""  cxBindScroll();
  initWerewolf();
  switchView(firstRun ? "config" : "debate");
  if (firstRun) setTimeout(() => toast("先给每位选手填上接口地址和 API Key，再去「辩论」开打"), 400);""",
    """  initWerewolf();
  switchView(firstRun ? "config" : "werewolf");
  if (firstRun) setTimeout(() => toast("先给每位选手填上接口地址和 API Key，再去「狼人杀」开打"), 400);""",
    'init tail')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处修改，文件 %d 字符' % (n, len(src)))