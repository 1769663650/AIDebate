#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI擂台 · 图标生成脚本（可复现）

用法：
    python3 tools/make_icon.py

需要：Pillow + 一个中文字体（默认用系统里的 MiSans；若路径不存在可用环境变量 FONT 指定）
产物：res/mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher.png

设计：深色渐变底 + 右上角月牙 + 居中白色「狼」字。
想换字/换色，改下面的 TEXT / BG_TOP / BG_BOT / MOON 即可。
"""
import os
import sys

from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

TEXT = "狼"                 # 图标主字，可改成 "AI"、"擂" 等
BG_TOP = (0x16, 0x20, 0x3A)  # 背景渐变（上）
BG_BOT = (0x08, 0x0B, 0x12)  # 背景渐变（下）
MOON = (0xF5, 0xE4, 0xA6)    # 月牙颜色
FG = (0xFF, 0xFF, 0xFF)      # 主字颜色

SIZE = 512                   # 母版尺寸
FONT_CANDIDATES = [
    os.environ.get("FONT", ""),
    "/sdcard/Download/_iconfont.ttf",
    "/root/_iconfont.ttf",
    "/sdcard/Download/_iconfont.otf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
]
TARGETS = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}


def find_font():
    for p in FONT_CANDIDATES:
        if p and os.path.exists(p):
            return p
    sys.exit("找不到字体文件，请用 FONT=/path/to/font.otf 指定")


def gradient_bg(size):
    im = Image.new("RGB", (1, size))
    d = ImageDraw.Draw(im)
    for y in range(size):
        t = y / max(1, size - 1)
        d.point((0, y), tuple(
            int(BG_TOP[i] + (BG_BOT[i] - BG_TOP[i]) * t) for i in range(3)
        ))
    return im.resize((size, size), Image.BILINEAR)


def crescent(size, cx, cy, r, bite_dx, bite_dy, bite_r):
    """月牙：大圆挖掉一个偏移的小圆"""
    mask = Image.new("L", (size, size), 0)
    m = ImageDraw.Draw(mask)
    m.ellipse([cx - r, cy - r, cx + r, cy + r], fill=255)
    m.ellipse([cx - bite_r + bite_dx, cy - bite_r + bite_dy,
               cx + bite_r + bite_dx, cy + bite_r + bite_dy], fill=0)
    layer = Image.new("RGB", (size, size), MOON)
    return layer, mask


def main():
    font_path = find_font()
    base = gradient_bg(SIZE)

    # 月牙
    layer, mask = crescent(SIZE, int(SIZE * 0.74), int(SIZE * 0.24),
                           int(SIZE * 0.115), int(-SIZE * 0.045), int(-SIZE * 0.03),
                           int(SIZE * 0.105))
    base.paste(layer, (0, 0), mask)

    # 主字（带描边加粗）
    font = ImageFont.truetype(font_path, int(SIZE * 0.60))
    d = ImageDraw.Draw(base)
    try:
        bbox = d.textbbox((0, 0), TEXT, font=font, stroke_width=8)
    except Exception:
        bbox = (0, 0, SIZE, SIZE)
    w = bbox[2] - bbox[0]
    h = bbox[3] - bbox[1]
    x = (SIZE - w) / 2 - bbox[0]
    y = int(SIZE * 0.62) - h / 2 - bbox[1]
    d.text((x, y), TEXT, font=font, fill=FG, stroke_width=8, stroke_fill=FG)

    for folder, px in TARGETS.items():
        out_dir = os.path.join(ROOT, "res", folder)
        os.makedirs(out_dir, exist_ok=True)
        out = os.path.join(out_dir, "ic_launcher.png")
        base.resize((px, px), Image.LANCZOS).save(out, "PNG")
        print("  ->", out, px)

    # 顺手导一张 512 的预览图，方便肉眼检查
    prev = os.path.join(ROOT, "tools", "icon_preview_512.png")
    base.save(prev, "PNG")
    print("  ->", prev)
    print("字体:", font_path)


if __name__ == "__main__":
    main()
