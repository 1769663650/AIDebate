#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 1) 「开始投票」按钮不再备注天数；去掉「进入下一天」这一步（投票完直接下一天）。
# 2) 压缩上半部分：顶栏 / 操作条 / 方格区。
# 3) 玩家框编号缩小并挪到右上角；状态小圆点挪到左上角避免重叠。
import io, sys

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
before = len(src)
n = 0

# ---------- 1) wwRun：去掉第二个闸门 + 简化标签 ----------
old_run = """    await wwGateNext('▶ 开始投票（第 ' + ww.day + ' 天）');
    if (!ww.running) break;

    await wwVote();
    if (!ww.running) break;

    win = wwCheckWin();
    if (win) { ww.winner = win; break; }

    if (ww.day < maxDays) {
      await wwGateNext('▶ 进入第 ' + (ww.day + 1) + ' 天');
      if (!ww.running) break;
    }
  }"""
new_run = """    await wwGateNext('▶ 开始投票');
    if (!ww.running) break;

    await wwVote();
    if (!ww.running) break;

    win = wwCheckWin();
    if (win) { ww.winner = win; break; }
  }"""
if old_run in src:
    src = src.replace(old_run, new_run, 1); n += 1
else:
    print('!! 未找到 wwRun 闸门段'); sys.exit(2)

# ---------- 2) 顶栏压缩 ----------
old_hd = """header{
  flex:0 0 auto;display:flex;align-items:center;gap:10px;
  padding:calc(6px + env(safe-area-inset-top)) 10px 6px;
  background:var(--panel);border-bottom:1px solid var(--line);
}
.brand{flex:1;font-weight:700;font-size:16px;letter-spacing:.3px}
.tabs{display:flex;background:var(--panel2);border-radius:10px;padding:3px}
.tabs button{
  border:0;background:transparent;color:var(--dim);
  padding:6px 14px;border-radius:8px;font-size:14px;font-weight:600;font-family:inherit;
}"""
new_hd = """header{
  flex:0 0 auto;display:flex;align-items:center;gap:8px;
  padding:calc(3px + env(safe-area-inset-top)) 10px 3px;
  background:var(--panel);border-bottom:1px solid var(--line);
}
.brand{flex:1;font-weight:700;font-size:15px;letter-spacing:.3px}
.tabs{display:flex;background:var(--panel2);border-radius:9px;padding:2px}
.tabs button{
  border:0;background:transparent;color:var(--dim);
  padding:5px 12px;border-radius:7px;font-size:13px;font-weight:600;font-family:inherit;
}"""
if old_hd in src:
    src = src.replace(old_hd, new_hd, 1); n += 1
else:
    print('!! 未找到 header'); sys.exit(2)

# ---------- 3) 操作条 / 标题行压缩 ----------
old_bar = """.bar{
  flex:0 0 auto;display:flex;flex-direction:column;gap:6px;
  padding:6px 10px;background:var(--panel);border-bottom:1px solid var(--line);
}
.topicline{font-size:13px;color:var(--dim);word-break:break-word;line-height:1.45}"""
new_bar = """.bar{
  flex:0 0 auto;display:flex;flex-direction:column;gap:4px;
  padding:4px 10px;background:var(--panel);border-bottom:1px solid var(--line);
}
.topicline{font-size:12px;color:var(--dim);word-break:break-word;line-height:1.35}"""
if old_bar in src:
    src = src.replace(old_bar, new_bar, 1); n += 1
else:
    print('!! 未找到 .bar'); sys.exit(2)

# ---------- 4) 方格区压缩 ----------
old_ch = """.wwchips{display:grid;grid-template-columns:repeat(auto-fill,minmax(46px,1fr));gap:6px;
  padding:6px 8px;background:var(--panel);border-bottom:1px solid var(--line);
  flex:0 0 auto;max-height:20vh;overflow-y:auto}"""
new_ch = """.wwchips{display:grid;grid-template-columns:repeat(auto-fill,minmax(42px,1fr));gap:5px;
  padding:4px 6px;background:var(--panel);border-bottom:1px solid var(--line);
  flex:0 0 auto;max-height:17vh;overflow-y:auto}"""
if old_ch in src:
    src = src.replace(old_ch, new_ch, 1); n += 1
else:
    print('!! 未找到 .wwchips'); sys.exit(2)

# ---------- 5) 方格缩小 + 编号挪右上 ----------
old_tile = """.pgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(52px,1fr));gap:6px}
.ptile{position:relative;min-height:44px;border-radius:10px;background:var(--panel2);
  border:2px solid var(--line);display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:0;padding:3px 3px;overflow:hidden}
.ptile .num{font-size:16px;font-weight:800;line-height:1.05;color:var(--dim)}"""
new_tile = """.pgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(46px,1fr));gap:5px}
.ptile{position:relative;min-height:38px;border-radius:9px;background:var(--panel2);
  border:2px solid var(--line);display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:0;padding:3px 3px;overflow:hidden}
.ptile .num{position:absolute;top:1px;right:5px;font-size:10.5px;font-weight:800;
  line-height:1;color:var(--dim);opacity:.9}"""
if old_tile in src:
    src = src.replace(old_tile, new_tile, 1); n += 1
else:
    print('!! 未找到 .ptile'); sys.exit(2)

# ---------- 6) 小圆点挪到左上，避免和编号重叠 ----------
old_dot = """.ptile .dot{position:absolute;top:3px;right:3px;width:6px;height:6px;border-radius:50%;background:#6b2b38}"""
new_dot = """.ptile .dot{position:absolute;top:3px;left:4px;width:5px;height:5px;border-radius:50%;background:#6b2b38}"""
if old_dot in src:
    src = src.replace(old_dot, new_dot, 1); n += 1
else:
    print('!! 未找到 .dot'); sys.exit(2)

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，已应用 %d 处修改，文件大小 %d -> %d' % (n, before, len(src)))