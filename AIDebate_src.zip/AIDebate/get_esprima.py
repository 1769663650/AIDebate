#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 在没有 pip 的环境里手动装 esprima：
# 从 PyPI 镜像取 wheel，解压到 /root/pylibs，之后用 PYTHONPATH 引用。
#
import io
import os
import re
import socket
import sys
import urllib.parse
import urllib.request
import zipfile

socket.setdefaulttimeout(60)

MIRRORS = [
    'https://pypi.tuna.tsinghua.edu.cn/simple/esprima/',
    'https://mirrors.aliyun.com/pypi/simple/esprima/',
]
DEST = '/root/pylibs'

os.makedirs(DEST, exist_ok=True)

page = None
base = None
for m in MIRRORS:
    try:
        page = urllib.request.urlopen(m).read().decode('utf-8', 'replace')
        base = m
        print('索引源:', m)
        break
    except Exception as e:
        print('失败', m, e)

if page is None:
    sys.exit(1)

hrefs = re.findall(r'href=[\'"]([^\'"]+)[\'"]', page)
whls = [h for h in hrefs if h.endswith('.whl')]
print('可用 wheel 数:', len(whls))
if not whls:
    sys.exit(1)

url = urllib.parse.urljoin(base, whls[-1])
print('下载:', url)
data = urllib.request.urlopen(url).read()
print('大小: %d 字节' % len(data))

z = zipfile.ZipFile(io.BytesIO(data))
z.extractall(DEST)

tops = sorted(set(n.split('/')[0] for n in z.namelist()))
print('解压出的顶层项:', tops)
print('完成 ->', DEST)