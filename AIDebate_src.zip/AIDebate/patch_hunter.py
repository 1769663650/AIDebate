#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 1) 猎人开枪：抽出 wwHunterShoot()，除「被投票淘汰」外，夜里被狼刀也能开枪（被毒死不能）。
# 2) 应用名 AI辩论擂台 -> AI擂台（strings.xml + index.html）。
# 3) 删除狼人杀顶部「🐺 狼人杀 · 上帝视角观战」那一行。

HTML = '/sdcard/Download/AIDebate/assets/index.html'
STR  = '/sdcard/Download/AIDebate/res/values/strings.xml'

src = open(HTML, encoding='utf-8').read()
n = 0

def rep(old, new, cnt=1):
    global src, n
    c = src.count(old)
    if c != cnt:
        print('[WARN] \u547d\u4e2d %d \u6b21\uff08\u671f\u671b %d\uff09\uff1a%r' % (c, cnt, old[:70]))
    src = src.replace(old, new)
    n += c

# ---- 1a) 猎人角色说明 ----
rep(
"    return '\u3010\u4f60\u7684\u8eab\u4efd\uff1a\u730e\u4eba\u3011\\n\u4f60\u5e73\u65f6\u548c\u6751\u6c11\u4e00\u6837\u3002\u5f53\u4f60\u88ab\u6295\u7968\u6dd8\u6c70\u65f6\uff0c\u53ef\u4ee5\u5f00\u67aa\u5e26\u8d70\u4e00\u540d\u73a9\u5bb6\u3002';",
"    return '\u3010\u4f60\u7684\u8eab\u4efd\uff1a\u730e\u4eba\u3011\\n\u4f60\u5e73\u65f6\u548c\u6751\u6c11\u4e00\u6837\uff0c\u5c3d\u91cf\u522b\u592a\u65e9\u66b4\u9732\u8eab\u4efd\u3002\\n\u3010\u5f00\u67aa\u6761\u4ef6\u3011\u4f60\u88ab\u6295\u7968\u6dd8\u6c70\u3001\u6216\u88ab\u72fc\u4eba\u591c\u91cc\u5200\u6b7b\u65f6\uff0c\u90fd\u53ef\u4ee5\u5f00\u67aa\u5e26\u8d70\u4e00\u540d\u73a9\u5bb6\uff1b\u4f46\u5982\u679c\u4f60\u662f\u88ab\u5973\u5deb\u6bd2\u6b7b\u7684\uff0c\u5c31\u65e0\u6cd5\u5f00\u67aa\u3002\\n\u5f00\u67aa\u65f6\u4f18\u5148\u5e26\u8d70\u4f60\u6700\u6000\u7591\u7684\u72fc\u4eba\u3002';"
)

# ---- 1b) 投票淘汰后的开枪：改为调用共享函数 ----
rep(
"""  const wasHunter = out.role === '\u730e\u4eba';
  await wwKill(out, '\u6295\u7968\u6dd8\u6c70');

  if (wasHunter && ww.running) {
    const pool = wwAlive();
    if (pool.length) {
      let ans = '';
      try {
        ans = await wwAsk(out, '\u3010\u730e\u4eba\u6280\u80fd\u3011\\n\u4f60\u88ab\u6295\u7968\u6dd8\u6c70\u4e86\u3002\u4f60\u53ef\u4ee5\u5f00\u67aa\u5e26\u8d70\u4e00\u540d\u73a9\u5bb6\u3002\\n\u53ea\u56de\u590d\u4e00\u4e2a\u73a9\u5bb6\u540d\u5b57\uff0c\u4e0d\u8981\u89e3\u91ca\u3002\\n\u53ef\u9009\uff1a' + wwNames(pool), 30);
      } catch (e) {}
      const shot = wwPick(ans, pool) || wwRand(pool);
      wwSys('\U0001f52b \u730e\u4eba\u5f00\u67aa', out.name + ' \u4eae\u51fa\u730e\u4eba\u8eab\u4efd\uff0c\u5f00\u67aa\u5e26\u8d70\u4e86 ' + shot.name);
      wwPub(out.name + ' \u662f\u730e\u4eba\uff0c\u5f00\u67aa\u5e26\u8d70\u4e86 ' + shot.name + '\u3002');
      await wwKill(shot, '\u730e\u4eba\u5f00\u67aa');
    }
  }
}""",
"""  await wwKill(out, '\u6295\u7968\u6dd8\u6c70');
  if (out.role === '\u730e\u4eba') await wwHunterShoot(out);
}

/* \u730e\u4eba\u5f00\u67aa\uff1a\u88ab\u6295\u7968\u6dd8\u6c70\u3001\u6216\u88ab\u72fc\u4eba\u591c\u91cc\u5200\u6b7b\u65f6\u90fd\u80fd\u5f00\u67aa\uff08\u88ab\u5973\u5deb\u6bd2\u6b7b\u5219\u4e0d\u80fd\uff09\u3002 */
async function wwHunterShoot(out) {
  if (!out || !ww.running) return;
  const pool = wwAlive();
  if (!pool.length) return;
  let ans = '';
  try {
    const r = await wwAskEx(out, '\u3010\u730e\u4eba\u6280\u80fd\u3011\\n\u4f60\u51fa\u5c40\u4e86\uff0c\u53ef\u4ee5\u5f00\u67aa\u5e26\u8d70\u4e00\u540d\u73a9\u5bb6\u3002\\n\u53ea\u56de\u590d\u4e00\u4e2a\u73a9\u5bb6\u540d\u5b57\uff08\u4f8b\u5982\uff1a\u4e09\u53f7\uff09\uff0c\u4e0d\u8981\u89e3\u91ca\u3002\\n\u53ef\u9009\uff1a' + wwNames(pool), 80);
    ans = r.text || r.think;
  } catch (e) {
    if (e && e.name === 'AbortError') return;
  }
  const shot = wwPick(wwDecisionSeg(ans), pool) || wwPick(ans, pool) || wwRand(pool);
  wwSys('\U0001f52b \u730e\u4eba\u5f00\u67aa', out.name + ' \u4eae\u51fa\u730e\u4eba\u8eab\u4efd\uff0c\u5f00\u67aa\u5e26\u8d70\u4e86 ' + shot.name);
  wwPub(out.name + ' \u662f\u730e\u4eba\uff0c\u5f00\u67aa\u5e26\u8d70\u4e86 ' + shot.name + '\u3002');
  await wwKill(shot, '\u730e\u4eba\u5f00\u67aa');
}"""
)

# ---- 1c) 夜里被狼刀也能开枪（插在「天亮了」与 wwCheckWin 之间） ----
rep(
"""    wwPub('\u7b2c' + ww.day + ' \u5929\uff1a' + (names ? ('\u6628\u591c\u6b7b\u4ea1 ' + names) : '\u5e73\u5b89\u591c\uff0c\u65e0\u4eba\u6b7b\u4ea1'));

    let win = wwCheckWin();""",
"""    wwPub('\u7b2c' + ww.day + ' \u5929\uff1a' + (names ? ('\u6628\u591c\u6b7b\u4ea1 ' + names) : '\u5e73\u5b89\u591c\uff0c\u65e0\u4eba\u6b7b\u4ea1'));

    // \u730e\u4eba\u82e5\u591c\u91cc\u6b7b\u4e8e\u72fc\u5200 \u2192 \u53ef\u4ee5\u5f00\u67aa\uff08\u88ab\u5973\u5deb\u6bd2\u6b7b\u5219\u4e0d\u80fd\uff09
    if (ww.running && night && night.kill && !night.healed && night.kill.role === '\u730e\u4eba') {
      await wwHunterShoot(night.kill);
    }

    let win = wwCheckWin();"""
)

# ---- 2) 删除狼人杀顶部「上帝视角观战」那行 ----
rep(
'        <div class="topicline">\U0001f43a \u72fc\u4eba\u6740 \u00b7 \u4e0a\u5e1d\u89c6\u89d2\u89c2\u6218</div>\n',
''
)

# ---- 3) 应用名改名 ----
rep('AI\u8fa9\u8bba\u64f2\u53f0', 'AI\u64c2\u53f0', src.count('AI\u8fa9\u8bba\u64f2\u53f0'))

open(HTML, 'w', encoding='utf-8').write(src)
print('index.html OK\uff0c\u5171 %d \u5904\uff0c\u6587\u4ef6 %d \u5b57\u7b26' % (n, len(src)))

# strings.xml
s = open(STR, encoding='utf-8').read()
c = s.count('AI\u8fa9\u8bba\u64f2\u53f0')
s = s.replace('AI\u8fa9\u8bba\u64f2\u53f0', 'AI\u64c2\u53f0')
open(STR, 'w', encoding='utf-8').write(s)
print('strings.xml OK\uff0c\u66f4\u6539 %d \u5904' % c)