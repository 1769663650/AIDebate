#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 投票环节改为「两段式」：正常思考照走，最后只输出一个玩家名
# 1) 新增 wwSplitVote(raw)：拆出【思考】与【投票】名字
# 2) 投票指令改为两段格式；解析只从【投票】段取名字
# 3) 界面：只显示「投给 X」，思考灰字单独显示（受开关控制），不再把整段理由当投票结果
import io

PATH = 'assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, tag):
    global src, n
    if old not in src:
        print('WARN 未命中: ' + tag)
        return
    src = src.replace(old, new, 1)
    n += 1
    print('OK   ' + tag)

# ---------- 1) 新增 wwSplitVote ----------
old1 = """  return '';
}

/* ---------- 界面 ---------- */"""
new1 = """  return '';
}

/* 投票专用：拆出「思考」和「投票名」。只认【投票】/投票：标记，取其后第一行作为名字。 */
function wwSplitVote(raw) {
  const t = wwCnNum(String(raw == null ? '' : raw));
  let think = '', vote = '';
  const mi = t.indexOf('【投票】');
  if (mi >= 0) {
    think = t.slice(0, mi).replace(/^【思考】\\s*/, '').trim();
    vote = t.slice(mi + 4).split('\\n')[0].trim();
  } else {
    const p1 = t.lastIndexOf('投票：'), p2 = t.lastIndexOf('投票:');
    const mi2 = Math.max(p1, p2);
    if (mi2 >= 0) {
      think = t.slice(0, mi2).replace(/^【思考】\\s*/, '').trim();
      vote = t.slice(mi2 + 3).split('\\n')[0].trim();
    } else {
      const lines = t.split('\\n').map(function (x) { return x.trim(); }).filter(function (x) { return x; });
      if (lines.length) { vote = lines[lines.length - 1]; think = lines.slice(0, -1).join('\\n'); }
    }
  }
  vote = vote.replace(/^【投票】\\s*/, '').replace(/^投票[:：]\\s*/, '').trim();
  return { think: think, vote: vote };
}

/* ---------- 界面 ---------- */"""
rep(old1, new1, 'wwSplitVote')

# ---------- 2) 投票指令 + 解析 ----------
old2 = """    let ans = '', think = '';
    const priorTxt = detail.length ? ('\\n本轮已经投出的票：' + detail.join('；')) : '';
    const mateTxt = (v.role === '狼人')
      ? ('\\n你的狼队友是：' + ww.players.filter(function (x) { return x.role === '狼人' && x.id !== v.id; }).map(function (x) { return x.name; }).join('、') + '。正常情况下别投队友；但如果某个队友已被查杀、眼看要被全场投出，跟票他反而能洗白你自己（这叫切割）。')
      : '';
    try {
      const r = await wwAskEx(v, '【投票阶段】\\n所有人已经发言完毕。' + priorTxt + mateTxt + '\\n可选目标：' + wwNames(pool) + '\\n请认真思考后投票淘汰一名你认为是狼人的玩家：先简要说明理由，最后单独一行写「投票：<玩家名>」。', 0);
      ans = r.text || r.think; think = r.think;
    } catch (e) {
      if (e && e.name === 'AbortError') return;
    }
    const pick = wwPick(ans, pool) || wwRand(fb);"""
new2 = """    let think = '';
    let pick = null;
    const priorTxt = detail.length ? ('\\n本轮已经投出的票：' + detail.join('；')) : '';
    const mateTxt = (v.role === '狼人')
      ? ('\\n你的狼队友是：' + ww.players.filter(function (x) { return x.role === '狼人' && x.id !== v.id; }).map(function (x) { return x.name; }).join('、') + '。正常情况下别投队友；但如果某个队友已被查杀、眼看要被全场投出，跟票他反而能洗白你自己（这叫切割）。')
      : '';
    try {
      const r = await wwAskEx(v, '【投票阶段】\\n所有人已经发言完毕。' + priorTxt + mateTxt + '\\n可选目标：' + wwNames(pool) + '\\n请先按下面两段格式输出，不要有多余内容：\\n【思考】这里写你真实的判断——为什么怀疑谁、场上票型如何，只有你自己能看到。\\n【投票】这里只写你要投票淘汰的那一个玩家名（例如：五号），只能有一个名字，不要写任何理由或解释。', 0);
      const raw = r.text || r.think || '';
      const sv = wwSplitVote(raw);
      think = sv.think || r.think;
      pick = wwPick(sv.vote, pool) || wwPick(wwDecisionSeg(raw), pool) || wwPick(raw, pool);
    } catch (e) {
      if (e && e.name === 'AbortError') return;
    }
    if (!pick) pick = wwRand(fb);"""
rep(old2, new2, 'vote instruction+parse')

# ---------- 3) 界面显示 ----------
old3 = """    wwAdd('vote', '🗳 ' + v.name + ' 投给', pick.name + thinkLine(think || ans));"""
new3 = """    wwAdd('vote', '🗳 ' + v.name + ' 投给', pick.name + thinkLine(think));"""
rep(old3, new3, 'vote display')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处修改，文件 %d 字符' % (n, len(src)))