#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 1. 思考过程默认不显示（设置里留开关，默认关）
# 2. 发言拿不到正文时，追加一次「只输出公开演讲」的重试
# 3. 系统提示禁止公开发言里出现身份自白 / 内心盘算
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)
n = 0
def rep(old, new, tag):
    global src, n
    if old in src:
        src = src.replace(old, new, 1); n += 1
    else:
        print('   !! 未命中：' + tag)

# ---- 1. 系统提示：加第5条硬约束 ----
rep(
"    '4. 不要说“根据我的分析模型”之类的话，就像正常人一样争论、怀疑、带节奏。'\n  ];",
"    '4. 不要说“根据我的分析模型”之类的话，就像正常人一样争论、怀疑、带节奏。',\n"
"    '5. 【极其重要】你输出的每一句“发言”，都必须是你当众说出口的话。绝对不要把内心盘算、身份自白（例如“我是狼人”“我要误导好人”“我的计划是”）写进发言里——这些只能自己心里想，一个字都不能外露。'\n  ];",
"系统提示规则5")

# ---- 2. 思考默认不显示（开关控制） ----
rep(
"      if (node && node.think) { node.think.hidden = false; node.think.textContent = th; }",
"      if (node && node.think && state.wwShowThink) { node.think.hidden = false; node.think.textContent = th; }",
"思考显示开关")

# ---- 3. 新增：把“想好的话”重新组织成公开演讲 ----
rep(
"async function wwDaySpeeches() {",
"""async function wwSpeechRetry(pl, maxTokens) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: maxTokens || 600 });
  const inst = '【白天讨论 · 最终发言】\\n现在，只输出你当众对大家说的那一段话。\\n要求：像真人一样口语化；不要写任何分析、推理或内心盘算；绝不要出现“我是狼人/我是预言家”这类身份自白（除非你正在悍跳预言家）；不要写括号动作。\\n直接输出发言内容即可。';
  let acc = '', th = '';
  await callModel(cfg, wwContext(pl, inst), function (d) {
    if (d.text) acc += d.text;
    if (d.think) th += d.think;
  }, ww.abort ? ww.abort.signal : null);
  return acc.trim() || th.trim();
}

async function wwDaySpeeches() {""",
"新增 wwSpeechRetry")

# ---- 4. 白天发言：正文为空时追加一次重试 ----
rep(
"        txt = await wwAskStream(sp, wwSpeechPrompt(sp), node, 900);",
"        txt = await wwAskStream(sp, wwSpeechPrompt(sp), node, 900);\n"
"        if (!txt) {\n"
"          wwStatus('☀️ 第 ' + ww.day + ' 天 · ' + sp.name + ' 重新组织发言…');\n"
"          txt = await wwSpeechRetry(sp, 600);\n"
"        }",
"白天发言追加重试")

# ---- 5. 有正文时回填到气泡 ----
rep(
"      if (txt) {\n        wwPub(sp.name + '（' + label + '）：' + txt);",
"      if (txt) {\n        if (node && node.content) node.content.textContent = txt;\n        wwPub(sp.name + '（' + label + '）：' + txt);",
"正文回填气泡")

# ---- 6. 空发言提示文案 ----
rep(
"node.content.textContent = '（没有拿到正式发言——只有上方的思考内容。多半是推理模型把输出长度用在了思考上：把该选手的「最大输出」调大，或换用非推理模型名试试）';",
"node.content.textContent = '（模型始终只给思考、没给正式发言。请把该选手的「最大输出」调大，或把模型名换成非推理模型再试。）';",
"空发言提示")

# ---- 7. 设置里加“显示思考”开关 ----
rep(
'        <label class="chk"><input type="checkbox" id="wwGodView">上帝视角（显示夜晚行动）</label>',
'        <label class="chk"><input type="checkbox" id="wwGodView">上帝视角（显示夜晚行动）</label>\n'
'        <label class="chk"><input type="checkbox" id="wwShowThink">显示 AI 思考过程（调试用，默认关）</label>',
"设置加思考开关")

# ---- 8. 绑定“显示思考”开关 ----
rep(
'''  b = $("#wwGodView");
  if (b) {
    b.checked = state.wwGodView !== false;
    b.addEventListener("change", function (e) { state.wwGodView = e.target.checked; save(); });
  }''',
'''  b = $("#wwGodView");
  if (b) {
    b.checked = state.wwGodView !== false;
    b.addEventListener("change", function (e) { state.wwGodView = e.target.checked; save(); });
  }
  b = $("#wwShowThink");
  if (b) {
    b.checked = state.wwShowThink === true;
    b.addEventListener("change", function (e) { state.wwShowThink = e.target.checked; save(); });
  }''',
"绑定思考开关")

io.open(P, 'w', encoding='utf-8').write(src)
print('命中 %d/8 段，文件大小 %d -> %d' % (n, before, len(src)))
if n < 8:
    sys.exit(1)