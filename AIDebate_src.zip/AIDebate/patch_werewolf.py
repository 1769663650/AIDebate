#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 把狼人杀模式注入 index.html：
#   1) 顶栏加「狼人杀」标签
#   2) 插入 #view-werewolf 面板
#   3) 追加狼人杀样式
#   4) 设置页加狼人杀配置卡
#   5) switchView 改为支持三种视图
#   6) init 里调用 initWerewolf
#   7) renderParticipants 里刷新角色预览
#   8) 把 werewolf.js 的内容注入到主 script 里
#
import sys

HTML = '/sdcard/Download/AIDebate/assets/index.html'
WWJS = '/sdcard/Download/AIDebate/werewolf.js'

WW_SECTION = '''
    <!-- ================= 狼人杀 ================= -->
    <section id="view-werewolf" class="pane">
      <div class="bar">
        <div class="topicline">🐺 狼人杀 · 上帝视角观战</div>
        <div class="status" id="wwStatus"></div>
        <div class="bar-actions">
          <button class="btn primary" id="btnWwStart">开始新一局</button>
          <button class="btn danger" id="btnWwStop" disabled>停止</button>
          <button class="btn ghost" id="btnWwClear">清空</button>
        </div>
      </div>
      <div class="wwchips" id="wwChips"></div>
      <div class="transcript" id="wwTranscript">
        <p class="empty">还没有开局。<br>在「设置」里配好至少 5 位 AI 选手，<br>然后回来点「开始新一局」。</p>
      </div>
    </section>

'''

WW_CSS = '''
/* ---------- 狼人杀 ---------- */
#view-werewolf.active{display:flex;flex-direction:column;padding:0}
.wwchips{display:flex;flex-wrap:wrap;gap:6px;padding:8px 12px;background:var(--panel);
  border-bottom:1px solid var(--line);flex:0 0 auto}
.chip{font-size:12px;padding:3px 9px;border-radius:20px;background:var(--panel2);
  border:1px solid var(--line);white-space:nowrap}
.chip.dead{opacity:.35;text-decoration:line-through}
.chip.wolf{border-color:#7a2b3a;background:#2a1620}
.chip.spec{border-color:#4a3a7a;background:#1e1a2e}
.wwev{margin:0 0 12px;padding:9px 11px;border-radius:10px;font-size:13.5px;
  line-height:1.6;white-space:pre-wrap;word-break:break-word}
.wwev.sys{background:var(--panel2);border:1px dashed var(--line);color:var(--dim);text-align:center}
.wwev.sys .wwtitle{color:var(--txt);font-weight:700;margin-bottom:2px}
.wwev.night{background:#17122a;border:1px solid #3b2f66;color:#c7b8ff}
.wwev.night .wwtitle{color:#a98cff;font-weight:700;margin-bottom:4px}
.wwev.vote{background:var(--panel);border:1px solid var(--line);font-size:12.5px;color:var(--dim)}
.wwev.vote .wwtitle{color:var(--txt);font-weight:600;margin-bottom:2px}
.wwev.end{background:#1b2416;border:1px solid #3f5a2e;color:#cdf0b0;text-align:center;font-size:14px}
.wwev.end .wwtitle{font-weight:800;color:#fff;margin-bottom:6px;font-size:15px}
'''

WW_CARD = '''      <div class="card">
        <h3>狼人杀</h3>
        <div class="row">
          <label class="fld"><span>最多天数</span>
            <input class="in" id="wwMaxDays" type="number" min="1" max="20" value="10">
          </label>
          <label class="fld"><span>每天发言轮数</span>
            <input class="in" id="wwSpeechRounds" type="number" min="1" max="3" value="1">
          </label>
        </div>
        <label class="chk"><input type="checkbox" id="wwGodView">上帝视角（显示夜晚行动）</label>
        <p class="hint" id="wwRolesPreview">—</p>
        <p class="hint">角色按启用的选手人数自动分配，最少 5 人。狼人杀一局会发起大量 API 调用（8 人局约每天 20 次左右），注意消耗。</p>
      </div>

'''

Tab_OLD = '      <button id="tab-debate" class="active">辩论</button>\n      <button id="tab-config">设置</button>'
Tab_NEW = '      <button id="tab-debate" class="active">辩论</button>\n      <button id="tab-werewolf">狼人杀</button>\n      <button id="tab-config">设置</button>'

MARK = '    <!-- ================= 设置 ================= -->'

CSS_OLD = '.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}\n</style>'
CSS_NEW = '.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}\n' + WW_CSS + '</style>'

CARD_OLD = '      <div class="card">\n        <h3>数据</h3>'
CARD_NEW = WW_CARD + '      <div class="card">\n        <h3>数据</h3>'

SV_OLD = '''function switchView(name) {
  $$(".pane").forEach(p => p.classList.remove("active"));
  const el = $("#view-" + name);
  if (el) el.classList.add("active");
  $("#tab-debate").classList.toggle("active", name === "debate");
  $("#tab-config").classList.toggle("active", name === "config");
}'''

SV_NEW = '''function switchView(name) {
  $$(".pane").forEach(function (p) { p.classList.remove("active"); });
  const el = $("#view-" + name);
  if (el) el.classList.add("active");
  ["debate", "werewolf", "config"].forEach(function (n) {
    const b = $("#tab-" + n);
    if (b) b.classList.toggle("active", n === name);
  });
}'''

INIT_OLD = '  switchView(firstRun ? "config" : "debate");'
INIT_NEW = '  initWerewolf();\n  switchView(firstRun ? "config" : "debate");'

RP_OLD = '  refreshJudgeOptions();\n}'
RP_NEW = '  refreshJudgeOptions();\n  if (typeof wwRenderPreview === "function") wwRenderPreview();\n}'

BIND_OLD = 'document.addEventListener("DOMContentLoaded", init);'

src = open(HTML, encoding='utf-8').read()
wwjs = open(WWJS, encoding='utf-8').read()
before = len(src)
applied = []
skipped = []


def rep(old, new, tag):
    global src
    if old not in src:
        skipped.append(tag)
        return
    src = src.replace(old, new, 1)
    applied.append(tag)


rep(Tab_OLD, Tab_NEW, '顶栏标签')
rep(CSS_OLD, CSS_NEW, '样式')
rep(MARK, WW_SECTION + MARK, '狼人杀面板')
rep(CARD_OLD, CARD_NEW, '设置卡片')
rep(SV_OLD, SV_NEW, 'switchView')
rep(INIT_OLD, INIT_NEW, 'init 调用')
rep(RP_OLD, RP_NEW, '角色预览刷新')

if 'WW_ROLE_EMOJI' in src:
    skipped.append('引擎注入（已存在）')
else:
    rep(BIND_OLD, wwjs + '\n\n' + BIND_OLD, '引擎注入')

open(HTML, 'w', encoding='utf-8').write(src)

print('已应用: ' + ('、'.join(applied) if applied else '无'))
if skipped:
    print('已跳过: ' + '、'.join(skipped))
print('文件大小 %d -> %d' % (before, len(src)))