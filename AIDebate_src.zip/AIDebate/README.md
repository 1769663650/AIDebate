# 🥊 AI辩论擂台

把一个辩题丢给多个 AI，让它们按立场轮流发言、互相反驳，最后还能请个裁判点评。

## 这是什么

一个 Android APK，包名为 `com.operit.aidebate`。

**整个 App 的内容就是 `assets/index.html` 一个文件**，Android 那边只有 80 行 Java 负责套一层 WebView。
这样做的好处是：改功能不用重装编译器，直接改 HTML 重新打包即可。

## 目录

```
AIDebate/
├── AndroidManifest.xml                  清单
├── build.sh                             一键构建脚本（无 Gradle）
├── AIDebate.apk                         ← 构建产物
├── res/
│   ├── values/strings.xml               应用名
│   └── drawable/ic_launcher.xml         图标（矢量）
├── src/com/operit/aidebate/
│   └── MainActivity.java                WebView 外壳
└── assets/
    └── index.html                       ★ 全部界面与逻辑
```

## 怎么改、怎么重新打包

1. 直接编辑 `assets/index.html`（用 MT管理器 / 夸克 都行）。
2. 打开 Operit 的终端，执行：

```bash
cd /sdcard/Download/AIDebate && bash build.sh
```

3. 产物在 `/sdcard/Download/AIDebate/AIDebate.apk`，覆盖安装即可。

## 构建依赖（本机已具备）

| 工具 | 位置 / 说明 |
|---|---|
| JDK 21 | `/usr/bin/javac`（Ubuntu proot 里） |
| android.jar (API 23) | `/usr/lib/android-sdk/platforms/android-23/android.jar` |
| aapt2 / zipalign / apksigner | `/usr/bin/` |
| d8 (R8) | `/root/r8.jar`，从阿里云 Maven 镜像下载 |
| 签名密钥 | `/root/aidebate.keystore`（口令均为 `android`） |

**关键处理**：脚本在合并 dex 时会把 `resources.arsc` 强制改为「不压缩」。
因为 targetSdk ≥ 30 时，Android 11+ 会拒绝安装 `resources.arsc` 被压缩的包。

## App 里的功能

- **多选手**：每位选手独立配置 接口地址 / API Key / 模型名 / 立场 / 人设 / 温度 / 最大输出。
- **内置预设**：DeepSeek、Kimi、通义、智谱、硅基流动、豆包、百川、Yi、阶跃、MiniMax、OpenAI、Gemini、Claude、本地 Ollama。全部走 OpenAI 兼容的 `/chat/completions`。
- **辩论流程**：按轮次依次发言（可设置每轮轮换首位，避免总是一个人先手）；每位选手都能看到全部历史。
- **流式输出**：边生成边显示；推理模型（如 deepseek-reasoner）的思考过程会以灰色斜体单独展示。
- **历史压缩**：发言条数超过阈值时，早期内容自动压成一段「前情提要」，省 token 也降延迟。
- **裁判点评**：可选。复用某位选手的接口，换一套评委 prompt。
- **导出**：辩论记录导出为 Markdown；配置导出为 JSON（含 Key，请自行保管）。

## 狼人杀模式

顶栏第三个标签。你是「上帝视角」的观战者——能看到所有人的身份和夜晚行动，
但 AI 之间互相不知道对方底细。

- **角色**：狼人 / 预言家 / 女巫 / 猎人 / 村民，按启用的选手人数自动分配（最少 5 人）
- **流程**：夜晚（狼人刀人 → 预言家查验 → 女巫用药）→ 天亮公布死讯 → 白天依次发言 → 投票淘汰 → 判定胜负
- **隐藏信息**：每个 AI 只会拿到「自己的身份 + 自己该知道的信息 + 公共事件」。
  预言家的查验结果、狼人的队友名单，都只写进各自的私有笔记，绝不泄露给别人。
- **胜负**：狼人全死 → 好人胜；狼人数 ≥ 好人数 → 狼人胜
- 具体角色配置会实时显示在「设置」页的狼人杀卡片里

### 花费提醒

一局 8 人局大约每天 20 次 API 调用，跑满 10 天就是 200 次左右，
而且每次都要带上公共发言记录。**建议先用 5 人局 + 最多 3 天试水**，
把 prompt 和节奏调顺了再上规模。

### 关于 AI 的“智能”

选择目标时（刀谁、查谁、投谁），引擎要求模型只回复一个玩家名字，
然后用「最早出现的候选名」做匹配；完全匹配不上就随机兜底，
避免某次 API 抽风就把整局卡死。

## 为什么不用服务器就能调 API

普通浏览器里，`file://` 页面调外部 API 会被 CORS 拦死。
`MainActivity` 里开了一个开关：

```java
settings.setAllowUniversalAccessFromFileURLs(true);
```

它让本地页面可以访问任意网络源，等于把 CORS 直接绕过。**这是套 WebView 壳最主要的动机。**

## 已知限制

- 目标 SDK 34、最小 SDK 23。编译用的是 API 23 的 android.jar，但不影响（只用到 WebView 的老 API）。
- 接口必须是 **OpenAI 兼容**格式。Anthropic / Gemini 请用它们各自的 OpenAI 兼容端点（预设里已填好）。
- Key 明文存在 WebView 的 localStorage 里，只在本机，未加密。别把带 Key 的配置 JSON 外发。
- 本机 Ollama 需要填写电脑在局域网里的 IP，不能写 `127.0.0.1`（那是手机自己）。

## 如果 WebView 的 CORS 绕过失效

极少数机型/WebView 版本可能仍然拦截。这时有两个后备方案：

1. 在电脑或手机上跑一个极简转发服务，把「接口地址」填成它的地址；
2. 或者用纯浏览器打开 `index.html`（Chrome 里可能因 CORS 失败，仅供调试）。

## 安装提示

MIUI / HyperOS 下用命令行 `pm install` 会被拦（`INSTALL_FAILED_USER_RESTRICTED`）。
正确做法是点开 APK 走系统安装界面；或到「开发者选项」里打开「USB 安装」。
