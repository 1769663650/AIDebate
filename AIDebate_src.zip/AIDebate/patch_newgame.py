#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 开始新一局：保留历史记录，只插入一条分隔；仅「清空」按钮才真的清空
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)

OLD = """  wwClear();
  switchView('werewolf');"""
NEW = """  wwAdd('sys', '🆕 新一局开始', '人数 ' + ps.length + ' 人 · 最多 ' + (Number(state.wwMaxDays) || 10) + ' 天。（上一局记录保留在上方，点「清空」可清除）');
  switchView('werewolf');"""

if OLD not in src:
    print('!! 未找到目标代码块，未修改')
    sys.exit(1)
src = src.replace(OLD, NEW, 1)

io.open(P, 'w', encoding='utf-8').write(src)
print('文件大小 %d -> %d' % (before, len(src)))