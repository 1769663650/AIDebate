#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 夜晚环节（狼刀 / 预言家查验 / 女巫用药）统一改为两段式：正常思考 + 只输出决定
# 1) wwDecisionSeg 增加【决定】【查验】标记
# 2) 新增 wwSplitNight(raw, marks)：拆出【思考】与决定段
# 3) 三处指令改为两段格式；解析只从决定段取名/判定
# 4) 上帝视角只显示「思考」灰字，不再把整段理由当决策
import io

PATH = 'assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, tag):
    global src, n
    if old not in src:
        print('WARN 未命中: ' + tag)
        return
    src = src.replace(old, new, 1)
    n += 1
    print('OK   ' + tag)

# ---------- 1) wwDecisionSeg 标记 ----------
old1 = """  const marks = ['决定：', '决定:', '查验：', '查验:', '结论：', '结论:'];"""
new1 = """  const marks = ['【决定】', '【查验】', '决定：', '决定:', '查验：', '查验:', '结论：', '结论:'];"""
rep(old1, new1, 'wwDecisionSeg marks')

# ---------- 2) 新增 wwSplitNight ----------
old2 = """  vote = vote.replace(/^【投票】\\s*/, '').replace(/^投票[:：]\\s*/, '').trim();
  return { think: think, vote: vote };
}"""
new2 = """  vote = vote.replace(/^【投票】\\s*/, '').replace(/^投票[:：]\\s*/, '').trim();
  return { think: think, vote: vote };
}

/* 夜晚专用：拆出「思考」和「决定」段。decision 保留标记，交给 wwDecisionSeg 继续处理。 */
function wwSplitNight(raw, marks) {
  const t = String(raw == null ? '' : raw);
  let best = -1;
  for (let i = 0; i < marks.length; i++) {
    const p = t.indexOf(marks[i]);
    if (p >= 0) { best = p; break; }
  }
  if (best >= 0) {
    return { think: t.slice(0, best).replace(/^【思考】\\s*/, '').trim(), decision: t.slice(best) };
  }
  return { think: '', decision: t.trim() };
}"""
rep(old2, new2, 'wwSplitNight')

# ---------- 3) 狼刀 ----------
old3 = """      let ans = '', think = '';
      const roundTxt = (ww.day <= 1)
        ? '这是第 1 晚，还没有任何信息，随便杀一个好人即可（不要杀狼队友）。'
        : '请先回顾上面的【公共信息】：有没有人自称预言家、有没有人拿到查验结果在带队？优先杀掉对你威胁最大的那个（尤其是跳预言家的），不要只挑沉默的平民。';
      const propTxt = proposals.length
        ? ('\\n你的狼队友今晚已经提议：\\n' + proposals.join('\\n') + '\\n（以上是队友的思考，只有你们狼能看到）尽量和队友保持一致。')
        : '';
      try {
        const r = await wwAskEx(w, '【夜晚 · 狼人行动】\\n现在是第 ' + ww.day + ' 个夜晚。\\n' + roundTxt + propTxt + '\\n可选目标：' + wwNames(pool) + '\\n请认真思考后决定今晚击杀谁：先简要说明理由，最后单独一行写「决定：<玩家名>」。', 0);
        ans = r.text || r.think; think = r.think;
      } catch (e) {
        if (e && e.name === 'AbortError') return null;
        wwNote(w, '第' + ww.day + '夜：我提议杀谁时出错了。');
      }
      const pick = wwPick(wwDecisionSeg(ans), pool) || wwPick(ans, pool) || wwRand(pool);
      proposals.push(w.name + ' 想杀 ' + pick.name + (think ? ('（' + brief(think) + '）') : ''));
      tally[pick.name] = (tally[pick.name] || 0) + 1;
      wwGod('🐺 ' + w.name + ' 提议击杀', pick.name + thinkLine(think || ans));"""
new3 = """      let think = '';
      let pick = null;
      const roundTxt = (ww.day <= 1)
        ? '这是第 1 晚，还没有任何信息，随便杀一个好人即可（不要杀狼队友）。'
        : '请先回顾上面的【公共信息】：有没有人自称预言家、有没有人拿到查验结果在带队？优先杀掉对你威胁最大的那个（尤其是跳预言家的），不要只挑沉默的平民。';
      const propTxt = proposals.length
        ? ('\\n你的狼队友今晚已经提议：\\n' + proposals.join('\\n') + '\\n（以上是队友的思考，只有你们狼能看到）尽量和队友保持一致。')
        : '';
      try {
        const r = await wwAskEx(w, '【夜晚 · 狼人行动】\\n现在是第 ' + ww.day + ' 个夜晚。\\n' + roundTxt + propTxt + '\\n可选目标：' + wwNames(pool) + '\\n请先按下面两段格式输出，不要有多余内容：\\n【思考】这里写你真实的判断——为什么杀他、场上形势如何，只有你和狼队友能看到。\\n【决定】这里只写你要击杀的那一个玩家名（例如：五号），只能有一个名字，不要写任何理由。', 0);
        const raw = r.text || r.think || '';
        const sv = wwSplitNight(raw, ['【决定】', '决定：', '决定:']);
        think = sv.think || r.think;
        pick = wwPick(wwDecisionSeg(raw), pool) || wwPick(raw, pool);
      } catch (e) {
        if (e && e.name === 'AbortError') return null;
        wwNote(w, '第' + ww.day + '夜：我提议杀谁时出错了。');
      }
      if (!pick) pick = wwRand(pool);
      proposals.push(w.name + ' 想杀 ' + pick.name + (think ? ('（' + brief(think) + '）') : ''));
      tally[pick.name] = (tally[pick.name] || 0) + 1;
      wwGod('🐺 ' + w.name + ' 提议击杀', pick.name + thinkLine(think));"""
rep(old3, new3, 'wolf night')

# ---------- 4) 预言家 ----------
old4 = """    let ans = '', think = '';
    try {
      const r = await wwAskEx(s, '【夜晚 · 预言家查验】\\n可选目标：' + wwNames(pool) + '\\n请认真思考后决定今晚查验谁：先简要说明理由，最后单独一行写「查验：<玩家名>」。', 0);
      ans = r.text || r.think; think = r.think;
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }
    const tgt = wwPick(wwDecisionSeg(ans), pool) || wwPick(ans, pool) || wwRand(pool);
    const isWolf = tgt.role === '狼人';
    wwNote(s, '第' + ww.day + '夜，我查验了 ' + tgt.name + '，结果是【' + (isWolf ? '狼人' : '好人') + '】。');
    wwGod('🔮 预言家查验', s.name + ' 查验了 ' + tgt.name + ' → ' + (isWolf ? '狼人' : '好人') + thinkLine(think || ans));"""
new4 = """    let think = '';
    let tgt = null;
    try {
      const r = await wwAskEx(s, '【夜晚 · 预言家查验】\\n可选目标：' + wwNames(pool) + '\\n请先按下面两段格式输出，不要有多余内容：\\n【思考】这里写你真实的判断——为什么查他、你想验证什么，只有你自己能看到。\\n【查验】这里只写你要查验的那一个玩家名（例如：五号），只能有一个名字，不要写理由。', 0);
      const raw = r.text || r.think || '';
      const sv = wwSplitNight(raw, ['【查验】', '查验：', '查验:']);
      think = sv.think || r.think;
      tgt = wwPick(wwDecisionSeg(raw), pool) || wwPick(raw, pool);
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }
    if (!tgt) tgt = wwRand(pool);
    const isWolf = tgt.role === '狼人';
    wwNote(s, '第' + ww.day + '夜，我查验了 ' + tgt.name + '，结果是【' + (isWolf ? '狼人' : '好人') + '】。');
    wwGod('🔮 预言家查验', s.name + ' 查验了 ' + tgt.name + ' → ' + (isWolf ? '狼人' : '好人') + thinkLine(think));"""
rep(old4, new4, 'seer night')

# ---------- 5) 女巫指令 ----------
old5 = """    const inst = '【夜晚 · 女巫行动】\\n' + info +
      '\\n你还有解药：' + (ww.healUsed ? '已用完' : '有') + '；毒药：' + (ww.poisonUsed ? '已用完' : '有') +
      '\\n注意：同一晚最多只能使用一瓶药。\\n请先简要说明你的判断（只有你自己能看到），然后【另起一行】给出最终决定，必须三选一：\\n决定：救\\n决定：毒 <玩家名>\\n决定：不用\\n只有「决定：」这一行才算数；前面写理由时提到任何人的名字都不影响决定，请务必想清楚再下结论。';
    let ans = '', think = '';
    try {
      const r = await wwAskEx(wi, inst, 0);
      ans = r.text || r.think; think = r.think;
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }"""
new5 = """    const inst = '【夜晚 · 女巫行动】\\n' + info +
      '\\n你还有解药：' + (ww.healUsed ? '已用完' : '有') + '；毒药：' + (ww.poisonUsed ? '已用完' : '有') +
      '\\n注意：同一晚最多只能使用一瓶药。\\n请先按下面两段格式输出，不要有多余内容：\\n【思考】这里写你真实的判断——救还是毒、毒谁，只有你自己能看到；这里提到谁的名字都不算数。\\n【决定】这里只写你的最终决定，三选一（只写其中一个，不要写理由）：\\n决定：救\\n决定：毒 <玩家名>\\n决定：不用\\n只有「决定：」这一行才算数。';
    let ans = '', think = '';
    try {
      const r = await wwAskEx(wi, inst, 0);
      ans = r.text || r.think || '';
      const sv = wwSplitNight(ans, ['【决定】', '决定：', '决定:']);
      think = sv.think || r.think;
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }"""
rep(old5, new5, 'witch night')

# ---------- 6) 剩余 thinkLine(think || ans) -> thinkLine(think) ----------
cnt = src.count('thinkLine(think || ans)')
src = src.replace('thinkLine(think || ans)', 'thinkLine(think)')
n += cnt
print('OK   thinkLine(think||ans) x%d' % cnt)

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处修改，文件 %d 字符' % (n, len(src)))