#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 胜利条件改为「屠边」：
#   好人胜：狼人全死；
#   狼人胜：神职（预言家/女巫/猎人）全灭，或村民全灭。
#   不再是「狼人数 >= 好人数」即胜（避免 4v4 打平就直接判狼胜）。
# 同时把胜负条件写进 AI 通用规则，让选手照此目标行动。

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, cnt=1):
    global src, n
    c = src.count(old)
    if c != cnt:
        print('[WARN] 命中 %d 次（期望 %d）：%r' % (c, cnt, old[:70]))
    src = src.replace(old, new)
    n += c

# ---- 1) wwCheckWin 改屠边 ----
rep(
"""function wwCheckWin() {
  const alive = wwAlive();
  const wolves = alive.filter(function (p) { return p.role === '\u72fc\u4eba'; }).length;
  const good = alive.length - wolves;
  if (wolves === 0) return '\u597d\u4eba\u9635\u8425\u80dc\u5229 \U0001f389';
  if (wolves >= good) return '\u72fc\u4eba\u9635\u8425\u80dc\u5229 \U0001f43a';
  return null;
}""",
"""function wwCheckWin() {
  const alive = wwAlive();
  const wolves = alive.filter(function (p) { return p.role === '\u72fc\u4eba'; }).length;
  if (wolves === 0) return '\u597d\u4eba\u9635\u8425\u80dc\u5229 \U0001f389';
  // \u5c60\u8fb9\uff1a\u795e\u804c\u5168\u706d \u6216 \u6751\u6c11\u5168\u706d \u624d\u7b97\u72fc\u80dc\uff08\u4e0d\u518d\u770b\u4eba\u6570\u6253\u5e73\uff09
  const all = ww.players;
  const gods = alive.filter(function (p) { return p.role === '\u9884\u8a00\u5bb6' || p.role === '\u5973\u5deb' || p.role === '\u730e\u4eba'; }).length;
  const villagers = alive.filter(function (p) { return p.role === '\u6751\u6c11'; }).length;
  const hasGods = all.some(function (p) { return p.role === '\u9884\u8a00\u5bb6' || p.role === '\u5973\u5deb' || p.role === '\u730e\u4eba'; });
  const hasVillagers = all.some(function (p) { return p.role === '\u6751\u6c11'; });
  if (hasGods && gods === 0) return '\u72fc\u4eba\u9635\u8425\u80dc\u5229 \U0001f43a';
  if (hasVillagers && villagers === 0) return '\u72fc\u4eba\u9635\u8425\u80dc\u5229 \U0001f43a';
  return null;
}"""
)

# ---- 2) 顶部注释 ----
rep(
"     \u00b7 \u72fc\u4eba\u5168\u6b7b -> \u597d\u4eba\u80dc\uff1b\u72fc\u4eba\u6570 >= \u597d\u4eba\u6570 -> \u72fc\u4eba\u80dc",
"     \u00b7 \u72fc\u4eba\u5168\u6b7b -> \u597d\u4eba\u80dc\uff1b\u795e\u804c\u5168\u706d \u6216 \u6751\u6c11\u5168\u706d -> \u72fc\u4eba\u80dc\uff08\u5c60\u8fb9\uff09"
)

# ---- 3) 通用规则加一条胜负条件 ----
rep(
"    '7. \u3010\u8bb0\u5fc6\u6838\u5bf9\u3011\u4f60\u5728\u3010\u4f60\u5df2\u77e5\u7684\u975e\u516c\u5f00\u4fe1\u606f\u3011\u91cc\u8bb0\u5f55\u7684\u4e8b\u5b9e\uff08\u8eab\u4efd\u3001\u4f60\u6551\u8fc7/\u6bd2\u8fc7/\u67e5\u9a8c\u8fc7\u8c01\u3001\u4f60\u7684\u72fc\u961f\u53cb\u662f\u8c01\uff09\u4e00\u5b9a\u662f\u771f\u7684\u3002\u6bcf\u6b21\u5f00\u53e3\u524d\u5148\u6838\u5bf9\u5b83\uff0c\u7edd\u4e0d\u80fd\u8bb0\u9519\u73a9\u5bb6\u540d\u5b57\u6216\u53f7\u7801\uff0c\u4e5f\u4e0d\u80fd\u7f16\u9020\u6ca1\u53d1\u751f\u7684\u4e8b\u3002'",
"    '7. \u3010\u8bb0\u5fc6\u6838\u5bf9\u3011\u4f60\u5728\u3010\u4f60\u5df2\u77e5\u7684\u975e\u516c\u5f00\u4fe1\u606f\u3011\u91cc\u8bb0\u5f55\u7684\u4e8b\u5b9e\uff08\u8eab\u4efd\u3001\u4f60\u6551\u8fc7/\u6bd2\u8fc7/\u67e5\u9a8c\u8fc7\u8c01\u3001\u4f60\u7684\u72fc\u961f\u53cb\u662f\u8c01\uff09\u4e00\u5b9a\u662f\u771f\u7684\u3002\u6bcf\u6b21\u5f00\u53e3\u524d\u5148\u6838\u5bf9\u5b83\uff0c\u7edd\u4e0d\u80fd\u8bb0\u9519\u73a9\u5bb6\u540d\u5b57\u6216\u53f7\u7801\uff0c\u4e5f\u4e0d\u80fd\u7f16\u9020\u6ca1\u53d1\u751f\u7684\u4e8b\u3002',\n    '8. \u3010\u80dc\u8d1f\u6761\u4ef6\u3011\u597d\u4eba\u9635\u8425\uff1a\u6240\u6709\u72fc\u4eba\u51fa\u5c40\u5373\u80dc\u3002\u72fc\u4eba\u9635\u8425\uff1a\u6740\u5149\u6240\u6709\u3010\u795e\u804c\u3011\uff08\u9884\u8a00\u5bb6/\u5973\u5deb/\u730e\u4eba\uff09\u6216\u6740\u5149\u6240\u6709\u3010\u6751\u6c11\u3011\u5373\u80dc\u2014\u2014\u6ce8\u610f\u662f\u201c\u5c60\u8fb9\u201d\uff0c\u5149\u9760\u4eba\u6570\u6253\u5e73\u4e0d\u7b97\u8d62\u3002'"
)

open(PATH, 'w', encoding='utf-8').write(src)
print('OK\uff0c\u5171 %d \u5904\u4fee\u6539\uff0c\u6587\u4ef6 %d \u5b57\u7b26' % (n, len(src)))