#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 修复「狼人刀自己人」：
#   1. 目标解析：取“最后提到”的候选名（结论通常在思考结尾），不再取最早
#   2. 狼人击杀候选：排除所有狼人（不该自刀/刀队友）
#   3. 狼人提示词加铁律：任何时候不得击杀或投票淘汰队友
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)
n = 0
def rep(old, new, tag):
    global src, n
    if old in src:
        src = src.replace(old, new, 1); n += 1
    else:
        print('   !! 未命中：' + tag)

# ---- 1. wwPick：取最后出现的候选名 ----
rep(
"""function wwPick(text, cands) {
  const t = String(text || '');
  let best = null, bi = -1;
  for (let i = 0; i < cands.length; i++) {
    const idx = t.indexOf(cands[i].name);
    if (idx >= 0 && (bi < 0 || idx < bi)) { bi = idx; best = cands[i]; }
  }
  return best;
}""",
"""function wwPick(text, cands) {
  const t = String(text || '');
  let best = null, bi = -1;
  for (let i = 0; i < cands.length; i++) {
    const idx = t.lastIndexOf(cands[i].name);
    if (idx >= 0 && idx > bi) { bi = idx; best = cands[i]; }
  }
  return best;
}""",
"wwPick 取最后")

# ---- 2. 狼人提示词：加铁律 ----
rep(
"    '\\n白天必须伪装成好人，误导大家票错人，保护自己和队友。';",
"    '\\n白天必须伪装成好人，误导大家票错人，保护自己和队友。' +\n"
"    '\\n【铁律】你和狼队友是一伙的。任何情况下都不得选择击杀或投票淘汰狼队友，必须保护他们。';",
"狼人铁律")

# ---- 3. 狼人击杀候选：排除所有狼人 ----
rep(
"""      const pool = wwAlive().filter(function (p) { return p.name !== w.name; });
      if (!pool.length) break;""",
"""      let pool = wwAlive().filter(function (p) { return p.role !== '狼人'; });
      if (!pool.length) pool = wwAlive().filter(function (p) { return p.name !== w.name; });
      if (!pool.length) break;""",
"狼人击杀排除同类")

io.open(P, 'w', encoding='utf-8').write(src)
print('命中 %d/3 段，文件大小 %d -> %d' % (n, before, len(src)))
if n < 3:
    sys.exit(1)