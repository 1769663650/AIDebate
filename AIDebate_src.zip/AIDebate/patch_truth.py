#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 1) 盘后「本局真相」标出每位玩家的出局方式（被狼刀/被毒/被投票/猎人开枪）+ 第几天，
#    并确保该真相进入每位 AI 的盘后上下文（所有玩家都能看见）。
# 2) 胜利文案标明具体获胜条件（狼人全灭 / 神职全灭 / 平民全灭 / 狼人数碾压）。
import io

PATH = 'assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, tag):
    global src, n
    if old not in src:
        print('WARN 未命中: ' + tag)
        return
    src = src.replace(old, new, 1)
    n += 1
    print('OK   ' + tag)

def repall(old, new, tag):
    global src, n
    if old not in src:
        print('WARN 未命中: ' + tag)
        return
    c = src.count(old)
    src = src.replace(old, new)
    n += 1
    print('OK   ' + tag + ' (%d 处)' % c)

# ---- A. wwKill 记录出局天数 ----
rep(
"""async function wwKill(pl, reason) {
  if (!pl || !pl.alive) return;
  pl.alive = false;
  pl.deathReason = reason;
  wwRenderChips();
}""",
"""async function wwKill(pl, reason) {
  if (!pl || !pl.alive) return;
  pl.alive = false;
  pl.deathReason = reason;
  pl.deathDay = ww.day;
  wwRenderChips();
}

/* 本局真相的一行：标明身份 + 出局方式（存活/第几天怎么死的） */
function wwTruthLine(p) {
  const head = p.name + '：' + (WW_ROLE_EMOJI[p.role] || '') + p.role;
  if (p.alive) return head + '（存活到最后）';
  const why = p.deathReason || '出局';
  const d = p.deathDay ? ('第' + p.deathDay + '天 ' + why) : why;
  return head + '（' + d + '）';
}""",
    'wwKill + wwTruthLine')

# ---- B. 夜晚死亡标注具体原因（狼刀 / 女巫毒） ----
rep(
"""    const deaths = [];
    if (night) {
      if (night.kill && !night.healed) deaths.push(night.kill);
      if (night.poisoned && deaths.indexOf(night.poisoned) < 0) deaths.push(night.poisoned);
    }
    for (let i = 0; i < deaths.length; i++) await wwKill(deaths[i], '夜晚死亡');

    const names = deaths.map(function (p) { return p.name; }).join('、');""",
"""    const deaths = [];
    if (night) {
      if (night.kill && !night.healed) deaths.push({ p: night.kill, why: '被狼人刀杀' });
      if (night.poisoned && !deaths.some(function (d) { return d.p === night.poisoned; })) {
        deaths.push({ p: night.poisoned, why: '被女巫毒杀' });
      }
    }
    for (let i = 0; i < deaths.length; i++) await wwKill(deaths[i].p, deaths[i].why);

    const names = deaths.map(function (d) { return d.p.name; }).join('、');""",
    'night deaths reason')

# ---- C. wwCheckWin 标明获胜方式 ----
rep(
"""function wwCheckWin() {
  const alive = wwAlive();
  const wolves = alive.filter(function (p) { return p.role === '狼人'; }).length;
  if (wolves === 0) return '好人阵营胜利 🎉';
  const good = alive.length - wolves;
  // 狼人票数碾压：严格多于好人 → 狼胜（4v4 打平不算）
  if (wolves > good) return '狼人阵营胜利 🐺';
  // 屠边：神职全灭 或 村民全灭 也算狼胜
  const all = ww.players;
  const gods = alive.filter(function (p) { return p.role === '预言家' || p.role === '女巫' || p.role === '猎人'; }).length;
  const villagers = alive.filter(function (p) { return p.role === '村民'; }).length;
  const hasGods = all.some(function (p) { return p.role === '预言家' || p.role === '女巫' || p.role === '猎人'; });
  const hasVillagers = all.some(function (p) { return p.role === '村民'; });
  if (hasGods && gods === 0) return '狼人阵营胜利 🐺';
  if (hasVillagers && villagers === 0) return '狼人阵营胜利 🐺';
  return null;
}""",
"""function wwCheckWin() {
  const alive = wwAlive();
  const wolves = alive.filter(function (p) { return p.role === '狼人'; }).length;
  if (wolves === 0) return '好人阵营胜利 🎉（狼人全部出局）';
  const good = alive.length - wolves;
  // 狼人票数碾压：严格多于好人 → 狼胜（4v4 打平不算）
  if (wolves > good) return '狼人阵营胜利 🐺（狼人数量已超过好人）';
  // 屠边：神职全灭 或 村民全灭 也算狼胜
  const all = ww.players;
  const gods = alive.filter(function (p) { return p.role === '预言家' || p.role === '女巫' || p.role === '猎人'; }).length;
  const villagers = alive.filter(function (p) { return p.role === '村民'; }).length;
  const hasGods = all.some(function (p) { return p.role === '预言家' || p.role === '女巫' || p.role === '猎人'; });
  const hasVillagers = all.some(function (p) { return p.role === '村民'; });
  if (hasGods && gods === 0) return '狼人阵营胜利 🐺（神职全部出局）';
  if (hasVillagers && villagers === 0) return '狼人阵营胜利 🐺（平民全部出局）';
  return null;
}""",
    'wwCheckWin reason')

# ---- D. 真相列表（盘后 + 结束横幅）统一带上出局方式 ----
repall(
"""  const roster = ww.players.map(function (p) {
    return p.name + '：' + (WW_ROLE_EMOJI[p.role] || '') + p.role + (p.alive ? '（存活）' : '（出局）');
  }).join('\\n');""",
"""  const roster = ww.players.map(function (p) {
    return wwTruthLine(p);
  }).join('\\n');""",
    'roster truth')

repall(
"""  const all = ww.players.map(function (p) {
    return p.name + '：' + (WW_ROLE_EMOJI[p.role] || '') + p.role + (p.alive ? '（存活）' : '（出局）');
  }).join('\\n');""",
"""  const all = ww.players.map(function (p) {
    return wwTruthLine(p);
  }).join('\\n');""",
    'end banner truth')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处修改，文件 %d 字符' % (n, len(src)))