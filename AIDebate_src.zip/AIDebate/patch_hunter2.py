#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 补丁2：修正上一版没命中的两处（夜间猎人开枪 + 应用改名），用字面中文匹配。

HTML = '/sdcard/Download/AIDebate/assets/index.html'
STR  = '/sdcard/Download/AIDebate/res/values/strings.xml'

src = open(HTML, encoding='utf-8').read()
n = 0

def rep(old, new, cnt=1):
    global src, n
    c = src.count(old)
    if c != cnt:
        print('[WARN] 命中 %d 次（期望 %d）：%r' % (c, cnt, old[:70]))
    src = src.replace(old, new)
    n += c

# ---- 夜里猎人被狼刀 → 开枪 ----
rep(
    "    wwPub('第' + ww.day + '天：' + (names ? ('昨夜死亡 ' + names) : '平安夜，无人死亡'));\n\n    let win = wwCheckWin();",
    "    wwPub('第' + ww.day + '天：' + (names ? ('昨夜死亡 ' + names) : '平安夜，无人死亡'));\n\n    // 猎人若夜里死于狼刀 → 可以开枪（被女巫毒死则不能）\n    if (ww.running && night && night.kill && !night.healed && night.kill.role === '猎人') {\n      await wwHunterShoot(night.kill);\n    }\n\n    let win = wwCheckWin();"
)

# ---- 改名 ----
rep('AI辩论擂台', 'AI擂台', src.count('AI辩论擂台'))

open(HTML, 'w', encoding='utf-8').write(src)
print('index.html 共 %d 处，文件 %d 字符' % (n, len(src)))

s = open(STR, encoding='utf-8').read()
c = s.count('AI辩论擂台')
s = s.replace('AI辩论擂台', 'AI擂台')
open(STR, 'w', encoding='utf-8').write(s)
print('strings.xml 更改 %d 处' % c)