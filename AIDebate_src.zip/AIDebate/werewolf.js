/* =========================================================
   狼人杀模式
   ---------------------------------------------------------
   规则要点：
     · 每个 AI 只知道自己身份，狼人互相知道
     · 夜晚行动私密（只有「上帝视角」的你能看到）
     · 白天公开发言 + 投票淘汰
     · 狼人全死 -> 好人胜；狼人数 >= 好人数 -> 狼人胜
   ========================================================= */

const WW_ROLE_EMOJI = { 狼人: '🐺', 预言家: '🔮', 女巫: '🧪', 猎人: '🔫', 村民: '🧑' };

const WW_PRESETS = {
  5:  [['狼人', 1], ['预言家', 1], ['女巫', 1], ['村民', 2]],
  6:  [['狼人', 2], ['预言家', 1], ['女巫', 1], ['村民', 2]],
  7:  [['狼人', 2], ['预言家', 1], ['女巫', 1], ['猎人', 1], ['村民', 2]],
  8:  [['狼人', 3], ['预言家', 1], ['女巫', 1], ['猎人', 1], ['村民', 2]],
  9:  [['狼人', 3], ['预言家', 1], ['女巫', 1], ['猎人', 1], ['村民', 3]],
  10: [['狼人', 3], ['预言家', 1], ['女巫', 1], ['猎人', 1], ['村民', 4]],
  11: [['狼人', 4], ['预言家', 1], ['女巫', 1], ['猎人', 1], ['村民', 4]],
  12: [['狼人', 4], ['预言家', 1], ['女巫', 1], ['猎人', 1], ['村民', 5]]
};

let ww = null;

function wwRolePlan(n) {
  if (WW_PRESETS[n]) return WW_PRESETS[n].slice();
  const wolves = Math.max(1, Math.floor(n / 3));
  const spec = ['预言家', '女巫', '猎人'];
  const plan = [['狼人', wolves]];
  let used = wolves;
  for (let i = 0; i < spec.length && used < n - 1; i++) { plan.push([spec[i], 1]); used++; }
  plan.push(['村民', Math.max(0, n - used)]);
  return plan;
}

function wwRenderPreview() {
  const el = $("#wwRolesPreview");
  if (!el) return;
  const n = state.participants.filter(function (p) { return p.enabled; }).length;
  if (n < 5) {
    el.textContent = '当前启用 ' + n + ' 位选手，至少需要 5 位才能玩狼人杀。';
    return;
  }
  const plan = wwRolePlan(n);
  el.textContent = n + ' 人局配置：' + plan.map(function (p) { return p[0] + ' × ' + p[1]; }).join('，');
}

/* ---------- 基础工具 ---------- */
function wwAlive() { return ww.players.filter(function (p) { return p.alive; }); }
function wwByName(n) {
  for (let i = 0; i < ww.players.length; i++) if (ww.players[i].name === n) return ww.players[i];
  return null;
}
function wwShuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}
function wwPick(text, cands) {
  const t = String(text || '');
  let best = null, bi = -1;
  for (let i = 0; i < cands.length; i++) {
    const idx = t.indexOf(cands[i].name);
    if (idx >= 0 && (bi < 0 || idx < bi)) { bi = idx; best = cands[i]; }
  }
  return best;
}
function wwTally(tally, pool) {
  let best = -1, win = [];
  for (const k in tally) {
    if (!Object.prototype.hasOwnProperty.call(tally, k)) continue;
    if (tally[k] > best) { best = tally[k]; win = [k]; }
    else if (tally[k] === best) win.push(k);
  }
  if (!win.length) return null;
  const name = win[Math.floor(Math.random() * win.length)];
  return wwByName(name);
}
function wwRand(pool) { return pool[Math.floor(Math.random() * pool.length)]; }
function wwNames(pool) { return pool.map(function (p) { return p.name; }).join('、'); }

/* ---------- 界面 ---------- */
function wwScroll() {
  const t = $("#wwTranscript");
  if (t) t.scrollTop = t.scrollHeight;
}
function wwClear() {
  const t = $("#wwTranscript");
  if (t) t.innerHTML = '<p class="empty">还没有开局。<br>在「设置」里配好至少 5 位 AI 选手，<br>然后回来点「开始新一局」。</p>';
  const c = $("#wwChips");
  if (c) c.innerHTML = '';
}
function wwAdd(kind, title, text) {
  const t = $("#wwTranscript");
  if (!t) return null;
  const empty = t.querySelector(".empty");
  if (empty) empty.remove();
  const el = document.createElement("div");
  el.className = "wwev " + kind;
  el.innerHTML = '<div class="wwtitle">' + esc(title) + '</div>' +
                 (text ? '<div class="wwtext">' + esc(text) + '</div>' : '');
  t.appendChild(el);
  wwScroll();
  return el;
}
function wwSpeakBubble(pl, label) {
  const t = $("#wwTranscript");
  if (!t) return null;
  const empty = t.querySelector(".empty");
  if (empty) empty.remove();
  const el = document.createElement("div");
  el.className = "msg";
  el.innerHTML =
    '<div class="avatar">' + esc(pl.emoji || '🤖') + '</div>' +
    '<div class="body">' +
      '<div class="meta"><span class="name">' + esc(pl.name) + '</span>' +
      '<span class="tag">' + esc(label) + '</span></div>' +
      '<div class="content"></div>' +
    '</div>';
  t.appendChild(el);
  wwScroll();
  return { el: el, content: el.querySelector(".content") };
}
function wwGod(title, text) { if (state.wwGodView !== false) wwAdd('night', title, text); }
function wwSys(title, text) { wwAdd('sys', title, text); }
function wwPub(s) { ww.pub.push(s); }
function wwNote(pl, s) { if (pl) pl.notes.push(s); }
function wwStatus(s) { const e = $("#wwStatus"); if (e) e.textContent = s || ""; }

function wwRenderChips() {
  const box = $("#wwChips");
  if (!box) return;
  box.innerHTML = '';
  if (!ww) return;
  ww.players.forEach(function (p) {
    const reveal = !p.alive || !!ww.winner;
    let cls = 'chip' + (p.alive ? '' : ' dead');
    if (reveal) {
      if (p.role === '狼人') cls += ' wolf';
      else if (p.role !== '村民') cls += ' spec';
    }
    const el = document.createElement('div');
    el.className = cls;
    el.textContent = (p.emoji || '🤖') + ' ' + p.name +
      (reveal ? (' ' + (WW_ROLE_EMOJI[p.role] || '') + p.role) : '');
    box.appendChild(el);
  });
}

/* ---------- 提示词 ---------- */
function wwRoleBrief(pl) {
  if (pl.role === '狼人') {
    const mates = ww.players.filter(function (x) { return x.role === '狼人' && x.id !== pl.id; })
                            .map(function (x) { return x.name; });
    return '【你的身份：狼人】\n每晚你和队友共同选择杀死一名玩家。\n你的狼队友是：' +
           (mates.length ? mates.join('、') : '（只有你一个狼人）') +
           '\n白天必须伪装成好人，误导大家票错人，保护自己和队友。';
  }
  if (pl.role === '预言家') {
    return '【你的身份：预言家】\n每晚可以查验一名玩家的真实身份（狼人 / 好人）。\n白天要让好人相信你，同时提防狼人反咬你是假预言家。';
  }
  if (pl.role === '女巫') {
    return '【你的身份：女巫】\n你有一瓶解药和一瓶毒药，各只能用一次，且同一晚最多用一瓶。\n每晚你会知道谁被狼人袭击。救人还是毒人，你要权衡。';
  }
  if (pl.role === '猎人') {
    return '【你的身份：猎人】\n你平时和村民一样。当你被投票淘汰时，可以开枪带走一名玩家。';
  }
  return '【你的身份：村民】\n你没有特殊能力，只能靠发言和投票找出狼人。';
}

function wwSystem(pl) {
  const parts = [
    '你正在玩一场文字版「狼人杀」游戏，你是其中的一名玩家。',
    '你的名字是「' + pl.name + '」。',
    '',
    wwRoleBrief(pl),
    '',
    '【通用规则】',
    '1. 全程用中文，口语化，像一个真人在玩狼人杀。不要出现“作为AI”“作为一个语言模型”这类话。',
    '2. 除了你自己的身份和系统明确告知你的信息，你什么都不知道，不要编造。',
    '3. 发言要为你的胜利条件服务：该骗人就骗人，该隐藏就隐藏，该悍跳就悍跳。',
    '4. 不要说“根据我的分析模型”之类的话，就像正常人一样争论、怀疑、带节奏。'
  ];
  if (pl.cfg.persona && pl.cfg.persona.trim()) {
    parts.push('');
    parts.push('你的人设与说话风格：' + pl.cfg.persona.trim());
  }
  return parts.join('\n');
}

function wwContext(pl, instruction) {
  const alive = wwAlive().map(function (p) { return p.name; });
  const dead = ww.players.filter(function (p) { return !p.alive; }).map(function (p) { return p.name; });
  const parts = [];
  let head = '存活玩家（' + alive.length + '人）：' + alive.join('、');
  if (dead.length) head += '\n已出局：' + dead.join('、');
  parts.push(head);
  if (pl.notes.length) parts.push('【你已知的非公开信息】\n' + pl.notes.join('\n'));
  if (ww.pub.length) parts.push('【公共信息 / 已发生的事】\n' + ww.pub.slice(-40).join('\n'));
  parts.push('【你的行动】\n' + instruction);
  return [
    { role: 'system', content: wwSystem(pl) },
    { role: 'user', content: parts.join('\n\n') }
  ];
}

async function wwAsk(pl, instruction, maxTokens) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.85, maxTokens: maxTokens || 300 });
  return await callModel(cfg, wwContext(pl, instruction), function () {}, ww.abort ? ww.abort.signal : null);
}

async function wwAskStream(pl, instruction, outEl, maxTokens) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: maxTokens || 300 });
  let acc = '';
  await callModel(cfg, wwContext(pl, instruction), function (d) {
    if (d.text) { acc += d.text; outEl.textContent = acc; wwScroll(); }
  }, ww.abort ? ww.abort.signal : null);
  return acc.trim();
}

/* ---------- 夜晚 ---------- */
async function wwNight() {
  let nightKill = null;
  let poisoned = null;
  let healed = false;

  wwGod('🌙 夜晚 · 狼人行动', '狼人正在商量今晚杀谁…');
  wwStatus('🌙 第 ' + ww.day + ' 夜 · 狼人行动');

  const wolves = wwAlive().filter(function (p) { return p.role === '狼人'; });
  if (wolves.length) {
    const tally = {};
    for (let i = 0; i < wolves.length; i++) {
      if (!ww.running) return null;
      const w = wolves[i];
      const pool = wwAlive().filter(function (p) { return p.name !== w.name; });
      if (!pool.length) break;
      let ans = '';
      try {
        ans = await wwAsk(w, '【夜晚 · 狼人行动】\n现在是第 ' + ww.day + ' 个夜晚。\n请选择今晚要击杀的玩家。\n只回复一个玩家名字，不要任何解释。\n可选：' + wwNames(pool), 30);
      } catch (e) {
        if (e && e.name === 'AbortError') return null;
        wwNote(w, '第' + ww.day + '夜：我提议杀谁时出错了。');
      }
      const pick = wwPick(ans, pool) || wwRand(pool);
      tally[pick.name] = (tally[pick.name] || 0) + 1;
      wwGod('🐺 ' + w.name + ' 提议击杀', pick.name);
    }
    nightKill = wwTally(tally, wwAlive());
  }

  if (!ww.running) return null;

  const seers = wwAlive().filter(function (p) { return p.role === '预言家'; });
  for (let i = 0; i < seers.length; i++) {
    if (!ww.running) return null;
    const s = seers[i];
    const pool = wwAlive().filter(function (p) { return p.name !== s.name; });
    if (!pool.length) continue;
    let ans = '';
    try {
      ans = await wwAsk(s, '【夜晚 · 预言家查验】\n请选择今晚要查验身份的玩家。\n只回复一个玩家名字，不要解释。\n可选：' + wwNames(pool), 30);
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }
    const tgt = wwPick(ans, pool) || wwRand(pool);
    const isWolf = tgt.role === '狼人';
    wwNote(s, '第' + ww.day + '夜，我查验了 ' + tgt.name + '，结果是【' + (isWolf ? '狼人' : '好人') + '】。');
    wwGod('🔮 预言家查验', s.name + ' 查验了 ' + tgt.name + ' → ' + (isWolf ? '狼人' : '好人'));
  }

  if (!ww.running) return null;

  const witches = wwAlive().filter(function (p) { return p.role === '女巫'; });
  for (let i = 0; i < witches.length; i++) {
    if (!ww.running) return null;
    const wi = witches[i];
    if (ww.healUsed && ww.poisonUsed) {
      wwNote(wi, '第' + ww.day + '夜，我的两瓶药都用完了。');
      continue;
    }
    const info = nightKill ? ('今晚被狼人袭击的是：' + nightKill.name) : '今晚无人被狼人袭击';
    const inst = '【夜晚 · 女巫行动】\n' + info +
      '\n你还有解药：' + (ww.healUsed ? '已用完' : '有') + '；毒药：' + (ww.poisonUsed ? '已用完' : '有') +
      '\n注意：同一晚最多只能使用一瓶药。\n请回复你的决定：\n· 想救被袭击的人，回复：救\n· 想毒死某人，回复：毒 玩家名\n· 什么都不做，回复：不用';
    let ans = '';
    try {
      ans = await wwAsk(wi, inst, 60);
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }
    const t = String(ans || '');
    const wantHeal = !ww.healUsed && nightKill && t.indexOf('救') >= 0 && t.indexOf('不救') < 0;
    let poisonTgt = null;
    if (!wantHeal && !ww.poisonUsed && t.indexOf('毒') >= 0) {
      const pool = wwAlive().filter(function (p) { return p.name !== wi.name; });
      poisonTgt = wwPick(t.slice(t.indexOf('毒')), pool);
    }
    if (wantHeal) {
      ww.healUsed = true;
      healed = true;
      wwNote(wi, '第' + ww.day + '夜，我用解药救了 ' + nightKill.name + '。');
      wwGod('🧪 女巫用药', wi.name + ' 使用【解药】救下了 ' + nightKill.name);
    } else if (poisonTgt) {
      ww.poisonUsed = true;
      poisoned = poisonTgt;
      wwNote(wi, '第' + ww.day + '夜，我用毒药毒了 ' + poisonTgt.name + '。');
      wwGod('🧪 女巫用药', wi.name + ' 使用【毒药】指向 ' + poisonTgt.name);
    } else {
      wwNote(wi, '第' + ww.day + '夜，我没有用药。');
      wwGod('🧪 女巫用药', wi.name + ' 没有用药');
    }
  }

  return { kill: nightKill, healed: healed, poisoned: poisoned };
}

/* ---------- 白天 ---------- */
function wwSpeechPrompt(pl) {
  return '【白天讨论】\n现在是第 ' + ww.day + ' 天。\n请发表你的发言：陈述身份、指认你认为的狼人、反驳别人、拉票都可以。\n控制在 200 字以内。只输出你要说的话本身，不要加名字前缀，不要写括号动作。';
}

async function wwDaySpeeches() {
  const rounds = Number(state.wwSpeechRounds) || 1;
  for (let r = 1; r <= rounds; r++) {
    const order = wwAlive();
    for (let i = 0; i < order.length; i++) {
      if (!ww.running) return;
      const sp = order[i];
      const label = '第' + ww.day + '天' + (rounds > 1 ? (' 第' + r + '轮') : '') + ' 发言';
      wwStatus('☀️ 第 ' + ww.day + ' 天 · ' + sp.name + ' 发言中');
      const node = wwSpeakBubble(sp, label);
      let txt = '';
      try {
        txt = await wwAskStream(sp, wwSpeechPrompt(sp), node.content, 280);
      } catch (e) {
        if (e && e.name === 'AbortError') return;
        node.el.classList.add('err');
        node.content.textContent = '⚠️ ' + (e && e.message ? e.message : e);
        continue;
      }
      if (txt) wwPub(sp.name + '（' + label + '）：' + txt);
    }
  }
}

async function wwKill(pl, reason) {
  if (!pl || !pl.alive) return;
  pl.alive = false;
  pl.deathReason = reason;
  wwRenderChips();
}

async function wwVote() {
  wwStatus('🗳 第 ' + ww.day + ' 天 · 投票中');
  wwSys('🗳 投票阶段', '存活玩家依次投票');
  const voters = wwAlive();
  const tally = {};
  const detail = [];

  for (let i = 0; i < voters.length; i++) {
    if (!ww.running) return;
    const v = voters[i];
    const pool = wwAlive().filter(function (p) { return p.name !== v.name; });
    if (!pool.length) break;
    let ans = '';
    try {
      ans = await wwAsk(v, '【投票阶段】\n所有人已经发言完毕。\n请投票淘汰一名你认为是狼人的玩家。\n只回复一个玩家名字，不要任何解释。\n可选：' + wwNames(pool), 30);
    } catch (e) {
      if (e && e.name === 'AbortError') return;
    }
    const pick = wwPick(ans, pool) || wwRand(pool);
    tally[pick.name] = (tally[pick.name] || 0) + 1;
    detail.push(v.name + ' → ' + pick.name);
    wwAdd('vote', '🗳 ' + v.name + ' 投给', pick.name);
  }

  const out = wwTally(tally, wwAlive());
  if (!out) { wwSys('投票结果', '无人被淘汰'); return; }

  const score = Object.keys(tally).map(function (k) { return k + ' ' + tally[k] + '票'; }).join('　');
  wwSys('⚖️ 投票结果', score + '\n\n【' + out.name + '】被投票淘汰');
  wwPub('第' + ww.day + '天投票结果：' + out.name + ' 被淘汰出局。');

  const wasHunter = out.role === '猎人';
  await wwKill(out, '投票淘汰');

  if (wasHunter && ww.running) {
    const pool = wwAlive();
    if (pool.length) {
      let ans = '';
      try {
        ans = await wwAsk(out, '【猎人技能】\n你被投票淘汰了。你可以开枪带走一名玩家。\n只回复一个玩家名字，不要解释。\n可选：' + wwNames(pool), 30);
      } catch (e) {}
      const shot = wwPick(ans, pool) || wwRand(pool);
      wwSys('🔫 猎人开枪', out.name + ' 亮出猎人身份，开枪带走了 ' + shot.name);
      wwPub(out.name + ' 是猎人，开枪带走了 ' + shot.name + '。');
      await wwKill(shot, '猎人开枪');
    }
  }
}

function wwCheckWin() {
  const alive = wwAlive();
  const wolves = alive.filter(function (p) { return p.role === '狼人'; }).length;
  const good = alive.length - wolves;
  if (wolves === 0) return '好人阵营胜利 🎉';
  if (wolves >= good) return '狼人阵营胜利 🐺';
  return null;
}

/* ---------- 主循环 ---------- */
async function wwRun() {
  const maxDays = Number(state.wwMaxDays) || 10;
  while (ww.running && !ww.winner && ww.day < maxDays) {
    ww.day++;
    wwPub('===== 第 ' + ww.day + ' 天 =====');

    const night = await wwNight();
    if (!ww.running) break;

    const deaths = [];
    if (night) {
      if (night.kill && !night.healed) deaths.push(night.kill);
      if (night.poisoned && deaths.indexOf(night.poisoned) < 0) deaths.push(night.poisoned);
    }
    for (let i = 0; i < deaths.length; i++) await wwKill(deaths[i], '夜晚死亡');

    const names = deaths.map(function (p) { return p.name; }).join('、');
    wwSys('☀️ 第 ' + ww.day + ' 天天亮了',
      names ? ('昨夜死亡：' + names) : '昨夜是平安夜，无人死亡');
    wwPub('第' + ww.day + '天：' + (names ? ('昨夜死亡 ' + names) : '平安夜，无人死亡'));

    let win = wwCheckWin();
    if (win) { ww.winner = win; break; }

    await wwDaySpeeches();
    if (!ww.running) break;

    await wwVote();
    if (!ww.running) break;

    win = wwCheckWin();
    if (win) { ww.winner = win; break; }
  }

  if (!ww.winner && ww.running) ww.winner = '达到最大天数，游戏平局 🤝';
}

async function wwStart() {
  const ps = state.participants.filter(function (p) { return p.enabled; });
  if (ps.length < 5) { toast('狼人杀至少需要 5 位启用的选手，当前 ' + ps.length + ' 位'); switchView('config'); return; }
  let bad = null;
  for (let i = 0; i < ps.length; i++) {
    if (!String(ps[i].endpoint || '').trim() || !String(ps[i].model || '').trim()) { bad = ps[i]; break; }
  }
  if (bad) { toast('选手「' + bad.name + '」还没填接口地址或模型名'); switchView('config'); return; }

  ww = {
    players: [], pub: [], day: 0, running: true, winner: null,
    healUsed: false, poisonUsed: false,
    abort: new AbortController()
  };
  wwClear();
  switchView('werewolf');
  $("#btnWwStart").disabled = true;
  $("#btnWwStop").disabled = false;

  const plan = wwRolePlan(ps.length);
  const roles = [];
  plan.forEach(function (pair) { for (let k = 0; k < pair[1]; k++) roles.push(pair[0]); });
  wwShuffle(roles);

  ww.players = ps.map(function (p, i) {
    return {
      id: p.id, name: p.name, emoji: p.emoji || '🤖',
      role: roles[i] || '村民', alive: true,
      notes: [], cfg: p
    };
  });
  wwRenderChips();

  const roster = ww.players.map(function (p) {
    return p.name + ' → ' + (WW_ROLE_EMOJI[p.role] || '') + p.role;
  }).join('\n');
  const wolves = ww.players.filter(function (p) { return p.role === '狼人'; })
                           .map(function (p) { return p.name; }).join('、');
  wwGod('🎭 身份分配（只有你能看到）', roster + '\n\n狼人：' + wolves);
  wwSys('游戏开始', ww.players.length + ' 人局。天黑请闭眼…');

  await wwRun();

  const all = ww.players.map(function (p) {
    return p.name + '：' + (WW_ROLE_EMOJI[p.role] || '') + p.role + (p.alive ? '（存活）' : '（出局）');
  }).join('\n');
  wwAdd('end', '🏆 ' + (ww.winner || '游戏结束'), all + '\n\n共进行 ' + ww.day + ' 天');

  ww.running = false;
  $("#btnWwStart").disabled = false;
  $("#btnWwStop").disabled = true;
  wwStatus(ww.winner ? ('🏆 ' + ww.winner) : '已停止');
}

function wwStop() {
  if (!ww || !ww.running) return;
  ww.running = false;
  try { if (ww.abort) ww.abort.abort(); } catch (e) {}
  $("#btnWwStart").disabled = false;
  $("#btnWwStop").disabled = true;
  wwStatus('⏹ 已停止');
  wwSys('已停止', '本局中断');
}

/* ---------- 绑定 ---------- */
function initWerewolf() {
  let b = $("#btnWwStart");
  if (b) b.addEventListener("click", wwStart);
  b = $("#btnWwStop");
  if (b) b.addEventListener("click", wwStop);
  b = $("#btnWwClear");
  if (b) b.addEventListener("click", function () {
    if (ww && ww.running) { toast('先停止再清空'); return; }
    ww = null; wwClear(); wwStatus('');
  });
  b = $("#tab-werewolf");
  if (b) b.addEventListener("click", function () { switchView('werewolf'); wwRenderPreview(); });

  b = $("#wwGodView");
  if (b) {
    b.checked = state.wwGodView !== false;
    b.addEventListener("change", function (e) { state.wwGodView = e.target.checked; save(); });
  }
  b = $("#wwMaxDays");
  if (b) {
    b.value = state.wwMaxDays || 10;
    b.addEventListener("input", function (e) {
      state.wwMaxDays = Math.max(1, Math.min(20, Number(e.target.value) || 10)); save();
    });
  }
  b = $("#wwSpeechRounds");
  if (b) {
    b.value = state.wwSpeechRounds || 1;
    b.addEventListener("input", function (e) {
      state.wwSpeechRounds = Math.max(1, Math.min(3, Number(e.target.value) || 1)); save();
    });
  }
  wwRenderPreview();
}
