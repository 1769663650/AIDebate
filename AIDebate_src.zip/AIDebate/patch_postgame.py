#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 新增「盘后总结」：对局某一方获胜后自动触发，每位选手以自己的身份说一句盘后感言。
# 1) 新增 wwPostGame()；
# 2) wwStart() 在显示结算卡后、游戏真正结束前自动调用（受开关控制）；
# 3) 设置区新增开关 wwPostSummary（默认开启）。

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, cnt=1):
    global src, n
    c = src.count(old)
    if c != cnt:
        print('[WARN] 命中 %d 次（期望 %d）：%r' % (c, cnt, old[:70]))
    src = src.replace(old, new)
    n += c

# ---- 1) 新增 wwPostGame 函数（插在 wwStart 之前） ----
rep(
r"""async function wwStart() {""",
r"""/* ---------- 盘后总结 ---------- */
async function wwPostGame() {
  const result = ww.winner || '游戏结束';
  const roster = ww.players.map(function (p) {
    return p.name + '：' + (WW_ROLE_EMOJI[p.role] || '') + p.role + (p.alive ? '（存活）' : '（出局）');
  }).join('\n');
  wwSys('🎬 盘后总结', '本局真相：\n' + roster + '\n\n大家各自说两句——');
  for (let i = 0; i < ww.players.length; i++) {
    if (!ww.running) return;
    const p = ww.players[i];
    const recap = ww.pub.slice(-30).join('\n');
    const inst = '【盘后总结】\n游戏已经结束，最终结果：' + result + '。\n\n' +
      '【本局真相（现已全部揭晓）】\n' + roster + '\n\n' +
      '【本局公开发言回顾】\n' + (recap || '（无）') + '\n\n' +
      '你是' + p.name + '（' + p.role + '，' + (p.alive ? '活到了最后' : '已出局') + '）。\n' +
      '请你以' + p.name + '的身份，用 1~2 句话发表一句「盘后感言」：' +
      '可以得意地炫耀自己早就看穿了谁、可以吐槽好人或队友当初不听你的、也可以自嘲自己看走眼。\n' +
      '要求：口语化、有情绪、可以玩点梗；1~2 句即可；不要复述规则、不要长篇战术分析、不要加名字前缀、不要写括号动作。';
    const bubble = wwSpeakBubble(p, '🎙 盘后感言');
    let txt = '';
    try {
      txt = await wwAskStream(p, inst, bubble, 300);
    } catch (e) {
      if (e && e.name === 'AbortError') return;
    }
    if (bubble && bubble.content && !String(bubble.content.textContent || '').trim()) {
      bubble.content.textContent = '（沉默不语）';
    }
  }
}

async function wwStart() {"""
)

# ---- 2) wwStart 结束后自动触发 ----
rep(
r"""  wwAdd('end', '🏆 ' + (ww.winner || '游戏结束'), all + '\n\n共进行 ' + ww.day + ' 天');

  ww.running = false;""",
r"""  wwAdd('end', '🏆 ' + (ww.winner || '游戏结束'), all + '\n\n共进行 ' + ww.day + ' 天');

  // 对局某一方胜利后，自动触发盘后总结
  if (ww.running && state.wwPostSummary !== false) { await wwPostGame(); }

  ww.running = false;"""
)

# ---- 3) 设置区开关 ----
rep(
r"""        <label class="chk"><input type="checkbox" id="wwShowThink">显示 AI 思考过程（调试用，默认关）</label>""",
r"""        <label class="chk"><input type="checkbox" id="wwShowThink">显示 AI 思考过程（调试用，默认关）</label>
        <label class="chk"><input type="checkbox" id="wwPostSummary">对局结束后盘后总结（每位选手来一句感言）</label>"""
)

# ---- 4) 开关绑定 ----
rep(
r"""  b = $("#wwShowThink");
  if (b) {
    b.checked = state.wwShowThink === true;
    b.addEventListener("change", function (e) { state.wwShowThink = e.target.checked; save(); });
  }""",
r"""  b = $("#wwShowThink");
  if (b) {
    b.checked = state.wwShowThink === true;
    b.addEventListener("change", function (e) { state.wwShowThink = e.target.checked; save(); });
  }
  b = $("#wwPostSummary");
  if (b) {
    b.checked = state.wwPostSummary !== false;
    b.addEventListener("change", function (e) { state.wwPostSummary = e.target.checked; save(); });
  }"""
)

open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处修改，文件 %d 字符' % (n, len(src)))