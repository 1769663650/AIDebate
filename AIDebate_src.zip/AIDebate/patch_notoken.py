#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 输出不设上限：
#   · cfg.maxTokens 为 0（或空）时，请求里干脆不带 max_tokens，用服务商默认上限
#   · 狼人杀白天发言、重试发言一律不限；选手编辑里 0 = 不限制
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)
n = 0
def rep(old, new, tag):
    global src, n
    if old in src:
        src = src.replace(old, new, 1); n += 1
    else:
        print('   !! 未命中：' + tag)

# ---- 1. callModel：maxTokens<=0 时不下发 max_tokens ----
rep(
"""  const body = {
    model: cfg.model,
    messages: messages,
    stream: true,
    temperature: Number(cfg.temperature == null ? 0.8 : cfg.temperature),
    max_tokens: Number(cfg.maxTokens || 500)
  };""",
"""  const mt = Number(cfg.maxTokens);
  const body = {
    model: cfg.model,
    messages: messages,
    stream: true,
    temperature: Number(cfg.temperature == null ? 0.8 : cfg.temperature)
  };
  if (mt > 0) body.max_tokens = mt;""",
"callModel 去掉字数上限")

# ---- 2. wwAskStream：允许传 0 表示不限制 ----
rep(
"  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: maxTokens || 900 });",
"  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: (maxTokens === 0 ? 0 : (maxTokens || 900)) });",
"wwAskStream 不限")

# ---- 3. 白天发言 + 重试：都不限 ----
rep(
"        txt = await wwAskStream(sp, wwSpeechPrompt(sp), node, 900);",
"        txt = await wwAskStream(sp, wwSpeechPrompt(sp), node, 0);",
"白天发言不限")
rep(
"          txt = await wwSpeechRetry(sp, 600);",
"          txt = await wwSpeechRetry(sp, 0);",
"重试发言不限")
rep(
"  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: maxTokens || 600 });",
"  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: (maxTokens === 0 ? 0 : (maxTokens || 600)) });",
"wwSpeechRetry 不限")

# ---- 4. 选手编辑：最大输出支持 0 = 不限制 ----
rep(
'<label class="fld"><span>最大输出 tokens</span><input class="in" type="number" data-field="maxTokens" min="50" max="4000" step="50" value="\' + p.maxTokens + \'"></label>',
'<label class="fld"><span>最大输出 tokens（0 = 不限制）</span><input class="in" type="number" data-field="maxTokens" min="0" max="200000" step="50" value="\' + p.maxTokens + \'"></label>',
"编辑面板支持0")

io.open(P, 'w', encoding='utf-8').write(src)
print('命中 %d/5 段，文件大小 %d -> %d' % (n, before, len(src)))
if n < 5:
    sys.exit(1)