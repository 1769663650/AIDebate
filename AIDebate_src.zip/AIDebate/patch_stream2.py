#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 修复「内心独白被当成公开发言」：
#   1. 彻底取消「拿思考过程当正文」的兜底
#   2. 发言气泡里把思考过程单独用灰字显示（仅供你看，不进公共信息）
#   3. 正式发言只认模型的 content；上限 280 -> 900，让推理模型想完还能说
#   4. 夜晚等内部决策（投票/刀人）允许用思考内容做私有兜底，但绝不外泄
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)
n = 0

# ---- 1. callModel：去掉「思考当正文」，非流式也把思考单独抛出 ----
OLD1 = '''      const m = j.choices && j.choices[0] && (j.choices[0].message || j.choices[0].delta);
      const c = m && (m.content || m.reasoning_content);
      if (c) { full = c; onDelta({ text: c }); }
    }
  }

  // 兜底二：正文为空但有思考过程 —— 把思考过程当作正文展示，避免空白
  if (!full && thinkAll) { full = thinkAll; onDelta({ text: thinkAll }); }

  return full;
}'''
NEW1 = '''      const m = j.choices && j.choices[0] && (j.choices[0].message || j.choices[0].delta);
      const c = m && m.content;
      const r = m && m.reasoning_content;
      if (c) { full = c; onDelta({ text: c }); }
      else if (r) { onDelta({ think: r }); }
    }
  }

  return full;
}'''
if OLD1 in src: src = src.replace(OLD1, NEW1, 1); n += 1
else: print('   !! 片段1未命中')

# ---- 2. 发言气泡：加一个灰字思考区 ----
OLD2 = """      '<span class="tag">' + esc(label) + '</span></div>' +
      '<div class="content"></div>' +
    '</div>';
  t.appendChild(el);
  wwScroll();
  return { el: el, content: el.querySelector(".content") };"""
NEW2 = """      '<span class="tag">' + esc(label) + '</span></div>' +
      '<div class="think" hidden></div>' +
      '<div class="content"></div>' +
    '</div>';
  t.appendChild(el);
  wwScroll();
  return { el: el, content: el.querySelector(".content"), think: el.querySelector(".think") };"""
if OLD2 in src: src = src.replace(OLD2, NEW2, 1); n += 1
else: print('   !! 片段2未命中')

# ---- 3. wwAsk：内部决策，思考可作私有兜底（不公开） ----
OLD3 = """async function wwAsk(pl, instruction, maxTokens) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.85, maxTokens: maxTokens || 300 });
  return await callModel(cfg, wwContext(pl, instruction), function () {}, ww.abort ? ww.abort.signal : null);
}"""
NEW3 = """async function wwAsk(pl, instruction, maxTokens) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.85, maxTokens: maxTokens || 300 });
  let acc = '', th = '';
  await callModel(cfg, wwContext(pl, instruction), function (d) {
    if (d.text) acc += d.text;
    if (d.think) th += d.think;
  }, ww.abort ? ww.abort.signal : null);
  return acc.trim() || th.trim();
}"""
if OLD3 in src: src = src.replace(OLD3, NEW3, 1); n += 1
else: print('   !! 片段3未命中')

# ---- 4. wwAskStream：思考进灰字区，正文只认 content ----
OLD4 = """async function wwAskStream(pl, instruction, outEl, maxTokens) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: maxTokens || 300 });
  let acc = '';
  await callModel(cfg, wwContext(pl, instruction), function (d) {
    if (d.text) { acc += d.text; outEl.textContent = acc; wwScroll(); }
  }, ww.abort ? ww.abort.signal : null);
  return acc.trim();
}"""
NEW4 = """async function wwAskStream(pl, instruction, node, maxTokens) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: maxTokens || 900 });
  let acc = '', th = '';
  await callModel(cfg, wwContext(pl, instruction), function (d) {
    if (d.think) {
      th += d.think;
      if (node && node.think) { node.think.hidden = false; node.think.textContent = th; }
      wwScroll();
    }
    if (d.text) {
      acc += d.text;
      if (node && node.content) node.content.textContent = acc;
      wwScroll();
    }
  }, ww.abort ? ww.abort.signal : null);
  return acc.trim();
}"""
if OLD4 in src: src = src.replace(OLD4, NEW4, 1); n += 1
else: print('   !! 片段4未命中')

# ---- 5. 白天发言：传整颗节点 + 提高上限 ----
OLD5 = "        txt = await wwAskStream(sp, wwSpeechPrompt(sp), node.content, 280);"
NEW5 = "        txt = await wwAskStream(sp, wwSpeechPrompt(sp), node, 900);"
if OLD5 in src: src = src.replace(OLD5, NEW5, 1); n += 1
else: print('   !! 片段5未命中')

# ---- 6. 空发言提示文案调整 ----
OLD6 = "node.content.textContent = '（模型返回了空内容。请检查：接口地址是否到 /v1 为止、模型名是否正确、Key 是否有额度）';"
NEW6 = "node.content.textContent = '（没有拿到正式发言——只有上方的思考内容。多半是推理模型把输出长度用在了思考上：把该选手的「最大输出」调大，或换用非推理模型名试试）';"
if OLD6 in src: src = src.replace(OLD6, NEW6, 1); n += 1
else: print('   !! 片段6未命中')

io.open(P, 'w', encoding='utf-8').write(src)
print('命中 %d/6 段，文件大小 %d -> %d' % (n, before, len(src)))
if n < 6:
    sys.exit(1)