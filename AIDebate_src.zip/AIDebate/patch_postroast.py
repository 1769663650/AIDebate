#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 给「盘后总结」增加第二轮：互怼。
# 1) wwPostGame 收集每人感言到 postLog；
# 2) 第二轮回怼：每人看到前面所有发言，点着名字怼一句（可回「过」跳过）；
# 3) 新增开关 wwPostRoast（默认开）。

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, cnt=1):
    global src, n
    c = src.count(old)
    if c != cnt:
        print('[WARN] 命中 %d 次（期望 %d）：%r' % (c, cnt, old[:70]))
    src = src.replace(old, new)
    n += c

# ---- 1) 声明 postLog ----
rep(
r"""  wwSys('🎬 盘后总结', '本局真相：\n' + roster + '\n\n大家各自说两句——');""",
r"""  wwSys('🎬 盘后总结', '本局真相：\n' + roster + '\n\n大家各自说两句——');
  const postLog = [];"""
)

# ---- 2) 收集感言 + 追加互怼轮 ----
rep(
r"""    if (bubble && bubble.content && !String(bubble.content.textContent || '').trim()) {
      bubble.content.textContent = '（沉默不语）';
    }
  }
}""",
r"""    if (!txt && bubble && bubble.content && !String(bubble.content.textContent || '').trim()) {
      bubble.content.textContent = '（沉默不语）';
    }
    postLog.push(p.name + '：' + (txt || '（沉默不语）'));
  }

  // 第二轮：互怼（可选）
  if (state.wwPostRoast === false) return;
  wwSys('🔥 盘后互怼', '现在放开了怼——想怼谁怼谁，回「过」可以跳过。');
  for (let i = 0; i < ww.players.length; i++) {
    if (!ww.running) return;
    const p = ww.players[i];
    const seen = postLog.join('\n');
    const inst = '【盘后互怼】\n游戏已经结束了，刚才大家都说了自己的盘后感言：\n' + seen + '\n\n' +
      '现在轮到你（' + p.name + '，' + p.role + '）回怼。请挑一个你最想怼的人——' +
      '可以是当初冤枉你的好人、把锅甩给你的队友、或者嘴硬的对手——点着他的名字怼一句。\n' +
      '要求：口语化、带点情绪和梗；就一句话；必须点出对方的玩家名（例如「八号」）；' +
      '不要复述规则、不要长篇分析、不要加自己名字前缀、不要写括号动作。若实在不想回，就只回复：过。';
    const bubble2 = wwSpeakBubble(p, '🔥 回怼');
    let t2 = '';
    try {
      t2 = await wwAskStream(p, inst, bubble2, 200);
    } catch (e) {
      if (e && e.name === 'AbortError') return;
    }
    t2 = String(t2 || '').trim();
    if (!t2 || t2 === '过' || t2 === '跳过') {
      if (bubble2 && bubble2.el && bubble2.el.parentNode) bubble2.el.parentNode.removeChild(bubble2.el);
      continue;
    }
    postLog.push(p.name + '（回怼）：' + t2);
  }
}"""
)

# ---- 3) 设置区开关 ----
rep(
r"""        <label class="chk"><input type="checkbox" id="wwPostSummary">对局结束后盘后总结（每位选手来一句感言）</label>""",
r"""        <label class="chk"><input type="checkbox" id="wwPostSummary">对局结束后盘后总结（每位选手来一句感言）</label>
        <label class="chk"><input type="checkbox" id="wwPostRoast">盘后互怼（选手互相回怼一轮）</label>"""
)

# ---- 4) 开关绑定 ----
rep(
r"""  b = $("#wwPostSummary");
  if (b) {
    b.checked = state.wwPostSummary !== false;
    b.addEventListener("change", function (e) { state.wwPostSummary = e.target.checked; save(); });
  }""",
r"""  b = $("#wwPostSummary");
  if (b) {
    b.checked = state.wwPostSummary !== false;
    b.addEventListener("change", function (e) { state.wwPostSummary = e.target.checked; save(); });
  }
  b = $("#wwPostRoast");
  if (b) {
    b.checked = state.wwPostRoast !== false;
    b.addEventListener("change", function (e) { state.wwPostRoast = e.target.checked; save(); });
  }"""
)

open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处修改，文件 %d 字符' % (n, len(src)))