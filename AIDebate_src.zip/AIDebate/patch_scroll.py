#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 修复「AI 输出时消息框滑不动」：
#   · 你只要一碰消息框（滑动），就停止自动滚到底
#   · 等你自己滑回底部附近，才恢复「自动跟底」
#   · 狼人杀与辩论两页都按这套处理
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)
n = 0
def rep(old, new, tag):
    global src, n
    if old in src:
        src = src.replace(old, new, 1); n += 1
    else:
        print('   !! 未命中：' + tag)

# ---- 1. 狼人杀：加“跟底”标志 ----
rep(
"let ww = null;",
"let ww = null;\nlet wwStick = true;",
"wwStick 变量")

# ---- 2. 狼人杀：滚动函数改成“跟底才滚” + 绑定手势 ----
rep(
"""function wwScroll() {
  const t = $("#wwTranscript");
  if (t) t.scrollTop = t.scrollHeight;
}""",
"""function wwScroll(force) {
  const t = $("#wwTranscript");
  if (!t) return;
  if (force) { wwStick = true; t.scrollTop = t.scrollHeight; return; }
  if (wwStick) t.scrollTop = t.scrollHeight;
}
function wwBindScroll() {
  const t = $("#wwTranscript");
  if (!t || t.__sb) return;
  t.__sb = true;
  t.addEventListener("touchstart", function () { wwStick = false; }, { passive: true });
  t.addEventListener("mousedown", function () { wwStick = false; }, { passive: true });
  t.addEventListener("wheel", function () { wwStick = false; }, { passive: true });
  t.addEventListener("scroll", function () {
    if (t.scrollHeight - t.scrollTop - t.clientHeight < 24) wwStick = true;
  }, { passive: true });
}""",
"wwScroll 改跟底")

# ---- 3. 初始化与切页时绑定 ----
rep(
"function initWerewolf() {\n  let b = $(\"#btnWwStart\");",
"function initWerewolf() {\n  wwBindScroll();\n  let b = $(\"#btnWwStart\");",
"initWerewolf 绑定")

rep(
"    if (b) b.addEventListener(\"click\", function () { switchView('werewolf'); wwRenderPreview(); });",
"    if (b) b.addEventListener(\"click\", function () { switchView('werewolf'); wwRenderPreview(); wwBindScroll(); });",
"切换狼人杀页绑定")

# ---- 4. 辩论页：同样改成“跟底才滚” ----
rep(
"""function scrollBottom(force) {
  const t = $("#transcript");
  const near = t.scrollHeight - t.scrollTop - t.clientHeight < 140;
  if (force || near) t.scrollTop = t.scrollHeight;
}""",
"""let cxStick = true;
function scrollBottom(force) {
  const t = $("#transcript");
  if (!t) return;
  if (force) { cxStick = true; t.scrollTop = t.scrollHeight; return; }
  if (cxStick) t.scrollTop = t.scrollHeight;
}
function cxBindScroll() {
  const t = $("#transcript");
  if (!t || t.__sb) return;
  t.__sb = true;
  t.addEventListener("touchstart", function () { cxStick = false; }, { passive: true });
  t.addEventListener("mousedown", function () { cxStick = false; }, { passive: true });
  t.addEventListener("wheel", function () { cxStick = false; }, { passive: true });
  t.addEventListener("scroll", function () {
    if (t.scrollHeight - t.scrollTop - t.clientHeight < 24) cxStick = true;
  }, { passive: true });
}""",
"scrollBottom 改跟底")

# ---- 5. 新发言不再强行抢焦点（尊重你是否滑上去了） ----
src = src.replace("  scrollBottom(true);", "  scrollBottom();")
n += 1

# ---- 6. init 里绑定辩论页滚动 ----
rep(
"  initWerewolf();\n  switchView(firstRun ? \"config\" : \"debate\");",
"  cxBindScroll();\n  initWerewolf();\n  switchView(firstRun ? \"config\" : \"debate\");",
"init 绑定辩论滚动")

io.open(P, 'w', encoding='utf-8').write(src)
print('命中 %d/6 段，文件大小 %d -> %d' % (n, before, len(src)))
if n < 6:
    sys.exit(1)