#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 修复「互怼后 bug 变多 / 记性下降 / 思考错乱」
# 1) wwSplitSpeech：只有【思考】没有【发言】时，绝不把思考当成公开发言（防止身份自白外泄、串味）
# 2) wwSpeechRun：think 与 text 分流累加，避免流式交替拼接把【发言】切割位置打乱
# 3) wwContext：新增 wwAnchor()，每次开口前强制回显身份锚点（村民也有），公共信息窗口 40 -> 50
# 4) 盘后总结/互怼：清理残留标签，收紧「过」判定
import io

PATH = 'assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, tag):
    global src, n
    if old not in src:
        print('WARN 未命中: ' + tag)
        return
    src = src.replace(old, new, 1)
    n += 1
    print('OK   ' + tag)

# ---------- 1) wwSplitSpeech ----------
old1 = """function wwSplitSpeech(raw) {
  const t = String(raw || '');
  let think = '', text = t.trim();
  const mi = t.indexOf('【发言】');
  if (mi >= 0) {
    text = t.slice(mi + 4).trim();
    const th = t.slice(0, mi);
    const ti = th.indexOf('【思考】');
    think = (ti >= 0 ? th.slice(ti + 4) : th).trim();
  } else {
    const mi2 = t.indexOf('发言：');
    if (mi2 >= 0) {
      text = t.slice(mi2 + 3).trim();
      const th = t.slice(0, mi2);
      const ti2 = th.indexOf('思考：');
      think = (ti2 >= 0 ? th.slice(ti2 + 3) : th).trim();
    }
  }
  return { think: think, text: text };
}"""
new1 = """function wwSplitSpeech(raw) {
  const t = String(raw || '');
  let think = '', text = '';
  const mi = t.indexOf('【发言】');
  const ti = t.indexOf('【思考】');
  if (mi >= 0) {
    text = t.slice(mi + 4).trim();
    const th = t.slice(0, mi);
    const tj = th.indexOf('【思考】');
    think = (tj >= 0 ? th.slice(tj + 4) : th).trim();
  } else if (ti >= 0) {
    // 只有【思考】、没有【发言】：绝不能把思考当成公开发言（防止身份自白/狼队友外泄）
    think = t.slice(ti + 4).trim();
    text = '';
  } else {
    const mi2 = t.indexOf('发言：');
    if (mi2 >= 0) {
      text = t.slice(mi2 + 3).trim();
      const th = t.slice(0, mi2);
      const ti2 = th.indexOf('思考：');
      think = (ti2 >= 0 ? th.slice(ti2 + 3) : th).trim();
    } else {
      // 没有任何格式标记：整段当作公开发言（兼容直出）
      text = t.trim();
    }
  }
  // 兜底清理：绝不让残留标签进入公开文本
  text = text.replace(/^【(思考|发言)】\\s*/, '').trim();
  return { think: think, text: text };
}"""
rep(old1, new1, 'wwSplitSpeech')

# ---------- 2) wwSpeechRun ----------
old2 = """async function wwSpeechRun(pl, node) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: 0 });
  let raw = '';
  await callModel(cfg, wwContext(pl, wwSpeechPrompt(pl)), function (d) {
    if (d.think) raw += d.think;
    if (d.text) raw += d.text;
    const s = wwSplitSpeech(raw);
    if (node) {
      if (node.think && state.wwShowThink && s.think) { node.think.hidden = false; node.think.textContent = s.think; }
      if (node.content) node.content.textContent = s.text;
    }
    wwScroll();
  }, ww.abort ? ww.abort.signal : null);
  return wwSplitSpeech(raw);
}"""
new2 = """async function wwSpeechRun(pl, node) {
  const cfg = Object.assign({}, pl.cfg, { temperature: 0.9, maxTokens: 0 });
  let raw = '', th = '';
  await callModel(cfg, wwContext(pl, wwSpeechPrompt(pl)), function (d) {
    // 思考与正文分流累加，避免交替拼接打乱【发言】切割位置
    if (d.think) th += d.think;
    if (d.text) {
      raw += d.text;
      const s = wwSplitSpeech(raw);
      if (node && node.content) node.content.textContent = s.text;
      if (node && node.think && state.wwShowThink && s.think) { node.think.hidden = false; node.think.textContent = s.think; }
    }
    wwScroll();
  }, ww.abort ? ww.abort.signal : null);
  const s = wwSplitSpeech(raw);
  if (!s.think && th) s.think = th.trim();
  return s;
}"""
rep(old2, new2, 'wwSpeechRun')

# ---------- 3) wwAnchor + wwContext ----------
old3 = """function wwContext(pl, instruction) {
  const alive = wwAlive().map(function (p) { return p.name; });
  const dead = ww.players.filter(function (p) { return !p.alive; }).map(function (p) { return p.name; });
  const parts = [];
  let head = '存活玩家（' + alive.length + '人）：' + alive.join('、');
  if (dead.length) head += '\\n已出局：' + dead.join('、');
  parts.push(head);
  if (ww.pub.length) parts.push('【公共信息 / 已发生的事】\\n' + ww.pub.slice(-40).join('\\n'));
  if (pl.notes.length) {
    parts.push('【你已知的非公开信息（这是事实，务必记准，绝不能说错名字或号码）】\\n' + pl.notes.join('\\n'));
  }
  parts.push('【你的行动】\\n' + instruction);
  if (pl.notes.length) {
    parts.push('【作答前先做这件事】默读上面【你已知的非公开信息】，确认你的身份、你救过/毒过/查验过谁、你的狼队友是谁——接下来你说的每一个事实都必须和它完全一致，不要被公共信息里的闲话带偏，更不要记错人名或号码。');
  }
  return [
    { role: 'system', content: wwSystem(pl) },
    { role: 'user', content: parts.join('\\n\\n') }
  ];
}"""
new3 = """function wwAnchor(pl) {
  const idx = ww.players.indexOf(pl) + 1;
  let s = '【身份锚点 · 每次开口前先默念】你是第 ' + idx + ' 号玩家「' + pl.name + '」，你的真实身份是【' + pl.role + '】。';
  if (pl.role === '狼人') {
    const mates = ww.players.filter(function (x) { return x.role === '狼人' && x.id !== pl.id; }).map(function (x) { return x.name; });
    s += '你是狼人。你的狼队友只有：' + (mates.length ? mates.join('、') : '（没有其他狼人）') + '。除你自己和这些队友外，其他所有人都是好人，都不是你的队友，绝不能把他们当成队友。';
  } else if (pl.role === '村民') {
    s += '你是普通村民，没有任何特殊能力。你【不是狼人】，也不认识任何狼人，更没有狼队友。';
  } else if (pl.role === '预言家') {
    s += '你是预言家，你查验过谁、结果如何，都写在下面的【你已知的非公开信息】里。';
  } else if (pl.role === '女巫') {
    s += '你是女巫，你救过谁、毒过谁，都写在下面的【你已知的非公开信息】里。';
  } else if (pl.role === '猎人') {
    s += '你是猎人，平时和村民一样，被投票淘汰或被狼人夜里刀死时可以开枪。';
  }
  return s;
}
function wwContext(pl, instruction) {
  const alive = wwAlive().map(function (p) { return p.name; });
  const dead = ww.players.filter(function (p) { return !p.alive; }).map(function (p) { return p.name; });
  const parts = [];
  let head = '存活玩家（' + alive.length + '人）：' + alive.join('、');
  if (dead.length) head += '\\n已出局：' + dead.join('、');
  parts.push(head);
  if (ww.pub.length) parts.push('【公共信息 / 已发生的事】\\n' + ww.pub.slice(-50).join('\\n'));
  if (pl.notes.length) {
    parts.push('【你已知的非公开信息（这是事实，务必记准，绝不能说错名字或号码）】\\n' + pl.notes.join('\\n'));
  }
  parts.push('【你的行动】\\n' + instruction);
  parts.push(wwAnchor(pl));
  parts.push('【作答前先做这件事】先默读上面的【身份锚点】和【你已知的非公开信息】，确认你自己的身份、你救过/毒过/查验过谁、你的狼队友是谁；然后逐条核对你要说的事实——每一个都必须和它们完全一致，不能被公共信息里别人说的话带偏，更不能记错自己或别人的名字、号码与身份。');
  return [
    { role: 'system', content: wwSystem(pl) },
    { role: 'user', content: parts.join('\\n\\n') }
  ];
}"""
rep(old3, new3, 'wwContext+wwAnchor')

# ---------- 4) 盘后总结：清理残留标签 ----------
old4 = """    if (!txt && bubble && bubble.content && !String(bubble.content.textContent || '').trim()) {"""
new4 = """    txt = String(txt || '').replace(/^【(思考|发言)】\\s*/, '').trim();
    if (!txt && bubble && bubble.content && !String(bubble.content.textContent || '').trim()) {"""
rep(old4, new4, 'postgame clean')

# ---------- 5) 互怼：清理标签 + 收紧「过」 ----------
old5 = """    t2 = String(t2 || '').trim();
    if (!t2 || t2 === '过' || t2 === '跳过') {"""
new5 = """    t2 = String(t2 || '').replace(/^【(思考|发言)】\\s*/, '').trim();
    if (!t2 || /^(过|跳过|算了|不怼了|没有)?[。.!！~～]?$/.test(t2) || t2 === '无') {"""
rep(old5, new5, 'roast clean')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处修改，文件 %d 字符' % (n, len(src)))