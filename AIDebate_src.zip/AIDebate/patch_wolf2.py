#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 重做狼人设定：从「必须保护队友」改成「隐藏优先 + 切割/悍跳」。
# 1) wwRoleBrief 狼人：删除硬性“必须保护”，加入关于队友的行为策略。
# 2) wwSpeechPrompt：按角色加特别提醒（狼人不得为队友辩护）。
# 3) wwVote：允许狼人把票投给队友（切割），但解析失败时兜底不投队友。
import io, sys

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
before = len(src)
n = 0

# ---------- 1) 狼人角色说明：核心心法 + 关于队友 ----------
old_a = r"""'\n白天必须伪装成好人，误导大家票错人，保护自己和队友。' +"""
new_a = r"""'\n【核心心法】你的第一优先级不是“保护队友”，而是【让自己活着、不被怀疑】。为了救队友而暴露自己，是最蠢的输法。' +
    '\n【关于队友】\n· 你们心里清楚彼此是一伙，但绝不能让好人看出这层关系。\n· 队友没被怀疑时：就当他是个普通玩家，正常相处，不要刻意亲近或抱团。\n· 队友被查杀、或被集中怀疑时：绝对不要公开替他辩护（“我信X号”“X号肯定是好人”“X号被冤枉了”这类话，等于自曝同伙）。宁可含糊其辞、把矛头引向别人，甚至顺势踩他几脚。\n· 队友已大势已去、注定被投出时：果断【切割】——跟票队友，用卖掉他来洗白自己；也可以由你们中另一人【悍跳预言家】，和真预言家对跳搅局。\n· 只有在你确信“帮他”能被当成正常好人逻辑、且不会牵连自己时，才轻描淡写地帮一句。' +"""
if old_a in src:
    src = src.replace(old_a, new_a, 1); n += 1
else:
    print('!! 未找到 狼人 白天必须伪装 段'); sys.exit(2)

# ---------- 2) 铁律 改为「行动铁律」 ----------
old_b = r"""'\n【铁律】你和狼队友是一伙的。任何情况下都不得选择击杀或投票淘汰狼队友，必须保护他们。'"""
new_b = r"""'\n【行动铁律】夜里不得选择击杀狼队友（这是行动规则，与发言无关，绝不要挂在嘴边）。'"""
if old_b in src:
    src = src.replace(old_b, new_b, 1); n += 1
else:
    print('!! 未找到 铁律 段'); sys.exit(2)

# ---------- 3) wwSpeechPrompt：按角色加特别提醒 ----------
old_sp = r"""function wwSpeechPrompt(pl) {
  return '【白天讨论】\n现在是第 ' + ww.day + ' 天。\n请严格按下面两段格式输出，不要有多余内容：\n【思考】这里写你真实的内心想法——只有你自己能看到，不会被公开。\n【发言】这里写你当众对大家说的话：陈述身份、指认狼人、反驳别人、拉票都可以，控制在 200 字以内，不要加名字前缀，不要写括号动作。\n记住：其他玩家只能看到【发言】那一段。';
}"""
new_sp = r"""function wwSpeechPrompt(pl) {
  let extra = '';
  if (pl.role === '狼人') {
    extra = '\n\n【狼人特别提醒】你现在要装成好人。不要替狼队友说好话、不要为他辩护、不要表现和任何人过分亲近——那会让你被当成同伙一起投出去。如果队友已被查杀、或眼看要被全场投出，你可以顺势踩他、跟他切割，也可以悍跳预言家把水搅浑。';
  } else if (pl.role === '预言家') {
    extra = '\n\n【预言家特别提醒】除非你已经有查杀、或场上有人跳预言家需要你对跳，否则先别亮身份，用低调的发言带节奏、观察。';
  } else if (pl.role === '女巫') {
    extra = '\n\n【女巫特别提醒】不要暴露你有药、更不要说出救了谁毒了谁；像普通好人一样发言。';
  }
  return '【白天讨论】\n现在是第 ' + ww.day + ' 天。\n请严格按下面两段格式输出，不要有多余内容：\n【思考】这里写你真实的内心想法——只有你自己能看到，不会被公开。\n【发言】这里写你当众对大家说的话：陈述身份、指认狼人、反驳别人、拉票都可以，控制在 200 字以内，不要加名字前缀，不要写括号动作。\n记住：其他玩家只能看到【发言】那一段。' + extra;
}"""
if old_sp in src:
    src = src.replace(old_sp, new_sp, 1); n += 1
else:
    print('!! 未找到 wwSpeechPrompt'); sys.exit(2)

# ---------- 4) wwVote：允许切割（候选含队友），但兜底不投队友 ----------
old_v1 = r"""    let pool = wwAlive().filter(function (p) { return p.name !== v.name; });
    if (v.role === '狼人') pool = pool.filter(function (p) { return p.role !== '狼人'; });
    if (!pool.length) pool = wwAlive().filter(function (p) { return p.name !== v.name; });
    if (!pool.length) break;"""
new_v1 = r"""    const pool = wwAlive().filter(function (p) { return p.name !== v.name; });
    if (!pool.length) break;
    let fb = pool;
    if (v.role === '狼人') {
      const nw = pool.filter(function (p) { return p.role !== '狼人'; });
      if (nw.length) fb = nw;
    }"""
if old_v1 in src:
    src = src.replace(old_v1, new_v1, 1); n += 1
else:
    print('!! 未找到 wwVote pool 段'); sys.exit(2)

old_v2 = r"""'（绝对不要投他们，尽量跟队友保持一致）。'"""
new_v2 = r"""'。正常情况下别投队友；但如果某个队友已被查杀、眼看要被全场投出，跟票他反而能洗白你自己（这叫切割）。'"""
if old_v2 in src:
    src = src.replace(old_v2, new_v2, 1); n += 1
else:
    print('!! 未找到 mateTxt 段'); sys.exit(2)

old_v3 = r"""    const pick = wwPick(ans, pool) || wwRand(pool);
    tally[pick.name] = (tally[pick.name] || 0) + 1;
    detail.push(v.name + ' → ' + pick.name);"""
new_v3 = r"""    const pick = wwPick(ans, pool) || wwRand(fb);
    tally[pick.name] = (tally[pick.name] || 0) + 1;
    detail.push(v.name + ' → ' + pick.name);"""
if old_v3 in src:
    src = src.replace(old_v3, new_v3, 1); n += 1
else:
    print('!! 未找到 wwVote pick 段'); sys.exit(2)

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，已应用 %d 处修改，文件大小 %d -> %d' % (n, before, len(src)))