package com.operit.aidebate;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * AI辩论擂台 —— 极薄 Android 外壳。
 *
 * 真正的 App 全部是 assets/index.html 里的 HTML+JS。
 * 这里只做三件浏览器做不到的事：
 *   1) setAllowUniversalAccessFromFileURLs(true) —— 绕过 CORS，
 *      让本地页面可以直接 fetch 各家 AI 的 API，无需任何代理服务器；
 *   2) 允许明文 HTTP（本地 Ollama / 自建中转）；
 *   3) 辩论过程中保持屏幕常亮。
 */
public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 辩论可能跑好几分钟，别让屏幕黑掉
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0F1115"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        // 关键：让 file:// 页面可以访问任意网络源（CORS 绕过）
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        // 允许 http 明文接口（本地模型 / 中转）
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);

        // 方便用 Chrome 远程调试（chrome://inspect）
        WebView.setWebContentsDebuggingEnabled(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());

        // 配置备份桥：把 localStorage 里的配置再落一份到文件，
        // 防止 WebView 偶发读不到 localStorage 时配置看起来“丢了”。
        web.addJavascriptInterface(new BackupBridge(), "AndroidBackup");

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    /* =========================================================
       配置备份桥
       ========================================================= */
    public class BackupBridge {

        private File internalFile() {
            return new File(getFilesDir(), "aidebate_backup.json");
        }

        private File externalFile() {
            File d = getExternalFilesDir(null);
            if (d == null) return null;
            return new File(d, "aidebate_backup.json");
        }

        private void writeTo(File f, String s) throws Exception {
            if (f == null) return;
            File p = f.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            FileOutputStream o = new FileOutputStream(f);
            try {
                o.write(s.getBytes("UTF-8"));
                o.flush();
            } finally {
                try { o.close(); } catch (Exception e) {}
            }
        }

        private String readFrom(File f) {
            try {
                if (f == null || !f.exists() || f.length() <= 0) return "";
                FileInputStream i = new FileInputStream(f);
                try {
                    byte[] b = new byte[(int) f.length()];
                    int n = i.read(b);
                    return n > 0 ? new String(b, 0, n, "UTF-8") : "";
                } finally {
                    try { i.close(); } catch (Exception e) {}
                }
            } catch (Exception e) {
                return "";
            }
        }

        /** 保存一份配置备份（写内部 + 外部两个位置） */
        @JavascriptInterface
        public boolean writeBackup(String json) {
            if (json == null || json.length() < 5) return false;
            boolean ok = false;
            try { writeTo(internalFile(), json); ok = true; } catch (Exception e) {}
            try { writeTo(externalFile(), json); ok = true; } catch (Exception e) {}
            return ok;
        }

        /** 读取配置备份（先外部，再内部） */
        @JavascriptInterface
        public String readBackup() {
            String s = readFrom(externalFile());
            if (s.length() > 5) return s;
            return readFrom(internalFile());
        }

        /** 外部备份文件的完整路径（方便用户手动拷贝） */
        @JavascriptInterface
        public String backupPath() {
            File f = externalFile();
            return f == null ? "" : f.getAbsolutePath();
        }
    }
}
