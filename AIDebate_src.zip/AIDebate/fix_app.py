#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 修复 index.html 的两个地方：
#   1) 替换被写坏的 esc 函数。原来的实体引号在写入时被解码成了裸双引号，
#      导致整段 script 语法错误、init 不执行、所有按钮无响应。
#      新实现用 String.fromCharCode 拼出实体，源码里不再出现实体字面量。
#   2) 在 body 开头插入一个全局错误浮层。以后再有任何 JS 报错，
#      会直接以红色条显示在屏幕底部，而不是静默失效。
#
import sys

PATH = '/sdcard/Download/AIDebate/assets/index.html'

NEW_ESC = (
    'function esc(s) {\n'
    '  var A = String.fromCharCode(38);\n'
    '  var Q = String.fromCharCode(34);\n'
    "  if (s == null || s === undefined) return '';\n"
    "  return String(s).replace(/[&<>\"']/g, function (c) {\n"
    "    if (c === '&') return A + 'amp;';\n"
    "    if (c === '<') return A + 'lt;';\n"
    "    if (c === '>') return A + 'gt;';\n"
    "    if (c === Q) return A + 'quot;';\n"
    "    return A + '#39;';\n"
    '  });\n'
    '}\n'
)

ERR_SCRIPT = (
    '<script>\n'
    'window.onerror = function (m, u, l, c) {\n'
    '  try {\n'
    "    var d = document.getElementById('jserr');\n"
    '    if (!d) {\n'
    "      d = document.createElement('div');\n"
    "      d.id = 'jserr';\n"
    "      d.style.cssText = 'position:fixed;left:8px;right:8px;bottom:8px;z-index:9999;'\n"
    "        + 'background:#3a1f26;border:1px solid #7a2b3a;color:#ffb3c1;'\n"
    "        + 'font:12px/1.5 monospace;padding:8px 10px;border-radius:8px;'\n"
    "        + 'white-space:pre-wrap;max-height:40vh;overflow:auto';\n"
    '      document.body.appendChild(d);\n'
    '    }\n'
    "    d.textContent = 'JS 错误: ' + m + '  @' + (u || '') + ':' + l + ':' + c;\n"
    '  } catch (e) {}\n'
    '  return false;\n'
    '};\n'
    '</script>\n'
)

src = open(PATH, encoding='utf-8').read()
before = len(src)

i = src.find('const esc')
j = src.find('const uid')
if i < 0 or j < 0 or j <= i:
    print('esc 定位失败 i=%d j=%d' % (i, j))
    sys.exit(1)
src = src[:i] + NEW_ESC + src[j:]

if 'jserr' not in src:
    k = src.find('<body>')
    if k < 0:
        print('body 定位失败')
        sys.exit(1)
    k += len('<body>')
    src = src[:k] + '\n' + ERR_SCRIPT + src[k:]
    print('已插入全局错误浮层')
else:
    print('错误浮层已存在，跳过')

open(PATH, 'w', encoding='utf-8').write(src)
print('完成: %d -> %d 字节' % (before, len(src)))