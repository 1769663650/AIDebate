#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 思考行的兜底：如果没有独立的 reasoning_content，
# 就把模型本次的完整回答（含理由）当思考显示出来
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)

cnt = src.count("thinkLine(think)")
if cnt == 0:
    print('!! 未找到 thinkLine(think)，未修改')
    sys.exit(1)

src = src.replace("thinkLine(think)", "thinkLine(think || ans)")
src = src.replace("thinkLine(ans)", "thinkLine(think || ans)")  # 防重入

io.open(P, 'w', encoding='utf-8').write(src)
print('替换 %d 处，文件大小 %d -> %d' % (cnt, before, len(src)))