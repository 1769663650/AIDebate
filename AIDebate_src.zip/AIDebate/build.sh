#!/bin/bash
# ============================================================
#  AI辩论擂台 · 无 Gradle 构建脚本
#  需要的：openjdk + aapt2 + zipalign + apksigner + r8.jar(d8)
#  用法：  bash build.sh
# ============================================================
set -u

PROJ="$(cd "$(dirname "$0")" && pwd)"
SDK=/usr/lib/android-sdk
AJAR=$SDK/platforms/android-23/android.jar
R8=/root/r8.jar
KS=/root/aidebate.keystore
BUILD="$PROJ/build"
OUT="$PROJ/AIDebate.apk"

MIN_SDK=23
TARGET_SDK=34
VNAME_BASE=1.0

# versionCode 自动递增：存在 version.txt 就 +1，方便后续覆盖升级追溯
VFILE="$PROJ/version.txt"
VCODE=1
if [ -f "$VFILE" ]; then
  _v=$(cat "$VFILE" 2>/dev/null)
  case "$_v" in
    ''|*[!0-9]*) VCODE=1 ;;
    *) VCODE=$((_v + 1)) ;;
  esac
fi
printf '%s\n' "$VCODE" > "$VFILE" 2>/dev/null || true
VNAME="$VNAME_BASE.$VCODE"

die() { echo "❌ $*" >&2; exit 1; }

[ -f "$AJAR" ] || die "找不到 android.jar: $AJAR"
[ -f "$R8" ]   || die "找不到 r8.jar(d8): $R8"
command -v aapt2     >/dev/null || die "缺 aapt2"
command -v zipalign  >/dev/null || die "缺 zipalign"
command -v apksigner >/dev/null || die "缺 apksigner"

rm -rf "$BUILD"
mkdir -p "$BUILD/gen" "$BUILD/classes" "$BUILD/dex"

echo "[1/6] aapt2 compile  资源编译"
aapt2 compile --dir "$PROJ/res" -o "$BUILD/res.zip" || die "aapt2 compile 失败"

echo "[2/6] aapt2 link     打包资源 + 清单 + assets"
aapt2 link \
  -o "$BUILD/base.apk" \
  -I "$AJAR" \
  --manifest "$PROJ/AndroidManifest.xml" \
  -A "$PROJ/assets" \
  --java "$BUILD/gen" \
  --min-sdk-version $MIN_SDK \
  --target-sdk-version $TARGET_SDK \
  --version-code $VCODE \
  --version-name "$VNAME" \
  "$BUILD/res.zip" || die "aapt2 link 失败"

echo "[3/6] javac          Java -> class"
find "$PROJ/src" "$BUILD/gen" -name '*.java' > "$BUILD/sources.txt"
javac -encoding UTF-8 -nowarn -source 8 -target 8 \
      -bootclasspath "$AJAR" -cp "$AJAR" \
      -d "$BUILD/classes" @"$BUILD/sources.txt" 2>"$BUILD/javac.log"
if [ $? -ne 0 ]; then
  echo "--- javac 报错 ---"; cat "$BUILD/javac.log"
  die "javac 失败"
fi
echo "      class 文件：$(find "$BUILD/classes" -name '*.class' | wc -l) 个"

echo "[4/6] d8            class -> classes.dex"
java -cp "$R8" com.android.tools.r8.D8 \
  --release --min-api $MIN_SDK \
  --lib "$AJAR" \
  --output "$BUILD/dex" \
  $(find "$BUILD/classes" -name '*.class') || die "d8 失败"
ls -l "$BUILD/dex/classes.dex" | awk '{print "      dex 大小:", $5, "bytes"}'

echo "[5/6] 合并 dex 进 APK（并把 resources.arsc 改成不压缩）"
cp "$BUILD/base.apk" "$BUILD/unsigned.apk"
python3 - "$BUILD" <<'PYEOF' || die "合并失败"
import sys, os, zipfile, shutil
b = sys.argv[1]
apk = os.path.join(b, "unsigned.apk")
dex = os.path.join(b, "dex", "classes.dex")
tmp = os.path.join(b, "merged.apk")

zin = zipfile.ZipFile(apk, "r")
items = zin.infolist()
zout = zipfile.ZipFile(tmp, "w")
for it in items:
    data = zin.read(it.filename)
    # Android11+ 要求 targetSdk>=30 时 resources.arsc 必须未压缩
    if it.filename == "resources.arsc":
        zi = zipfile.ZipInfo(it.filename, date_time=it.date_time)
        zi.compress_type = zipfile.ZIP_STORED
        zi.external_attr = it.external_attr
        zout.writestr(zi, data)
    else:
        zi = zipfile.ZipInfo(it.filename, date_time=it.date_time)
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = it.external_attr
        zout.writestr(zi, data)
zin.close()

with open(dex, "rb") as f:
    d = f.read()
zi = zipfile.ZipInfo("classes.dex", date_time=(2024, 1, 1, 0, 0, 0))
zi.compress_type = zipfile.ZIP_DEFLATED
zout.writestr(zi, d)
zout.close()
shutil.move(tmp, apk)
print("      entries:", len(items) + 1)
PYEOF

echo "[6/6] 对齐 + 签名"
[ -f "$KS" ] || keytool -genkeypair -keystore "$KS" -alias androiddebugkey \
  -storepass android -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=AI Debate, OU=Dev, O=Home, L=Beijing, ST=Beijing, C=CN" >/dev/null 2>&1

zipalign -f 4 "$BUILD/unsigned.apk" "$BUILD/aligned.apk" || die "zipalign 失败"
apksigner sign --ks "$KS" --ks-pass pass:android --key-pass pass:android \
  --ks-key-alias androiddebugkey --out "$OUT" "$BUILD/aligned.apk" || die "签名失败"

apksigner verify --print-certs "$OUT" >/dev/null 2>&1 \
  && echo "      ✅ 签名校验通过" || echo "      ⚠️ 签名校验有警告"

echo ""
echo "============================================"
echo " 构建完成 → $OUT"
echo " 版本: $VNAME  (versionCode $VCODE)"
ls -lh "$OUT" | awk '{print " 大小:", $5}'
echo "============================================"
