#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 1) 把「▶开始投票」按钮和「自动」勾选框移到 停止/清空 同一行。
# 2) 「▶开始投票」默认禁用，只有真的暂停等待时才可点。
# 3) 「自动」随时可勾选。
import io, sys

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
before = len(src)
n = 0

# ---------- 1) HTML：并入顶栏，删除独立闸门条 ----------
old_html = """        <div class="bar-actions">
          <button class="btn primary" id="btnWwStart">开始新一局</button>
          <button class="btn danger" id="btnWwStop" disabled>停止</button>
          <button class="btn ghost" id="btnWwClear">清空</button>
        </div>
      </div>
      <div class="wwchips" id="wwChips"></div>
      <div class="wwgate" id="wwGate" hidden>
        <button class="btn primary" id="wwGateBtn">▶ 继续</button>
        <label class="chk"><input type="checkbox" id="wwAuto">自动（不暂停）</label>
      </div>"""
new_html = """        <div class="bar-actions">
          <button class="btn primary" id="btnWwStart">开始新一局</button>
          <button class="btn danger" id="btnWwStop" disabled>停止</button>
          <button class="btn ghost" id="btnWwClear">清空</button>
          <button class="btn primary" id="wwGateBtn" disabled>▶ 开始投票</button>
          <label class="chk inline"><input type="checkbox" id="wwAuto">自动</label>
        </div>
      </div>
      <div class="wwchips" id="wwChips"></div>"""
if old_html in src:
    src = src.replace(old_html, new_html, 1); n += 1
else:
    print('!! 未找到 狼人杀 bar-actions'); sys.exit(2)

# ---------- 2) CSS ----------
old_css = """.wwgate{display:flex;align-items:center;gap:10px;padding:8px 10px;margin:6px 0;
  background:#1e2a3a;border:1px solid #33507f;border-radius:10px}
.wwgate[hidden]{display:none}
.wwgate .btn{flex:0 0 auto}
.wwgate .chk{margin:0;font-size:12px;color:var(--dim)}
</style>"""
new_css = """.bar-actions .chk.inline{margin:0;font-size:12px;color:var(--dim);white-space:nowrap;
  display:inline-flex;align-items:center;gap:5px;padding:0 4px}
.bar-actions .chk.inline input{width:15px;height:15px;margin:0}
</style>"""
if old_css in src:
    src = src.replace(old_css, new_css, 1); n += 1
else:
    print('!! 未找到 .wwgate CSS'); sys.exit(2)

# ---------- 3) JS：按钮按需启用 ----------
old_js = """function wwHideGate() { const g = $("#wwGate"); if (g) g.hidden = true; }
function wwReleaseGate() {
  if (wwGateResolve) { const r = wwGateResolve; wwGateResolve = null; wwHideGate(); r(); }
}
/* 自动模式直接放行；手动模式显示按钮并等待点击 */
function wwGateNext(label) {
  if (!ww || !ww.running) return Promise.resolve();
  if (state.wwAuto === true) return Promise.resolve();
  const g = $("#wwGate");
  const btn = $("#wwGateBtn");
  if (!g || !btn) return Promise.resolve();
  btn.textContent = label || '▶ 继续';
  g.hidden = false;
  wwStatus('⏸ 已暂停 · 点「' + (label || '继续') + '」继续（勾选「自动」可取消暂停）');
  return new Promise(function (res) { wwGateResolve = res; });
}"""
new_js = """function wwHideGate() {
  const btn = $("#wwGateBtn");
  if (btn) { btn.disabled = true; btn.textContent = '▶ 开始投票'; }
}
function wwReleaseGate() {
  if (wwGateResolve) { const r = wwGateResolve; wwGateResolve = null; wwHideGate(); r(); }
  else wwHideGate();
}
/* 自动模式直接放行；手动模式亮起按钮并等待点击 */
function wwGateNext(label) {
  if (!ww || !ww.running) { wwHideGate(); return Promise.resolve(); }
  if (state.wwAuto === true) { wwHideGate(); return Promise.resolve(); }
  const btn = $("#wwGateBtn");
  if (!btn) return Promise.resolve();
  btn.disabled = false;
  btn.textContent = label || '▶ 继续';
  wwStatus('⏸ 已暂停 · 点「' + (label || '继续') + '」继续（勾选「自动」可取消暂停）');
  return new Promise(function (res) { wwGateResolve = res; });
}"""
if old_js in src:
    src = src.replace(old_js, new_js, 1); n += 1
else:
    print('!! 未找到 闸门 JS'); sys.exit(2)

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，已应用 %d 处修改，文件大小 %d -> %d' % (n, before, len(src)))