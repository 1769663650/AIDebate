#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 收紧 wwDecisionSeg 的兜底：没有「决定：」标记时，只认以决定词开头的行，否则返回空串（视为不行动）。

PATH = '/sdcard/Download/AIDebate/assets/index.html'
src = open(PATH, encoding='utf-8').read()

old = """  if (idx >= 0) return t.slice(idx);
  const lines = t.split('\\n').map(function (x) { return x.trim(); }).filter(function (x) { return x; });
  return lines.slice(-2).join('\\n');
}"""

new = """  if (idx >= 0) return t.slice(idx);
  const lines = t.split('\\n').map(function (x) { return x.trim(); }).filter(function (x) { return x; });
  for (let i = lines.length - 1; i >= 0; i--) {
    if (/^(决定|查验|结论|救|毒|不用|不毒|不救)/.test(lines[i])) return lines[i];
  }
  return '';
}"""

c = src.count(old)
if c != 1:
    print('[WARN] 命中 %d 次' % c)
src = src.replace(old, new)
open(PATH, 'w', encoding='utf-8').write(src)
print('OK，已收紧兜底，命中 %d 次，文件 %d 字符' % (c, len(src)))