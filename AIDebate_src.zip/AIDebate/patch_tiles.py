#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 把 AI 选手改成「编号方格」：
#   · 设置页：方格网格，点格子弹出编辑面板（配 Key / 地址 / 模型 / 人设…）
#   · 狼人杀页：顶部同样是一排编号方格，点格子也能直接改配置
#   · 方格里带一个状态点：绿=接口/Key/模型都填好了，红=还没配
#
import sys

HTML = '/sdcard/Download/AIDebate/assets/index.html'

src = open(HTML, encoding='utf-8').read()
before = len(src)
applied = []
skipped = []


def rep(old, new, tag):
    global src
    if old not in src:
        skipped.append(tag)
        return
    src = src.replace(old, new, 1)
    applied.append(tag)


# ---------- 1. 样式 ----------
NEW_CSS = '''
/* ---------- 编号方格 ---------- */
.pgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(64px,1fr));gap:8px}
.ptile{position:relative;min-height:64px;border-radius:14px;background:var(--panel2);
  border:2px solid var(--line);display:flex;flex-direction:column;align-items:center;
  justify-content:center;gap:1px;padding:6px 4px;overflow:hidden}
.ptile .num{font-size:24px;font-weight:800;line-height:1.05;color:var(--dim)}
.ptile .nm{width:100%;text-align:center;font-size:10.5px;color:var(--dim);
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ptile .st{font-size:10px;color:var(--dim);white-space:nowrap}
.ptile.ready{border-color:#33507f}
.ptile.ready .num{color:var(--txt)}
.ptile.pro{border-color:var(--pro)}
.ptile.con{border-color:var(--con)}
.ptile.neu{border-color:var(--neu)}
.ptile.wolf{border-color:#8a3547;background:#2a1620}
.ptile.spec{border-color:#4a3a7a}
.ptile.dead{opacity:.3}
.ptile.off{opacity:.45}
.ptile .dot{position:absolute;top:5px;right:5px;width:7px;height:7px;border-radius:50%;background:#6b2b38}
.ptile .dot.ok{background:var(--ok)}
.ptile.add{border-style:dashed;border-color:var(--line);font-size:24px;
  color:var(--dim);font-weight:300}
.modal-body{flex:1;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;padding-right:2px}
'''
rep('\n</style>', NEW_CSS + '\n</style>', '格子样式')

# wwchips 改成网格
rep('.wwchips{display:flex;flex-wrap:wrap;gap:6px;padding:8px 12px;background:var(--panel);\n' +
    '  border-bottom:1px solid var(--line);flex:0 0 auto}',
    '.wwchips{display:grid;grid-template-columns:repeat(auto-fill,minmax(64px,1fr));gap:8px;\n' +
    '  padding:10px 12px;background:var(--panel);border-bottom:1px solid var(--line);\n' +
    '  flex:0 0 auto;max-height:36vh;overflow-y:auto}',
    '狼人杀方格容器')

# ---------- 2. 设置页：卡片列表 -> 网格 ----------
rep('<div id="participants"></div>',
    '<div class="pgrid" id="participantGrid"></div>',
    '设置页网格')

# ---------- 3. 编辑面板 ----------
PART_MODAL = '''<div class="mask" id="partMask">
  <div class="modal">
    <h3 id="partTitle">选手</h3>
    <div class="modal-body" id="partBody"></div>
    <div class="bar-actions">
      <button class="btn primary" id="partClose">完成</button>
    </div>
  </div>
</div>

'''
rep('<div class="toast" id="toast"></div>',
    PART_MODAL + '<div class="toast" id="toast"></div>',
    '编辑面板')

# ---------- 4. 格子构造函数 + 编辑面板逻辑 ----------
TILE_JS = '''/* ---------- 编号方格 ---------- */
let editingId = null;

function isConfigured(p) {
  const c = p.cfg || p;
  return !!(String(c.endpoint || '').trim() && String(c.model || '').trim() && String(c.key || '').trim());
}

function mkTile(n, name, tag, extraCls, ready) {
  const el = document.createElement('div');
  el.className = 'ptile' + (ready ? ' ready' : '') + (extraCls ? (' ' + extraCls) : '');
  el.innerHTML = '<div class="num">' + n + '</div>' +
                 '<div class="nm">' + esc(name) + '</div>' +
                 '<div class="st">' + esc(tag || '') + '</div>' +
                 '<span class="dot' + (ready ? ' ok' : '') + '"></span>';
  return el;
}

function openPartEditor(id) {
  const p = state.participants.filter(function (x) { return x.id === id; })[0];
  if (!p) return;
  editingId = p.id;
  const n = state.participants.indexOf(p) + 1;
  $("#partTitle").textContent = '选手 #' + n + (p.name ? (' · ' + p.name) : '');
  const body = $("#partBody");
  body.innerHTML = '';
  body.appendChild(participantCard(p, n - 1));
  $("#partMask").classList.add("show");
  body.scrollTop = 0;
}

function closePartEditor() {
  editingId = null;
  $("#partMask").classList.remove("show");
}

function renderParticipants() {
  const grid = $("#participantGrid");
  if (grid) {
    grid.innerHTML = '';
    state.participants.forEach(function (p, i) {
      const tag = p.enabled ? p.stance : '未启用';
      const cls = p.enabled ? (p.stance === '正方' ? 'pro' : (p.stance === '反方' ? 'con' : 'neu')) : 'off';
      const t = mkTile(i + 1, p.name, tag, cls, isConfigured(p));
      t.addEventListener('click', function () { openPartEditor(p.id); });
      grid.appendChild(t);
    });
    const add = document.createElement('div');
    add.className = 'ptile add';
    add.textContent = '+';
    add.addEventListener('click', function () { addParticipant(true); });
    grid.appendChild(add);
  }
  refreshJudgeOptions();
  if (typeof wwRenderPreview === "function") wwRenderPreview();
  if (typeof wwRenderChips === "function") wwRenderChips();
}

function addParticipant(openEditor) {
  const np = mkPart(state.participants.length);
  state.participants.push(np);
  save();
  renderParticipants();
  if (openEditor) openPartEditor(np.id);
}

function onPartClick(e) {
  const btn = e.target.closest("button[data-act]");
  if (!btn) return;
  const card = btn.closest(".pcard");
  if (!card) return;
  const p = state.participants.filter(function (x) { return x.id === card.dataset.id; })[0];
  if (!p) return;

  if (btn.dataset.act === "del") {
    state.participants = state.participants.filter(function (x) { return x.id !== p.id; });
    if (state.judgeId === p.id) state.judgeId = "";
    save();
    closePartEditor();
    renderParticipants();
  } else if (btn.dataset.act === "test") {
    testConn(p, card.querySelector(".testout"));
  }
}
'''

OLD_RP = '''function renderParticipants() {
  const wrap = $("#participants");
  wrap.innerHTML = "";
  state.participants.forEach((p, i) => wrap.appendChild(participantCard(p, i)));
  refreshJudgeOptions();
  if (typeof wwRenderPreview === "function") wwRenderPreview();
}'''

OLD_CLICK = '''function onPartClick(e) {
  const btn = e.target.closest("button[data-act]");
  if (!btn) return;
  const card = btn.closest(".pcard");
  if (!card) return;
  const p = state.participants.filter(x => x.id === card.dataset.id)[0];
  if (!p) return;

  if (btn.dataset.act === "del") {
    state.participants = state.participants.filter(x => x.id !== p.id);
    if (state.judgeId === p.id) state.judgeId = "";
    save();
    renderParticipants();
  } else if (btn.dataset.act === "test") {
    testConn(p, card.querySelector(".testout"));
  }
}'''

rep(OLD_CLICK, TILE_JS, '方格逻辑（含重写 onPartClick）')

if OLD_RP in src:
    src = src.replace(OLD_RP + '\n', '', 1)
    applied.append('移除旧 renderParticipants')
else:
    skipped.append('移除旧 renderParticipants')

# ---------- 5. init 里的事件绑定 ----------
rep('''  const wrap = $("#participants");
  wrap.addEventListener("input", onPartChange);
  wrap.addEventListener("change", onPartChange);
  wrap.addEventListener("click", onPartClick);''',
    '''  const body = $("#partBody");
  body.addEventListener("input", onPartChange);
  body.addEventListener("change", onPartChange);
  body.addEventListener("click", onPartClick);
  $("#partClose").addEventListener("click", function () { renderParticipants(); closePartEditor(); });
  $("#partMask").addEventListener("click", function (e) {
    if (e.target === $("#partMask")) { renderParticipants(); closePartEditor(); }
  });''',
    '编辑面板事件绑定')

# ---------- 6. 添加按钮 ----------
rep('''  $("#btnAdd").addEventListener("click", () => {
    state.participants.push(mkPart(state.participants.length));
    save();
    renderParticipants();
    $("#participants").lastElementChild.scrollIntoView({ block: "nearest" });
  });''',
    '''  $("#btnAdd").addEventListener("click", function () { addParticipant(true); });''',
    '添加选手按钮')

# ---------- 7. 狼人杀方格 ----------
OLD_CHIPS = '''function wwRenderChips() {
  const box = $("#wwChips");
  if (!box) return;
  box.innerHTML = '';
  if (!ww) return;
  ww.players.forEach(function (p) {
    const reveal = !p.alive || !!ww.winner;
    let cls = 'chip' + (p.alive ? '' : ' dead');
    if (reveal) {
      if (p.role === '狼人') cls += ' wolf';
      else if (p.role !== '村民') cls += ' spec';
    }
    const el = document.createElement('div');
    el.className = cls;
    el.textContent = (p.emoji || '🤖') + ' ' + p.name +
      (reveal ? (' ' + (WW_ROLE_EMOJI[p.role] || '') + p.role) : '');
    box.appendChild(el);
  });
}'''

NEW_CHIPS = '''function wwRenderChips() {
  const box = $("#wwChips");
  if (!box) return;
  box.innerHTML = '';

  // 未开局：显示全部选手的编号方格，点一下就能配 Key
  if (!ww || !ww.players.length) {
    state.participants.forEach(function (p, i) {
      const tag = p.enabled ? p.stance : '未启用';
      const cls = p.enabled ? (p.stance === '正方' ? 'pro' : (p.stance === '反方' ? 'con' : 'neu')) : 'off';
      const t = mkTile(i + 1, p.name, tag, cls, isConfigured(p));
      t.addEventListener('click', function () { openPartEditor(p.id); });
      box.appendChild(t);
    });
    const add = document.createElement('div');
    add.className = 'ptile add';
    add.textContent = '+';
    add.addEventListener('click', function () { addParticipant(true); });
    box.appendChild(add);
    return;
  }

  // 开局中：显示存活状态与身份
  ww.players.forEach(function (p, i) {
    const reveal = !p.alive || !!ww.winner;
    let cls = p.alive ? '' : 'dead';
    if (reveal && p.role === '狼人') cls += ' wolf';
    else if (reveal && p.role !== '村民') cls += ' spec';
    let tag;
    if (reveal) tag = (WW_ROLE_EMOJI[p.role] || '') + p.role;
    else tag = '存活';
    box.appendChild(mkTile(i + 1, p.name, tag, cls, true));
  });
}'''

rep(OLD_CHIPS, NEW_CHIPS, '狼人杀方格')

open(HTML, 'w', encoding='utf-8').write(src)

print('已应用: ' + ('、'.join(applied) if applied else '无'))
if skipped:
    print('已跳过: ' + '、'.join(skipped))
print('文件大小 %d -> %d' % (before, len(src)))