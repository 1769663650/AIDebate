#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 让“思考”私有化：
#   1. 女巫用药、预言家查验也捕获并显示思考
#   2. 思考统一标注「仅该玩家可见」，且永不写入公共信息
#   3. 狼人夜里能看到队友的思考理由（不只名字）
#
import io, sys

P = 'assets/index.html'
src = io.open(P, encoding='utf-8').read()
before = len(src)
n = 0
def rep(old, new, tag):
    global src, n
    if old in src:
        src = src.replace(old, new, 1); n += 1
    else:
        print('   !! 未命中：' + tag)

# ---- 1. 思考标注为“仅该玩家可见” + 加 brief 助手 ----
rep(
"function thinkLine(t) {\n  if (!state.wwShowThink || !t) return '';\n  const s = String(t).replace(/\\s+/g, ' ').trim();\n  return '\\n— 思考：' + (s.length > 200 ? s.slice(0, 200) + '…' : s);\n}",
"function brief(t) {\n  const s = String(t || '').replace(/\\s+/g, ' ').trim();\n  return s.length > 80 ? s.slice(0, 80) + '…' : s;\n}\nfunction thinkLine(t) {\n  if (!state.wwShowThink || !t) return '';\n  const s = String(t).replace(/\\s+/g, ' ').trim();\n  return '\\n— 思考（仅该玩家可见）：' + (s.length > 200 ? s.slice(0, 200) + '…' : s);\n}",
"思考标注+brief")

# ---- 2. 预言家查验：捕获思考 ----
rep(
"""    let ans = '';
    try {
      ans = await wwAsk(s, '【夜晚 · 预言家查验】\\n请选择今晚要查验身份的玩家。\\n只回复一个玩家名字，不要解释。\\n可选：' + wwNames(pool), 30);
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }
    const tgt = wwPick(ans, pool) || wwRand(pool);
    const isWolf = tgt.role === '狼人';
    wwNote(s, '第' + ww.day + '夜，我查验了 ' + tgt.name + '，结果是【' + (isWolf ? '狼人' : '好人') + '】。');
    wwGod('🔮 预言家查验', s.name + ' 查验了 ' + tgt.name + ' → ' + (isWolf ? '狼人' : '好人'));""",
"""    let ans = '', think = '';
    try {
      const r = await wwAskEx(s, '【夜晚 · 预言家查验】\\n可选目标：' + wwNames(pool) + '\\n请认真思考后决定今晚查验谁：先简要说明理由，最后单独一行写「查验：<玩家名>」。', 0);
      ans = r.text || r.think; think = r.think;
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }
    const tgt = wwPick(ans, pool) || wwRand(pool);
    const isWolf = tgt.role === '狼人';
    wwNote(s, '第' + ww.day + '夜，我查验了 ' + tgt.name + '，结果是【' + (isWolf ? '狼人' : '好人') + '】。');
    wwGod('🔮 预言家查验', s.name + ' 查验了 ' + tgt.name + ' → ' + (isWolf ? '狼人' : '好人') + thinkLine(think));""",
"预言家思考")

# ---- 3. 女巫用药：捕获思考 ----
rep(
"""    let ans = '';
    try {
      ans = await wwAsk(wi, inst, 60);
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }
    const t = String(ans || '');""",
"""    let ans = '', think = '';
    try {
      const r = await wwAskEx(wi, inst, 0);
      ans = r.text || r.think; think = r.think;
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }
    const t = String(ans || '');""",
"女巫思考")

rep(
"      wwGod('🧪 女巫用药', wi.name + ' 使用【解药】救下了 ' + nightKill.name);",
"      wwGod('🧪 女巫用药', wi.name + ' 使用【解药】救下了 ' + nightKill.name + thinkLine(think));",
"女巫解药思考")
rep(
"      wwGod('🧪 女巫用药', wi.name + ' 使用【毒药】指向 ' + poisonTgt.name);",
"      wwGod('🧪 女巫用药', wi.name + ' 使用【毒药】指向 ' + poisonTgt.name + thinkLine(think));",
"女巫毒药思考")
rep(
"      wwGod('🧪 女巫用药', wi.name + ' 没有用药');",
"      wwGod('🧪 女巫用药', wi.name + ' 没有用药' + thinkLine(think));",
"女巫不用药思考")

# ---- 4. 狼人：队友提议带上思考理由 ----
rep(
"""      const propTxt = proposals.length
        ? ('\\n你的狼队友今晚已经提议杀：' + proposals.join('、') + '。尽量和队友保持一致。')
        : '';""",
"""      const propTxt = proposals.length
        ? ('\\n你的狼队友今晚已经提议：\\n' + proposals.join('\\n') + '\\n（以上是队友的思考，只有你们狼能看到）尽量和队友保持一致。')
        : '';""",
"狼队友思考共享")

rep(
"      proposals.push(pick.name);",
"      proposals.push(w.name + ' 想杀 ' + pick.name + (think ? ('（' + brief(think) + '）') : ''));",
"狼提议带理由")

io.open(P, 'w', encoding='utf-8').write(src)
print('命中 %d/7 段，文件大小 %d -> %d' % (n, before, len(src)))
if n < 7:
    sys.exit(1)