#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 进一步治理「狼把自己当村民 / 内心身份漂移」
# 1) wwSystem 增加第 9 条【内心独白不伪装】：思考与投票/行动理由必须按真实身份，只有对外发言才骗人
# 2) wwAnchor 增加提示：公共信息（含自己之前的话）都可能是伪装，身份一律以身份锚点为准
# 3) thinkLine 标签改为「内心/推理」，避免把纯文本答案误标成“思考”
import io

PATH = 'assets/index.html'
src = io.open(PATH, encoding='utf-8').read()
n = 0

def rep(old, new, tag):
    global src, n
    if old not in src:
        print('WARN 未命中: ' + tag)
        return
    src = src.replace(old, new, 1)
    n += 1
    print('OK   ' + tag)

# ---------- 1) wwSystem 第 9 条 ----------
old1 = """    '8. 【胜负条件】好人阵营：所有狼人出局即胜。狼人阵营：杀光所有【神职】（预言家/女巫/猎人）、或杀光所有【村民】、或活着的狼人严格多于好人（票数碾压）即胜。'
  ];"""
new1 = """    '8. 【胜负条件】好人阵营：所有狼人出局即胜。狼人阵营：杀光所有【神职】（预言家/女巫/猎人）、或杀光所有【村民】、或活着的狼人严格多于好人（票数碾压）即胜。',
    '9. 【内心独白不需要伪装】只有对外【发言】才需要骗人。在【思考】里、以及投票/夜晚决定时写的“理由”里，你是在自己心里盘算，必须按你的真实身份思考——你是狼人就必须清楚自己是狼人、有自己的狼队友；你是村民就绝不能说自己是狼或编造队友。绝不能把对外伪装的那套身份，带进你的内心推理。'
  ];"""
rep(old1, new1, 'wwSystem rule9')

# ---------- 2) wwAnchor 增加公共信息不可靠提示 ----------
old2 = """  } else if (pl.role === '猎人') {
    s += '你是猎人，平时和村民一样，被投票淘汰或被狼人夜里刀死时可以开枪。';
  }
  return s;
}"""
new2 = """  } else if (pl.role === '猎人') {
    s += '你是猎人，平时和村民一样，被投票淘汰或被狼人夜里刀死时可以开枪。';
  }
  s += '\\n（提示：公共信息里每个人的发言都可能是伪装，甚至包括你自己之前为了演戏说过的话；只有本【身份锚点】和【你已知的非公开信息】才是真的。判断身份一律以此为准。）';
  return s;
}"""
rep(old2, new2, 'wwAnchor caveat')

# ---------- 3) thinkLine 标签 ----------
old3 = """  return '\\n— 思考（仅该玩家可见）：'"""
new3 = """  return '\\n— 内心/推理（仅该玩家可见）：'"""
rep(old3, new3, 'thinkLine label')

io.open(PATH, 'w', encoding='utf-8').write(src)
print('OK，共 %d 处修改，文件 %d 字符' % (n, len(src)))