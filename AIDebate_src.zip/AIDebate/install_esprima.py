#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# 无 pip 环境下手动安装 esprima：
# 从 PyPI 镜像下载 wheel 或 sdist，找出 esprima 包目录，复制到 /root/pylibs。
#
import io
import os
import re
import shutil
import socket
import sys
import tarfile
import urllib.parse
import urllib.request
import zipfile

socket.setdefaulttimeout(90)

IDX = 'https://pypi.tuna.tsinghua.edu.cn/simple/esprima/'
DEST = '/root/pylibs'
TMP = '/root/_esprima_tmp'

page = urllib.request.urlopen(IDX).read().decode('utf-8', 'replace')
hrefs = re.findall(r'href=[\'"]([^\'"]+)[\'"]', page)
print('链接总数: %d' % len(hrefs))
for h in hrefs[:15]:
    print('   ', h)

cands = [h.split('#')[0] for h in hrefs if '.whl' in h or '.tar.gz' in h]
print('候选包数: %d' % len(cands))
if not cands:
    print('没有可下载的包')
    sys.exit(1)

url = urllib.parse.urljoin(IDX, cands[-1])
print('下载:', url)
data = urllib.request.urlopen(url).read()
print('大小: %d 字节' % len(data))

shutil.rmtree(TMP, ignore_errors=True)
os.makedirs(TMP, exist_ok=True)

if url.endswith('.whl'):
    zipfile.ZipFile(io.BytesIO(data)).extractall(TMP)
else:
    tarfile.open(fileobj=io.BytesIO(data), mode='r:gz').extractall(TMP)

found = None
for root, dirs, files in os.walk(TMP):
    if os.path.basename(root) == 'esprima' and '__init__.py' in files:
        found = root
        break

if not found:
    print('没定位到 esprima 包目录')
    sys.exit(1)

os.makedirs(DEST, exist_ok=True)
target = os.path.join(DEST, 'esprima')
shutil.rmtree(target, ignore_errors=True)
shutil.copytree(found, target)
print('已安装到:', target)
print('模块文件数: %d' % len(os.listdir(target)))